#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 41fef6f1352be994cd90056d47440fe9aa4c068f
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 41fef6f1352be994cd90056d47440fe9aa4c068f xarray/tests/test_indexes.py
git apply -v - <<'EOF_114329324912'
diff --git a/xarray/tests/test_indexes.py b/xarray/tests/test_indexes.py
index fa8bd84..57985da 100644
--- a/xarray/tests/test_indexes.py
+++ b/xarray/tests/test_indexes.py
@@ -688,12 +688,30 @@ def test_safe_cast_to_index_cftimeindex():
         assert isinstance(actual, type(expected))
 
 
-# Test that datetime.datetime objects are never used in a CFTimeIndex
-@requires_cftime
-def test_safe_cast_to_index_datetime_datetime():
-    dates = [datetime(1, 1, day) for day in range(1, 20)]
+import pytest
+import xarray as xr
+import numpy as np
 
-    expected = pd.Index(dates)
-    actual = safe_cast_to_index(np.array(dates))
-    assert_array_equal(expected, actual)
-    assert isinstance(actual, pd.Index)
+@pytest.mark.parametrize("dtype", ["int32", "float32"])
+def test_restore_dtype_on_multiindexes(dtype: str) -> None:
+    foo = xr.Dataset(coords={"bar": ("bar", np.array([0, 1], dtype=dtype))})
+    foo = foo.stack(baz=("bar",))
+    assert str(foo["bar"].values.dtype) == dtype
+
+def test_multiindex_with_various_dtypes():
+    ds = xr.Dataset(coords={'a': np.array([0, 1, 2], dtype='int32'),
+                            'b': np.array([0.1, 0.2, 0.3], dtype='float64')})
+    stacked = ds.stack(c=('a', 'b'))
+    assert str(stacked['a'].values.dtype) == 'int32'
+    assert str(stacked['b'].values.dtype) == 'float64'
+
+def test_empty_multiindex():
+    ds = xr.Dataset(coords={'a': np.array([], dtype='int32')})
+    stacked = ds.stack(b=('a',))
+    assert str(stacked['a'].values.dtype) == 'int32'
+
+def test_multiindex_preserves_dtype_after_unstack():
+    ds = xr.Dataset(coords={'a': np.array([0, 1], dtype='int32')})
+    stacked = ds.stack(b=('a',))
+    unstacked = stacked.unstack('b')
+    assert str(unstacked['a'].values.dtype) == 'int32'

EOF_114329324912
pytest -rA xarray/tests/test_indexes.py
git checkout 41fef6f1352be994cd90056d47440fe9aa4c068f xarray/tests/test_indexes.py
