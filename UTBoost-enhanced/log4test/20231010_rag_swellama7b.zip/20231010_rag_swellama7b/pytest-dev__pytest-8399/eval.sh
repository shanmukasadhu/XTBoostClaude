#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 6e7dc8bac831cd8cf7a53b08efa366bd84f0c0fe
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 6e7dc8bac831cd8cf7a53b08efa366bd84f0c0fe testing/test_unittest.py
git apply -v - <<'EOF_114329324912'
diff --git a/testing/test_unittest.py b/testing/test_unittest.py
index 2c720b0..5c5b73a 100644
--- a/testing/test_unittest.py
+++ b/testing/test_unittest.py
@@ -301,8 +301,28 @@ def test_setup_setUpClass(pytester: Pytester) -> None:
     reprec = pytester.inline_run(testpath)
     reprec.assertoutcome(passed=3)
 
+def test_unittest_setUpClass_fixtures_private(pytester: Pytester) -> None:
+    testpath = pytester.makepyfile(
+        """
+        import unittest
+
+        class TestClass(unittest.TestCase):
+            @classmethod
+            def setUpClass(cls):
+                pass
 
-def test_setup_class(pytester: Pytester) -> None:
+            def test_example(self):
+                pass
+
+        """
+    )
+    result = pytester.runpytest("--fixtures")
+    assert result.ret == 0
+    result.stdout.no_fnmatch_line("*unittest_setUpClass_fixture_TestClass*")
+
+    result = pytester.runpytest("--fixtures", "-v")
+    assert result.ret == 0
+    result.stdout.fnmatch_lines(["*unittest_setUpClass_fixture_TestClass*"])
     testpath = pytester.makepyfile(
         """
         import unittest

EOF_114329324912
pytest -rA testing/test_nose.py testing/test_unittest.py
git checkout 6e7dc8bac831cd8cf7a53b08efa366bd84f0c0fe testing/test_unittest.py
