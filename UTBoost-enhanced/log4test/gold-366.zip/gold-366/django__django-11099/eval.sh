#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff d26b2424437dabeeca94d7900b37d2df4410da0c
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout d26b2424437dabeeca94d7900b37d2df4410da0c tests/auth_tests/test_validators.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/auth_tests/test_validators.py b/tests/auth_tests/test_validators.py
index 688e6ff..8aec7ce 100644
--- a/tests/auth_tests/test_validators.py
+++ b/tests/auth_tests/test_validators.py
@@ -248,7 +248,31 @@ class UsernameValidatorsTests(SimpleTestCase):
                 with self.assertRaises(ValidationError):
                     v(invalid)
 
-    def test_ascii_validator(self):
+    def test_trailing_newline_unicode_validator(self):
+        """Test UnicodeUsernameValidator against usernames with trailing newlines."""
+        invalid_usernames = [
+            'userwithnewline\n',
+            'newline\u000A',
+            'anotheruser\n'
+        ]
+        v = validators.UnicodeUsernameValidator()
+        for invalid in invalid_usernames:
+            with self.subTest(invalid=invalid):
+                with self.assertRaises(ValidationError):
+                    v(invalid)
+
+    def test_trailing_newline_ascii_validator(self):
+        """Test ASCIIUsernameValidator against usernames with trailing newlines."""
+        invalid_usernames = [
+            'userwithnewline\n',
+            'newline\u000A',
+            'anotheruser\n'
+        ]
+        v = validators.ASCIIUsernameValidator()
+        for invalid in invalid_usernames:
+            with self.subTest(invalid=invalid):
+                with self.assertRaises(ValidationError):
+                    v(invalid)
         valid_usernames = ['glenn', 'GLEnN', 'jean-marc']
         invalid_usernames = ["o'connell", 'Éric', 'jean marc', "أحمد"]
         v = validators.ASCIIUsernameValidator()
@@ -258,4 +282,4 @@ class UsernameValidatorsTests(SimpleTestCase):
         for invalid in invalid_usernames:
             with self.subTest(invalid=invalid):
                 with self.assertRaises(ValidationError):
-                    v(invalid)
+                    v(invalid)

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 auth_tests.test_validators
git checkout d26b2424437dabeeca94d7900b37d2df4410da0c tests/auth_tests/test_validators.py
