#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff a7e38c5c61928033a2dc1915cbee8caa8544a4d0
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout a7e38c5c61928033a2dc1915cbee8caa8544a4d0 testing/test_collection.py
git apply -v - <<'EOF_114329324912'
diff --git a/testing/test_collection.py b/testing/test_collection.py
index b774a67..22fd6f7 100644
--- a/testing/test_collection.py
+++ b/testing/test_collection.py
@@ -1,3 +1,4 @@
+
 import os
 import pprint
 import sys
@@ -9,7 +10,7 @@ from _pytest.config import ExitCode
 from _pytest.main import _in_venv
 from _pytest.main import Session
 from _pytest.pathlib import symlink_or_skip
-from _pytest.pytester import Testdir
+from _pytest.pytester import Testdir, Pytester
 
 
 class TestCollector:
@@ -1175,6 +1176,32 @@ def test_collect_symlink_out_of_tree(testdir):
             "test_real.py::test_nodeid PASSED"
         ]
     )
+
+
+def test_collect_symlink_dir(pytester: Pytester) -> None:
+    """A symlinked directory is collected."""
+    dir = pytester.mkdir("dir")
+    dir.joinpath("test_it.py").write_text("def test_it(): pass", "utf-8")
+    pytester.path.joinpath("symlink_dir").symlink_to(dir)
+    result = pytester.runpytest()
+    result.assert_outcomes(passed=2)
+
+
+def test_symlink_to_non_test_dir(pytester: Pytester) -> None:
+    """A symlink pointing to a non-test directory should not collect any tests."""
+    non_test_dir = pytester.mkdir("non_test_dir")
+    pytester.path.joinpath("symlink_non_test").symlink_to(non_test_dir)
+    result = pytester.runpytest()
+    result.assert_outcomes(passed=0, failed=0)
+
+
+def test_symlink_loop(pytester: Pytester) -> None:
+    """A symlink that creates a loop should not cause infinite recursion."""
+    loop_dir = pytester.mkdir("loop_dir")
+    loop_dir.joinpath("test_loop.py").write_text("def test_loop(): pass", "utf-8")
+    loop_dir.joinpath("loop_symlink").symlink_to(loop_dir)
+    result = pytester.runpytest()
+    result.assert_outcomes(passed=1, failed=0)
     assert result.ret == 0
 
 

EOF_114329324912
pytest -rA testing/test_collection.py
git checkout a7e38c5c61928033a2dc1915cbee8caa8544a4d0 testing/test_collection.py
