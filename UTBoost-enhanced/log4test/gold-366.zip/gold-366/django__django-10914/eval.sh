#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff e7fd69d051eaa67cb17f172a39b57253e9cb831a
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout e7fd69d051eaa67cb17f172a39b57253e9cb831a tests/test_utils/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/test_utils/tests.py b/tests/test_utils/tests.py
index 3760491..3116499 100644
--- a/tests/test_utils/tests.py
+++ b/tests/test_utils/tests.py
@@ -1090,6 +1090,12 @@ class OverrideSettingsTests(SimpleTestCase):
         base_url attribute of django.core.files.storage.default_storage.
         """
         self.assertEqual(default_storage.base_location, '')
+
+    def test_default_file_upload_permissions(self):
+        """
+        Default FILE_UPLOAD_PERMISSIONS should be 0o644.
+        """
+        self.assertEqual(default_storage.file_permissions_mode, 0o644)
         with self.settings(MEDIA_URL='/test_value/'):
             self.assertEqual(default_storage.base_url, '/test_value/')
 

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 test_utils.tests
git checkout e7fd69d051eaa67cb17f172a39b57253e9cb831a tests/test_utils/tests.py
