#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 70381f282f2d9d039da860e391fe51649df2779d
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 70381f282f2d9d039da860e391fe51649df2779d sympy/printing/tests/test_latex.py
git apply -v - <<'EOF_114329324912'
diff --git a/sympy/printing/tests/test_latex.py b/sympy/printing/tests/test_latex.py
index ba93bdc..6292822 100644
--- a/sympy/printing/tests/test_latex.py
+++ b/sympy/printing/tests/test_latex.py
@@ -664,6 +664,19 @@ def test_latex_derivatives():
     x2 = Symbol('x2')
     assert latex(diff(f(x1, x2), x1)) == r'\frac{\partial}{\partial x_{1}} f{\left(x_{1},x_{2} \right)}'
 
+def test_issue_subs_parenthesizing():
+    from sympy import Subs
+    from sympy.abc import x, y
+    
+    # Original test patch
+    assert latex(3*Subs(-x+y, (x,), (1,))) == r'3 \left. \left(- x + y\right) \right|_{\substack{ x=1 }}'
+    
+    # Additional test cases
+    assert latex(3*Subs(x-y, (x,), (1,))) == r'3 \left. \left(x - y\right) \right|_{\substack{ x=1 }}'
+    assert latex(2*Subs(x*y - x/y, (x,), (1,))) == r'2 \left. \left(x y - \frac{x}{y}\right) \right|_{\substack{ x=1 }}'
+    assert latex(Subs(-x**2 + y**2, (x,), (1,))) == r'\left. \left(- x^{2} + y^{2}\right) \right|_{\substack{ x=1 }}'
+    assert latex(5*Subs(x**2 + y, (y,), (2,))) == r'5 \left. \left(x^{2} + y\right) \right|_{\substack{ y=2 }}'
+
     n1 = Symbol('n1')
     assert latex(diff(f(x), (x, n1))) ==  r'\frac{d^{n_{1}}}{d x^{n_{1}}} f{\left(x \right)}'
 

EOF_114329324912
PYTHONWARNINGS='ignore::UserWarning,ignore::SyntaxWarning' bin/test -C --verbose sympy/printing/tests/test_latex.py
git checkout 70381f282f2d9d039da860e391fe51649df2779d sympy/printing/tests/test_latex.py
