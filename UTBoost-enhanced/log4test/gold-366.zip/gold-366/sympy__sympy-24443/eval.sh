#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 809c53c077485ca48a206cee78340389cb83b7f1
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 809c53c077485ca48a206cee78340389cb83b7f1 sympy/combinatorics/tests/test_homomorphisms.py
git apply -v - <<'EOF_114329324912'
diff --git a/sympy/combinatorics/tests/test_homomorphisms.py b/sympy/combinatorics/tests/test_homomorphisms.py
index 0a025da..d4c4624 100644
--- a/sympy/combinatorics/tests/test_homomorphisms.py
+++ b/sympy/combinatorics/tests/test_homomorphisms.py
@@ -1,3 +1,4 @@
+
 from sympy.combinatorics import Permutation
 from sympy.combinatorics.perm_groups import PermutationGroup
 from sympy.combinatorics.homomorphisms import homomorphism, group_isomorphism, is_isomorphic
@@ -57,7 +58,11 @@ def test_homomorphism():
     assert T.codomain == D
     assert T(a*b) == p
 
-def test_isomorphisms():
+def test_permutation_group_homomorphism():
+    # Test to ensure that homomorphism works on PermutationGroups
+    D3 = DihedralGroup(3)
+    T = homomorphism(D3, D3, D3.generators, D3.generators)
+    assert T.is_isomorphism()
 
     F, a, b = free_group("a, b")
     E, c, d = free_group("c, d")
@@ -102,7 +107,12 @@ def test_isomorphisms():
     assert is_isomorphic(G, H)
 
 
-def test_check_homomorphism():
+    # Test for inverted generator handling in _image
+    a = Permutation(1,2,3,4)
+    b = Permutation(1,3)
+    G = PermutationGroup([a, b])
+    T = homomorphism(G, G, [a, b], [a**-1, b**-1])
+    assert T.is_homomorphism()
     a = Permutation(1,2,3,4)
     b = Permutation(1,3)
     G = PermutationGroup([a, b])

EOF_114329324912
PYTHONWARNINGS='ignore::UserWarning,ignore::SyntaxWarning' bin/test -C --verbose sympy/combinatorics/tests/test_homomorphisms.py
git checkout 809c53c077485ca48a206cee78340389cb83b7f1 sympy/combinatorics/tests/test_homomorphisms.py
