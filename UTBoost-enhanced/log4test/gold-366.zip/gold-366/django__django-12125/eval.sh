#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 89d41cba392b759732ba9f1db4ff29ed47da6a56
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 89d41cba392b759732ba9f1db4ff29ed47da6a56 tests/migrations/test_writer.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/migrations/test_writer.py b/tests/migrations/test_writer.py
index e62f7b0..51d4ca5 100644
--- a/tests/migrations/test_writer.py
+++ b/tests/migrations/test_writer.py
@@ -179,6 +179,39 @@ class OperationWriterTests(SimpleTestCase):
             '),'
         )
 
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
+
 
 class WriterTests(SimpleTestCase):
     """
@@ -229,12 +262,78 @@ class WriterTests(SimpleTestCase):
             ("Decimal('1.3')", {'from decimal import Decimal'})
         )
 
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
+
         self.assertSerializedEqual(Money('1.3'))
         self.assertSerializedResultEqual(
             Money('1.3'),
             ("migrations.test_writer.Money('1.3')", {'import migrations.test_writer'})
         )
 
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
+
     def test_serialize_constants(self):
         self.assertSerializedEqual(None)
         self.assertSerializedEqual(True)
@@ -270,6 +369,39 @@ class WriterTests(SimpleTestCase):
             ("[list, tuple, dict, set, frozenset]", set())
         )
 
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
+
     def test_serialize_lazy_objects(self):
         pattern = re.compile(r'^foo$')
         lazy_pattern = SimpleLazyObject(lambda: pattern)
@@ -280,18 +412,150 @@ class WriterTests(SimpleTestCase):
             TextEnum.A,
             ("migrations.test_writer.TextEnum['A']", {'import migrations.test_writer'})
         )
+
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
         self.assertSerializedResultEqual(
             TextTranslatedEnum.A,
             ("migrations.test_writer.TextTranslatedEnum['A']", {'import migrations.test_writer'})
         )
+
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
         self.assertSerializedResultEqual(
             BinaryEnum.A,
             ("migrations.test_writer.BinaryEnum['A']", {'import migrations.test_writer'})
         )
+
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
         self.assertSerializedResultEqual(
             IntEnum.B,
             ("migrations.test_writer.IntEnum['B']", {'import migrations.test_writer'})
         )
+
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
         self.assertSerializedResultEqual(
             self.NestedEnum.A,
             (
@@ -299,6 +563,39 @@ class WriterTests(SimpleTestCase):
                 {'import migrations.test_writer'},
             ),
         )
+
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
         self.assertSerializedEqual(self.NestedEnum.A)
 
         field = models.CharField(default=TextEnum.B, choices=[(m.value, m) for m in TextEnum])
@@ -310,10 +607,76 @@ class WriterTests(SimpleTestCase):
             "('value-b', migrations.test_writer.TextEnum['B'])], "
             "default=migrations.test_writer.TextEnum['B'])"
         )
+
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
         field = models.CharField(
             default=TextTranslatedEnum.A,
             choices=[(m.value, m) for m in TextTranslatedEnum],
         )
+
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
         string = MigrationWriter.serialize(field)[0]
         self.assertEqual(
             string,
@@ -322,6 +685,39 @@ class WriterTests(SimpleTestCase):
             "('value-b', migrations.test_writer.TextTranslatedEnum['B'])], "
             "default=migrations.test_writer.TextTranslatedEnum['A'])"
         )
+
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
         field = models.CharField(default=BinaryEnum.B, choices=[(m.value, m) for m in BinaryEnum])
         string = MigrationWriter.serialize(field)[0]
         self.assertEqual(
@@ -331,6 +727,39 @@ class WriterTests(SimpleTestCase):
             "(b'value-b', migrations.test_writer.BinaryEnum['B'])], "
             "default=migrations.test_writer.BinaryEnum['B'])"
         )
+
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
         field = models.IntegerField(default=IntEnum.A, choices=[(m.value, m) for m in IntEnum])
         string = MigrationWriter.serialize(field)[0]
         self.assertEqual(
@@ -341,6 +770,39 @@ class WriterTests(SimpleTestCase):
             "default=migrations.test_writer.IntEnum['A'])"
         )
 
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
+
     def test_serialize_choices(self):
         class TextChoices(models.TextChoices):
             A = 'A', 'A value'
@@ -360,6 +822,39 @@ class WriterTests(SimpleTestCase):
             DateChoices.DATE_1,
             ('datetime.date(1969, 7, 20)', {'import datetime'}),
         )
+
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
         field = models.CharField(default=TextChoices.B, choices=TextChoices.choices)
         string = MigrationWriter.serialize(field)[0]
         self.assertEqual(
@@ -367,12 +862,78 @@ class WriterTests(SimpleTestCase):
             "models.CharField(choices=[('A', 'A value'), ('B', 'B value')], "
             "default='B')",
         )
+
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
         field = models.IntegerField(default=IntegerChoices.B, choices=IntegerChoices.choices)
         string = MigrationWriter.serialize(field)[0]
         self.assertEqual(
             string,
             "models.IntegerField(choices=[(1, 'One'), (2, 'Two')], default=2)",
         )
+
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
         field = models.DateField(default=DateChoices.DATE_2, choices=DateChoices.choices)
         string = MigrationWriter.serialize(field)[0]
         self.assertEqual(
@@ -383,6 +944,39 @@ class WriterTests(SimpleTestCase):
             "default=datetime.date(1969, 11, 19))"
         )
 
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
+
     def test_serialize_uuid(self):
         self.assertSerializedEqual(uuid.uuid1())
         self.assertSerializedEqual(uuid.uuid4())
@@ -393,11 +987,77 @@ class WriterTests(SimpleTestCase):
             uuid_a,
             ("uuid.UUID('5c859437-d061-4847-b3f7-e6b78852f8c8')", {'import uuid'})
         )
+
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
         self.assertSerializedResultEqual(
             uuid_b,
             ("uuid.UUID('c7853ec1-2ea3-4359-b02d-b54e8f1bcee2')", {'import uuid'})
         )
 
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
+
         field = models.UUIDField(choices=((uuid_a, 'UUID A'), (uuid_b, 'UUID B')), default=uuid_a)
         string = MigrationWriter.serialize(field)[0]
         self.assertEqual(
@@ -408,6 +1068,39 @@ class WriterTests(SimpleTestCase):
             "default=uuid.UUID('5c859437-d061-4847-b3f7-e6b78852f8c8'))"
         )
 
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
+
     def test_serialize_functions(self):
         with self.assertRaisesMessage(ValueError, 'Cannot serialize function: lambda'):
             self.assertSerializedEqual(lambda x: 42)
@@ -430,6 +1123,39 @@ class WriterTests(SimpleTestCase):
             datetime.datetime(2014, 1, 1, 1, 1),
             ("datetime.datetime(2014, 1, 1, 1, 1)", {'import datetime'})
         )
+
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
         self.assertSerializedResultEqual(
             datetime.datetime(2012, 1, 1, 1, 1, tzinfo=utc),
             (
@@ -438,18 +1164,117 @@ class WriterTests(SimpleTestCase):
             )
         )
 
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
+
     def test_serialize_fields(self):
         self.assertSerializedFieldEqual(models.CharField(max_length=255))
         self.assertSerializedResultEqual(
             models.CharField(max_length=255),
             ("models.CharField(max_length=255)", {"from django.db import models"})
         )
+
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
         self.assertSerializedFieldEqual(models.TextField(null=True, blank=True))
         self.assertSerializedResultEqual(
             models.TextField(null=True, blank=True),
             ("models.TextField(blank=True, null=True)", {'from django.db import models'})
         )
 
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
+
     def test_serialize_settings(self):
         self.assertSerializedEqual(SettingsReference(settings.AUTH_USER_MODEL, "AUTH_USER_MODEL"))
         self.assertSerializedResultEqual(
@@ -457,12 +1282,78 @@ class WriterTests(SimpleTestCase):
             ("settings.AUTH_USER_MODEL", {"from django.conf import settings"})
         )
 
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
+
     def test_serialize_iterators(self):
         self.assertSerializedResultEqual(
             ((x, x * x) for x in range(3)),
             ("((0, 0), (1, 1), (2, 4))", set())
         )
 
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
+
     def test_serialize_compiled_regex(self):
         """
         Make sure compiled regex can be serialized.
@@ -558,6 +1449,39 @@ class WriterTests(SimpleTestCase):
             FoodQuerySet.as_manager(),
             ('migrations.models.FoodQuerySet.as_manager()', {'import migrations.models'})
         )
+
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
         self.assertSerializedEqual(FoodManager('a', 'b'))
         self.assertSerializedEqual(FoodManager('x', 'y', c=3, d=4))
 
@@ -661,6 +1585,39 @@ class WriterTests(SimpleTestCase):
             result['custom_migration_operations'].more_operations.TestOperation
         )
 
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
+
     def test_sorted_imports(self):
         """
         #24155 - Tests ordering of imports.
@@ -681,6 +1638,39 @@ class WriterTests(SimpleTestCase):
             output
         )
 
+    def test_serialize_nested_class_issue(self):
+        class Outer:
+            class Inner(models.CharField):
+                pass
+
+        class A(models.Model):
+            field = Outer.Inner(max_length=20)
+
+        field = A._meta.get_field('field')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "test_writer.Outer.Inner(max_length=20)"
+        )
+
+    def test_serialize_nested_enum_issue(self):
+        import enum
+
+        class Thing(models.Model):
+            @enum.unique
+            class State(enum.Enum):
+                on = 'on'
+                off = 'off'
+
+            state = EnumField(enum=State)
+
+        field = Thing._meta.get_field('state')
+        string = MigrationWriter.serialize(field)[0]
+        self.assertEqual(
+            string,
+            "enumfields.fields.EnumField(enum=test_writer.Thing.State, max_length=10)"
+        )
+
     def test_migration_file_header_comments(self):
         """
         Test comments at top of file.
@@ -746,4 +1736,4 @@ class WriterTests(SimpleTestCase):
 
     def test_register_non_serializer(self):
         with self.assertRaisesMessage(ValueError, "'TestModel1' must inherit from 'BaseSerializer'."):
-            MigrationWriter.register_serializer(complex, TestModel1)
+            MigrationWriter.register_serializer(complex, TestModel1)

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 migrations.test_writer
git checkout 89d41cba392b759732ba9f1db4ff29ed47da6a56 tests/migrations/test_writer.py
