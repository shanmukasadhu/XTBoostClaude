#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff cab2d93076d0cca7c53fac885f927dde3e2a5fec
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .[test]
git checkout cab2d93076d0cca7c53fac885f927dde3e2a5fec tests/test_build_gettext.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/test_build_gettext.py b/tests/test_build_gettext.py
index a6fc946..f3ab915 100644
--- a/tests/test_build_gettext.py
+++ b/tests/test_build_gettext.py
@@ -1,3 +1,41 @@
+
+def test_Catalog_no_duplicate_locations():
+    catalog = Catalog()
+    # Add the same message from the same location multiple times
+    catalog.add('duplicate_test', MsgOrigin('/path/to/file', 10))
+    catalog.add('duplicate_test', MsgOrigin('/path/to/file', 10))
+    catalog.add('duplicate_test', MsgOrigin('/path/to/file', 10))
+
+    # Add the same message from different locations
+    catalog.add('duplicate_test', MsgOrigin('/path/to/file', 20))
+    catalog.add('duplicate_test', MsgOrigin('/another/path/to/file', 10))
+
+    # Extract messages from catalog
+    messages = list(catalog)
+
+    assert len(messages) == 1
+    assert messages[0].text == 'duplicate_test'
+    assert messages[0].locations == [
+        ('/path/to/file', 10),
+        ('/path/to/file', 20),
+        ('/another/path/to/file', 10)
+    ]
+
+def test_Catalog_multiple_messages():
+    catalog = Catalog()
+    # Add different messages
+    catalog.add('message_one', MsgOrigin('/path/to/file', 1))
+    catalog.add('message_two', MsgOrigin('/path/to/file', 2))
+
+    # Extract messages from catalog
+    messages = list(catalog)
+
+    assert len(messages) == 2
+    assert messages[0].text == 'message_one'
+    assert messages[0].locations == [('/path/to/file', 1)]
+    assert messages[1].text == 'message_two'
+    assert messages[1].locations == [('/path/to/file', 2)]
+
 """Test the build process with gettext builder with the test root."""
 
 import gettext
@@ -8,6 +46,7 @@ from subprocess import PIPE, CalledProcessError
 
 import pytest
 
+from sphinx.builders.gettext import Catalog, MsgOrigin
 from sphinx.util.osutil import cd
 
 

EOF_114329324912
tox --current-env -epy39 -v -- tests/test_build_gettext.py
git checkout cab2d93076d0cca7c53fac885f927dde3e2a5fec tests/test_build_gettext.py
