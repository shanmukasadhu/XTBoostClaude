#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff f30284ef926ebaf04b176f21b421e2dffc679792
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .[test]
git checkout f30284ef926ebaf04b176f21b421e2dffc679792 tests/test_build_linkcheck.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/test_build_linkcheck.py b/tests/test_build_linkcheck.py
index 5b1b2ed..ff3fa9e 100644
--- a/tests/test_build_linkcheck.py
+++ b/tests/test_build_linkcheck.py
@@ -8,6 +8,42 @@
     :license: BSD, see LICENSE for details.
 """
 
+@pytest.mark.sphinx('linkcheck', testroot='linkcheck', freshenv=True)
+def test_local_links(app, status, warning):
+    app.builder.build_all()
+
+    assert (app.outdir / 'output.txt').exists()
+    content = (app.outdir / 'output.txt').read_text()
+
+    # Check for local link handling
+    assert "local - doesntexist" in content
+    assert "broken    https://lkfqhlkghflkhs" in content
+    assert len(content.splitlines()) == 7
+
+@pytest.mark.sphinx('linkcheck', testroot='linkcheck', freshenv=True)
+def test_local_links_json(app, status, warning):
+    app.builder.build_all()
+
+    assert (app.outdir / 'output.json').exists()
+    content = (app.outdir / 'output.json').read_text()
+
+    rows = [json.loads(x) for x in content.splitlines()]
+    rowsby = {row["uri"]: row for row in rows}
+
+    # Check for local link in JSON
+    assert rowsby["doesntexist"] == {
+        'filename': 'index.rst',
+        'lineno': 5,
+        'status': 'local',
+        'code': 0,
+        'uri': 'doesntexist',
+        'info': ''
+    }
+
+    # Check for broken external link in JSON
+    assert rowsby["https://lkfqhlkghflkhs"]["status"] == 'broken'
+    assert len(content.splitlines()) == 9
+
 import json
 import re
 from unittest import mock

EOF_114329324912
tox --current-env -epy39 -v -- tests/test_build_linkcheck.py
git checkout f30284ef926ebaf04b176f21b421e2dffc679792 tests/test_build_linkcheck.py
