#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff eb16c7260e573ec513d84cb586d96bdf508f3173
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout eb16c7260e573ec513d84cb586d96bdf508f3173 tests/user_commands/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/user_commands/tests.py b/tests/user_commands/tests.py
index b016284..5fe53b4 100644
--- a/tests/user_commands/tests.py
+++ b/tests/user_commands/tests.py
@@ -253,8 +253,38 @@ class CommandRunTests(AdminScriptTestCase):
         self.assertNoOutput(err)
         self.assertEqual(out.strip(), 'Set foo')
 
+    def test_skip_checks_flag_enabled(self):
+        """
+        Test --skip-checks flag to ensure system checks are skipped.
+        """
+        self.write_settings('settings.py', apps=['django.contrib.staticfiles', 'user_commands'], sdict={
+            'STATICFILES_DIRS': '"foo"',
+        })
+        out, err = self.run_manage(['set_option', '--skip-checks', '--set', 'foo'])
+        self.assertNoOutput(err)
+        self.assertEqual(out.strip(), 'Set foo')
 
-class UtilsTests(SimpleTestCase):
+    def test_skip_checks_flag_disabled(self):
+        """
+        Test running command without --skip-checks to ensure system checks are not skipped.
+        """
+        self.write_settings('settings.py', apps=['django.contrib.staticfiles', 'user_commands'], sdict={
+            'STATICFILES_DIRS': '"foo"',
+        })
+        out, err = self.run_manage(['set_option', '--set', 'foo'])
+        self.assertIn('SystemCheckError', err)
+        self.assertNotIn('Set foo', out)
+
+    def test_skip_checks_flag_with_other_flags(self):
+        """
+        Test --skip-checks flag in combination with other flags.
+        """
+        self.write_settings('settings.py', apps=['django.contrib.staticfiles', 'user_commands'], sdict={
+            'STATICFILES_DIRS': '"foo"',
+        })
+        out, err = self.run_manage(['set_option', '--skip-checks', '--no-color', '--set', 'foo'])
+        self.assertNoOutput(err)
+        self.assertEqual(out.strip(), 'Set foo')
 
     def test_no_existent_external_program(self):
         msg = 'Error executing a_42_command_that_doesnt_exist_42'

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 user_commands.tests
git checkout eb16c7260e573ec513d84cb586d96bdf508f3173 tests/user_commands/tests.py
