#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 6f54459aa0248bf1467ad12ee6333d8bc924a642
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 6f54459aa0248bf1467ad12ee6333d8bc924a642 sympy/combinatorics/tests/test_perm_groups.py
git apply -v - <<'EOF_114329324912'
diff --git a/sympy/combinatorics/tests/test_perm_groups.py b/sympy/combinatorics/tests/test_perm_groups.py
index 3f4bb48..8eb6904 100644
--- a/sympy/combinatorics/tests/test_perm_groups.py
+++ b/sympy/combinatorics/tests/test_perm_groups.py
@@ -895,13 +895,37 @@ def test_sylow_subgroup():
         else:
             assert len(ls) == length
 
+    G = DihedralGroup(18)
+    S = G.sylow_subgroup(2)
+    assert S.order() == 4
+
+    G = DihedralGroup(50)
+    S = G.sylow_subgroup(2)
+    assert S.order() == 4
+
     G = SymmetricGroup(100)
     S = G.sylow_subgroup(3)
+    G = DihedralGroup(36)
+    S = G.sylow_subgroup(3)
+    assert S.order() == 9
+
+    G = DihedralGroup(20)
+    S = G.sylow_subgroup(5)
+    assert S.order() == 5
+
     assert G.order() % S.order() == 0
     assert G.order()/S.order() % 3 > 0
 
     G = AlternatingGroup(100)
     S = G.sylow_subgroup(2)
+    G = DihedralGroup(36)
+    S = G.sylow_subgroup(3)
+    assert S.order() == 9
+
+    G = DihedralGroup(20)
+    S = G.sylow_subgroup(5)
+    assert S.order() == 5
+
     assert G.order() % S.order() == 0
     assert G.order()/S.order() % 2 > 0
 

EOF_114329324912
PYTHONWARNINGS='ignore::UserWarning,ignore::SyntaxWarning' bin/test -C --verbose sympy/combinatorics/tests/test_perm_groups.py
git checkout 6f54459aa0248bf1467ad12ee6333d8bc924a642 sympy/combinatorics/tests/test_perm_groups.py
