#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 273a8b25620467c1e5686aa8d2a1dbb8c02c78d0
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 273a8b25620467c1e5686aa8d2a1dbb8c02c78d0 tests/test_self.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/test_self.py b/tests/test_self.py
index 9123ae4..9cb436e 100644
--- a/tests/test_self.py
+++ b/tests/test_self.py
@@ -1233,6 +1233,27 @@ class TestRunTC:
             expected_output="No such file or directory",
         )
 
+    def test_recursive_ignore(self):
+        """Tests if `--ignore` flag works in recursive mode."""
+        self._runtest(
+            [join(HERE, "regrtest_data", "directory"), "--recursive=y", "--ignore=ignored_subdirectory"],
+            code=0,
+        )
+
+    def test_recursive_ignore_patterns(self):
+        """Tests if `--ignore-patterns` flag works in recursive mode."""
+        self._runtest(
+            [join(HERE, "regrtest_data", "directory"), "--recursive=y", "--ignore-patterns=ignored_.*"],
+            code=0,
+        )
+
+    def test_recursive_ignore_paths(self):
+        """Tests if `--ignore-paths` flag works in recursive mode."""
+        self._runtest(
+            [join(HERE, "regrtest_data", "directory"), "--recursive=y", "--ignore-paths=.*ignored.*"],
+            code=0,
+        )
+
     def test_recursive(self):
         self._runtest(
             [join(HERE, "regrtest_data", "directory", "subdirectory"), "--recursive=y"],

EOF_114329324912
pytest -rA tests/lint/unittest_lint.py tests/regrtest_data/directory/ignored_subdirectory/failing.py tests/test_self.py
git checkout 273a8b25620467c1e5686aa8d2a1dbb8c02c78d0 tests/test_self.py
