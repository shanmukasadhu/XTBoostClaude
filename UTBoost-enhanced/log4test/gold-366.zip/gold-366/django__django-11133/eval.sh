#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 879cc3da6249e920b8d54518a0ae06de835d7373
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 879cc3da6249e920b8d54518a0ae06de835d7373 tests/httpwrappers/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/httpwrappers/tests.py b/tests/httpwrappers/tests.py
index 32aaf3b..110e06e 100644
--- a/tests/httpwrappers/tests.py
+++ b/tests/httpwrappers/tests.py
@@ -413,6 +413,10 @@ class HttpResponseTests(unittest.TestCase):
         self.assertEqual(list(i), [b'abc'])
         self.assertEqual(list(i), [])
 
+    def test_memoryview_content(self):
+        r = HttpResponse(memoryview(b'memoryview'))
+        self.assertEqual(r.content, b'memoryview')
+
     def test_lazy_content(self):
         r = HttpResponse(lazystr('helloworld'))
         self.assertEqual(r.content, b'helloworld')

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 httpwrappers.tests
git checkout 879cc3da6249e920b8d54518a0ae06de835d7373 tests/httpwrappers/tests.py
