#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff f8ffce6d44127d4ea7d6491262ab30046b03294b
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout f8ffce6d44127d4ea7d6491262ab30046b03294b lib/matplotlib/tests/test_axes.py
git apply -v - <<'EOF_114329324912'
diff --git a/lib/matplotlib/tests/test_axes.py b/lib/matplotlib/tests/test_axes.py
index c24a832..29fd383 100644
--- a/lib/matplotlib/tests/test_axes.py
+++ b/lib/matplotlib/tests/test_axes.py
@@ -7801,6 +7801,44 @@ def test_xtickcolor_is_not_xticklabelcolor():
         assert tick.label1.get_color() == 'blue'
 
 
+def test_xaxis_offsetText_color():
+    plt.rcParams['xtick.labelcolor'] = 'blue'
+    ax = plt.axes()
+    assert ax.xaxis.offsetText.get_color() == 'blue'
+
+    plt.rcParams['xtick.color'] = 'yellow'
+    plt.rcParams['xtick.labelcolor'] = 'inherit'
+    ax = plt.axes()
+    assert ax.xaxis.offsetText.get_color() == 'yellow'
+
+def test_yaxis_offsetText_color():
+    plt.rcParams['ytick.labelcolor'] = 'green'
+    ax = plt.axes()
+    assert ax.yaxis.offsetText.get_color() == 'green'
+
+    plt.rcParams['ytick.color'] = 'red'
+    plt.rcParams['ytick.labelcolor'] = 'inherit'
+    ax = plt.axes()
+    assert ax.yaxis.offsetText.get_color() == 'red'
+
+def test_xaxis_and_yaxis_offsetText_default_color():
+    ax = plt.axes()
+    assert ax.xaxis.offsetText.get_color() == 'black'
+    assert ax.yaxis.offsetText.get_color() == 'black'
+
+def test_xaxis_and_yaxis_offsetText_custom_colors():
+    plt.rcParams['xtick.color'] = 'purple'
+    plt.rcParams['xtick.labelcolor'] = 'inherit'
+    plt.rcParams['ytick.color'] = 'orange'
+    plt.rcParams['ytick.labelcolor'] = 'inherit'
+    ax = plt.axes()
+    assert ax.xaxis.offsetText.get_color() == 'purple'
+    assert ax.yaxis.offsetText.get_color() == 'orange'
+
+import matplotlib.pyplot as plt
+import pytest
+import matplotlib as mpl
+
 def test_ytickcolor_is_not_yticklabelcolor():
     plt.rcParams['ytick.color'] = 'yellow'
     plt.rcParams['ytick.labelcolor'] = 'blue'

EOF_114329324912
pytest -rA lib/matplotlib/tests/test_axes.py
git checkout f8ffce6d44127d4ea7d6491262ab30046b03294b lib/matplotlib/tests/test_axes.py
