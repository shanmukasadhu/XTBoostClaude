#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff cb383753c0e0eb52306e1024d32a782549c27e61
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout cb383753c0e0eb52306e1024d32a782549c27e61 
git apply -v - <<'EOF_114329324912'

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 queries.models queries.tests
git checkout cb383753c0e0eb52306e1024d32a782549c27e61 
