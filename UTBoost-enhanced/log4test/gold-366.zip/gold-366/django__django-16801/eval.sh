#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 3b62d8c83e3e48d2ed61cfa32a61c56d9e030293
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 3b62d8c83e3e48d2ed61cfa32a61c56d9e030293 tests/model_fields/test_imagefield.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/model_fields/test_imagefield.py b/tests/model_fields/test_imagefield.py
index 9bf7f7d..eea7b9c 100644
--- a/tests/model_fields/test_imagefield.py
+++ b/tests/model_fields/test_imagefield.py
@@ -319,8 +319,37 @@ class ImageFieldTwoDimensionsTests(ImageFieldTestMixin, TestCase):
         # Dimensions were recalculated, and hence file should have opened.
         self.assertIs(p.mugshot.was_opened, True)
 
+    def test_post_init_not_connected(self):
+        person_model_id = id(self.PersonModel)
+        self.assertNotIn(
+            person_model_id,
+            [sender_id for (_, sender_id), *_ in signals.post_init.receivers],
+        )
 
+
+@skipIf(Image is None, "Pillow is required to test ImageField")
 @skipIf(Image is None, "Pillow is required to test ImageField")
+class ImageFieldSignalTests(TestCase):
+    """
+    Test to ensure no post_init signal is connected when width/height fields are not used.
+    """
+
+    def setUp(self):
+        # Define a simple model with an ImageField and no dimension fields
+        class SimpleModel(models.Model):
+            image = models.ImageField(upload_to='images/')
+
+        self.SimpleModel = SimpleModel
+
+    def test_post_init_signal_not_connected(self):
+        simple_model_id = id(self.SimpleModel)
+        self.assertNotIn(
+            simple_model_id,
+            [sender_id for (_, sender_id), *_ in signals.post_init.receivers],
+        )
+
+from django.db.models import signals
+
 class ImageFieldNoDimensionsTests(ImageFieldTwoDimensionsTests):
     """
     Tests behavior of an ImageField with no dimension fields.
@@ -328,6 +357,13 @@ class ImageFieldNoDimensionsTests(ImageFieldTwoDimensionsTests):
 
     PersonModel = Person
 
+    def test_post_init_not_connected(self):
+        person_model_id = id(self.PersonModel)
+        self.assertNotIn(
+            person_model_id,
+            [sender_id for (_, sender_id), *_ in signals.post_init.receivers],
+        )
+
 
 @skipIf(Image is None, "Pillow is required to test ImageField")
 class ImageFieldOneDimensionTests(ImageFieldTwoDimensionsTests):

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 model_fields.test_imagefield
git checkout 3b62d8c83e3e48d2ed61cfa32a61c56d9e030293 tests/model_fields/test_imagefield.py
