#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 06909fe084f87a65459a83bd69d7cdbe4fce9a7c
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 06909fe084f87a65459a83bd69d7cdbe4fce9a7c tests/forms_tests/tests/test_forms.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/forms_tests/tests/test_forms.py b/tests/forms_tests/tests/test_forms.py
index 95afc0d..6efb443 100644
--- a/tests/forms_tests/tests/test_forms.py
+++ b/tests/forms_tests/tests/test_forms.py
@@ -3672,7 +3672,38 @@ Good luck picking a username that doesn&#x27;t already exist.</p>
             '<input type="hidden" name="data" id="id_data"></td></tr>'
         )
 
-    def test_field_named_data(self):
+import copy
+from django.forms import CharField, Form
+from django.test import SimpleTestCase
+
+class FormFieldTests(SimpleTestCase):
+
+    def test_field_deep_copy_error_messages(self):
+        class CustomCharField(CharField):
+            def __init__(self, **kwargs):
+                kwargs['error_messages'] = {'invalid': 'Form custom error message.'}
+                super().__init__(**kwargs)
+
+        field = CustomCharField()
+        field_copy = copy.deepcopy(field)
+        self.assertIsInstance(field_copy, CustomCharField)
+        self.assertIsNot(field_copy.error_messages, field.error_messages)
+
+    def test_field_deep_copy_error_messages_modification(self):
+        class CustomCharField(CharField):
+            def __init__(self, **kwargs):
+                kwargs['error_messages'] = {'invalid': 'Form custom error message.'}
+                super().__init__(**kwargs)
+
+        field = CustomCharField()
+        field_copy = copy.deepcopy(field)
+
+        # Modify error message in the copy
+        field_copy.error_messages['invalid'] = 'Modified error message.'
+        
+        # Ensure original is not affected
+        self.assertEqual(field.error_messages['invalid'], 'Form custom error message.')
+        self.assertEqual(field_copy.error_messages['invalid'], 'Modified error message.')
         class DataForm(Form):
             data = CharField(max_length=10)
 

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 forms_tests.tests.test_forms
git checkout 06909fe084f87a65459a83bd69d7cdbe4fce9a7c tests/forms_tests/tests/test_forms.py
