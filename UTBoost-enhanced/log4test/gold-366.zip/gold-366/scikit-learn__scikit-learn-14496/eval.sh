#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff d49a6f13af2f22228d430ac64ac2b518937800d0
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -v --no-use-pep517 --no-build-isolation -e .
git checkout d49a6f13af2f22228d430ac64ac2b518937800d0 sklearn/cluster/tests/test_optics.py
git apply -v - <<'EOF_114329324912'
diff --git a/sklearn/cluster/tests/test_optics.py b/sklearn/cluster/tests/test_optics.py
index 6c9dac3..caf2b93 100644
--- a/sklearn/cluster/tests/test_optics.py
+++ b/sklearn/cluster/tests/test_optics.py
@@ -77,8 +77,27 @@ def test_the_extract_xi_labels(ordering, clusters, expected):
 
     assert_array_equal(labels, expected)
 
-
-def test_extract_xi():
+from sklearn.datasets import make_blobs
+from sklearn.utils import shuffle
+from sklearn.cluster import OPTICS
+import numpy as np
+from numpy.testing import assert_array_equal
+
+def test_float_min_samples():
+    # Generate sample data
+    X, _ = make_blobs(n_samples=100, centers=3, random_state=42)
+
+    # Expected behavior with min_samples as a float
+    try:
+        clust = OPTICS(min_samples=0.1, min_cluster_size=0.08,
+                       max_eps=20, cluster_method='xi',
+                       xi=0.4).fit(X)
+        print("Test Passed: No errors with float min_samples.")
+    except TypeError as e:
+        print(f"Test Failed: {e}")
+
+    # Verify that the labels are integers
+    assert np.issubdtype(clust.labels_.dtype, np.integer), "Labels are not integers"
     # small and easy test (no clusters around other clusters)
     # but with a clear noise data.
     rng = np.random.RandomState(0)

EOF_114329324912
pytest -rA sklearn/cluster/tests/test_optics.py
git checkout d49a6f13af2f22228d430ac64ac2b518937800d0 sklearn/cluster/tests/test_optics.py
