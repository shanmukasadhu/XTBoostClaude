#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff a85a0747c54bac75e9c3b2fe436b105ea029d6cf
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .[test] --verbose
git checkout a85a0747c54bac75e9c3b2fe436b105ea029d6cf astropy/io/fits/tests/test_header.py
git apply -v - <<'EOF_114329324912'
diff --git a/astropy/io/fits/tests/test_header.py b/astropy/io/fits/tests/test_header.py
index a2103c6..1109e6c 100644
--- a/astropy/io/fits/tests/test_header.py
+++ b/astropy/io/fits/tests/test_header.py
@@ -79,6 +79,33 @@ class TestHeaderFunctions(FitsTestCase):
         assert header['B'] == 'B'
         assert header.comments['B'] == 'C'
 
+    def test_card_from_bytes_encoding(self):
+        """Test loading a Card from a `bytes` object with different encoding."""
+        
+        # Default encoding assumed to be 'latin-1'
+        c = fits.Card.fromstring(b"XYZ     = 'xyz'")
+        assert c.keyword == 'XYZ'
+        assert c.value == 'xyz'
+
+        # Explicitly decode using UTF-8
+        c = fits.Card.fromstring("PQR     = 'pqr'".encode('utf-8').decode('utf-8'))
+        assert c.keyword == 'PQR'
+        assert c.value == 'pqr'
+
+    def test_header_fromstring_unicode(self):
+        """Test reading a Header from a unicode string."""
+        
+        header_str = "SIMPLE  =                    T / file does conform to FITS standard"
+        hdr = fits.Header.fromstring(header_str)
+        assert hdr['SIMPLE'] is True
+        
+    def test_header_fromstring_bytes_with_sep(self):
+        """Test reading a Header from a `bytes` string with separator."""
+        
+        header_bytes = b"SIMPLE  =                    T / file does conform to FITS standard\nEND"
+        hdr = fits.Header.fromstring(header_bytes, sep='\n')
+        assert hdr['SIMPLE'] is True
+
     def test_card_constructor_default_args(self):
         """Test Card constructor with default argument values."""
 

EOF_114329324912
pytest -rA astropy/io/fits/tests/test_header.py
git checkout a85a0747c54bac75e9c3b2fe436b105ea029d6cf astropy/io/fits/tests/test_header.py
