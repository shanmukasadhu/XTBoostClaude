#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 179ee13eb37348cd87169a198aec18fedccc8668
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 179ee13eb37348cd87169a198aec18fedccc8668 tests/staticfiles_tests/test_storage.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/staticfiles_tests/test_storage.py b/tests/staticfiles_tests/test_storage.py
index 76f3d3e..07276e5 100644
--- a/tests/staticfiles_tests/test_storage.py
+++ b/tests/staticfiles_tests/test_storage.py
@@ -205,6 +205,28 @@ class TestHashedFiles:
         self.assertIn(os.path.join('test', 'nonascii.css'), stats['post_processed'])
         self.assertPostCondition()
 
+    def test_no_duplicate_yield(self):
+        """
+        Test to ensure that no file is yielded multiple times during post-processing.
+        """
+        collectstatic_cmd = CollectstaticCommand()
+        collectstatic_cmd.set_options(clear=False, dry_run=False, post_process=True)
+        stats = collectstatic_cmd.collect()
+        post_processed_files = stats['post_processed']
+        # Check if all post-processed files are unique
+        self.assertCountEqual(post_processed_files, set(post_processed_files))
+
+    def test_no_intermediate_files_yielded(self):
+        """
+        Test to ensure that intermediate files are not yielded during post-processing.
+        """
+        collectstatic_cmd = CollectstaticCommand()
+        collectstatic_cmd.set_options(clear=False, dry_run=False, post_process=True)
+        stats = collectstatic_cmd.collect()
+        # Possible intermediate file example based on issue description
+        unexpected_file = os.path.join('admin', 'css', 'base.5af66c1b1797.css')
+        self.assertNotIn(unexpected_file, stats['post_processed'])
+
     def test_css_import_case_insensitive(self):
         relpath = self.hashed_file_path("cached/styles_insensitive.css")
         self.assertEqual(relpath, "cached/styles_insensitive.3fa427592a53.css")
@@ -214,6 +236,28 @@ class TestHashedFiles:
             self.assertIn(b"other.d41d8cd98f00.css", content)
         self.assertPostCondition()
 
+    def test_no_duplicate_yield(self):
+        """
+        Test to ensure that no file is yielded multiple times during post-processing.
+        """
+        collectstatic_cmd = CollectstaticCommand()
+        collectstatic_cmd.set_options(clear=False, dry_run=False, post_process=True)
+        stats = collectstatic_cmd.collect()
+        post_processed_files = stats['post_processed']
+        # Check if all post-processed files are unique
+        self.assertCountEqual(post_processed_files, set(post_processed_files))
+
+    def test_no_intermediate_files_yielded(self):
+        """
+        Test to ensure that intermediate files are not yielded during post-processing.
+        """
+        collectstatic_cmd = CollectstaticCommand()
+        collectstatic_cmd.set_options(clear=False, dry_run=False, post_process=True)
+        stats = collectstatic_cmd.collect()
+        # Possible intermediate file example based on issue description
+        unexpected_file = os.path.join('admin', 'css', 'base.5af66c1b1797.css')
+        self.assertNotIn(unexpected_file, stats['post_processed'])
+
     @override_settings(
         STATICFILES_DIRS=[os.path.join(TEST_ROOT, 'project', 'faulty')],
         STATICFILES_FINDERS=['django.contrib.staticfiles.finders.FileSystemFinder'],

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 staticfiles_tests.test_storage
git checkout 179ee13eb37348cd87169a198aec18fedccc8668 tests/staticfiles_tests/test_storage.py
