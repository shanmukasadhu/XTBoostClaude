#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 7ee9ceb71e868944a46e1ff00b506772a53a4f1d
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 7ee9ceb71e868944a46e1ff00b506772a53a4f1d tests/test_blueprints.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/test_blueprints.py b/tests/test_blueprints.py
index 94a27b3..73365c9 100644
--- a/tests/test_blueprints.py
+++ b/tests/test_blueprints.py
@@ -244,6 +244,27 @@ def test_default_static_max_age(app):
         app.config["SEND_FILE_MAX_AGE_DEFAULT"] = max_age_default
 
 
+def test_empty_name_not_allowed(app, client):
+    with pytest.raises(ValueError):
+        flask.Blueprint("", __name__)
+
+def test_whitespace_name_not_allowed(app, client):
+    with pytest.raises(ValueError):
+        flask.Blueprint("   ", __name__)
+
+def test_none_name_not_allowed(app, client):
+    with pytest.raises(ValueError):
+        flask.Blueprint(None, __name__)
+
+def test_valid_name_allowed(app, client):
+    try:
+        bp = flask.Blueprint("valid_name", __name__)
+    except ValueError:
+        pytest.fail("Blueprint raised ValueError unexpectedly!")
+
+import pytest
+import flask
+
 def test_templates_list(test_apps):
     from blueprintapp import app
 

EOF_114329324912
pytest -rA tests/test_blueprints.py
git checkout 7ee9ceb71e868944a46e1ff00b506772a53a4f1d tests/test_blueprints.py
