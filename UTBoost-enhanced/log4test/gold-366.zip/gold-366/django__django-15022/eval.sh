#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff e1d673c373a7d032060872b690a92fc95496612e
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout e1d673c373a7d032060872b690a92fc95496612e tests/admin_changelist/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/admin_changelist/tests.py b/tests/admin_changelist/tests.py
index e1920cd..b92bb6a 100644
--- a/tests/admin_changelist/tests.py
+++ b/tests/admin_changelist/tests.py
@@ -171,7 +171,50 @@ class ChangeListTests(TestCase):
         row_html = build_tbody_html(new_child.id, link, '<td class="field-parent nowrap">-</td>')
         self.assertNotEqual(table_output.find(row_html), -1, 'Failed to find expected row element: %s' % table_output)
 
-    def test_result_list_set_empty_value_display_on_admin_site(self):
+from django.test import TestCase
+from django.contrib.admin.sites import AdminSite
+from django.contrib.admin.views.main import SEARCH_VAR
+from django.db import connection
+from django.test.utils import CaptureQueriesContext
+from .models import Client, ClientOffice
+from .admin import ClientAdmin
+
+...
+
+class ClientTestCase(TestCase):
+    def setUp(self):
+        self.site = AdminSite()
+        self.client_admin = ClientAdmin(Client, self.site)
+        self.factory = RequestFactory()
+        self.superuser = User.objects.create_superuser('admin', 'admin@example.com', 'password')
+
+        # Create test data
+        client = Client.objects.create(name='Test Client', name2='TC', contact_person='John Doe')
+        ClientOffice.objects.create(client=client, name='Main Office', name2='HQ')
+
+    def test_search_clients_many_words(self):
+        """
+        Test if searching with many words does not lead to excessive JOINs.
+        """
+        request = self.factory.get('/client/', data={SEARCH_VAR: 'Test Client Main Office ' * 5})
+        request.user = self.superuser
+        cl = self.client_admin.get_changelist_instance(request)
+        
+        with CaptureQueriesContext(connection) as context:
+            object_count = cl.queryset.count()
+        
+        self.assertEqual(object_count, 1)
+        self.assertLessEqual(context.captured_queries[0]['sql'].count('JOIN'), 1)
+
+    def test_search_clients_no_results(self):
+        """
+        Test search with no results.
+        """
+        request = self.factory.get('/client/', data={SEARCH_VAR: 'Nonexistent'})
+        request.user = self.superuser
+        cl = self.client_admin.get_changelist_instance(request)
+        
+        self.assertEqual(cl.queryset.count(), 0)
         """
         Empty value display can be set on AdminSite.
         """

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 admin_changelist.admin admin_changelist.tests
git checkout e1d673c373a7d032060872b690a92fc95496612e tests/admin_changelist/tests.py
