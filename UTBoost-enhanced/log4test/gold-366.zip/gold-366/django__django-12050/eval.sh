#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff b93a0e34d9b9b99d41103782b7e7aeabf47517e3
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout b93a0e34d9b9b99d41103782b7e7aeabf47517e3 tests/queries/test_query.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/queries/test_query.py b/tests/queries/test_query.py
index 49d26f3..481c683 100644
--- a/tests/queries/test_query.py
+++ b/tests/queries/test_query.py
@@ -1,3 +1,4 @@
+
 from datetime import datetime
 
 from django.core.exceptions import FieldError
@@ -8,6 +9,7 @@ from django.db.models.functions import Lower
 from django.db.models.lookups import Exact, GreaterThan, IsNull, LessThan
 from django.db.models.sql.query import Query
 from django.db.models.sql.where import OR
+from django.db.models import PickledField
 from django.test import SimpleTestCase
 from django.test.utils import register_lookup
 
@@ -107,7 +109,19 @@ class TestQuery(SimpleTestCase):
         self.assertIsInstance(b_isnull.lhs, SimpleCol)
         self.assertEqual(b_isnull.lhs.target, ObjectC._meta.get_field('objectb'))
 
-    def test_clone_select_related(self):
+    def test_iterable_lookup_value(self):
+        query = Query(Item)
+        where = query.build_where(Q(name=['a', 'b']))
+        name_exact = where.children[0]
+        self.assertIsInstance(name_exact, Exact)
+        self.assertEqual(name_exact.rhs, ['a', 'b'])
+
+    def test_pickled_field_exact_lookup(self):
+        query = Query(Item)
+        where = query.build_where(Q(data=[1, 2, 3]))
+        data_exact = where.children[0]
+        self.assertIsInstance(data_exact, Exact)
+        self.assertEqual(data_exact.rhs, [1, 2, 3])
         query = Query(Item)
         query.add_select_related(['creator'])
         clone = query.clone()

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 queries.test_query
git checkout b93a0e34d9b9b99d41103782b7e7aeabf47517e3 tests/queries/test_query.py
