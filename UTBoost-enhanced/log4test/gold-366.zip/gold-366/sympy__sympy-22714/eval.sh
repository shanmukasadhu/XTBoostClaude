#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 3ff4717b6aef6086e78f01cdfa06f64ae23aed7e
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 3ff4717b6aef6086e78f01cdfa06f64ae23aed7e sympy/geometry/tests/test_point.py
git apply -v - <<'EOF_114329324912'
diff --git a/sympy/geometry/tests/test_point.py b/sympy/geometry/tests/test_point.py
index b7bdbda..e091877 100644
--- a/sympy/geometry/tests/test_point.py
+++ b/sympy/geometry/tests/test_point.py
@@ -1,4 +1,6 @@
+
 from sympy.core.basic import Basic
+from sympy.core.parameters import evaluate
 from sympy.core.numbers import (I, Rational, pi)
 from sympy.core.singleton import S
 from sympy.core.symbol import Symbol
@@ -440,7 +442,24 @@ def test_unit():
     assert Point(1, 1).unit == Point(sqrt(2)/2, sqrt(2)/2)
 
 
-def test_dot():
+def test_issue_22684():
+    # Used to give an error
+    with evaluate(False):
+        Point2D(1, 2)
+
+def test_point_creation_with_evaluate():
+    # Test without evaluate=False
+    p1 = Point2D(1, 2)
+    assert p1 == Point2D(1, 2)
+
+    # Test with evaluate=False
+    with evaluate(False):
+        p2 = Point2D(1, 2)
+        assert p2 == Point2D(1, 2)
+
+    # Test that imaginary coordinates are not allowed
+    with raises(ValueError, match='Imaginary coordinates are not permitted.'):
+        Point2D(1 + I, 2)
     raises(TypeError, lambda: Point(1, 2).dot(Line((0, 0), (1, 1))))
 
 

EOF_114329324912
PYTHONWARNINGS='ignore::UserWarning,ignore::SyntaxWarning' bin/test -C --verbose sympy/geometry/tests/test_point.py
git checkout 3ff4717b6aef6086e78f01cdfa06f64ae23aed7e sympy/geometry/tests/test_point.py
