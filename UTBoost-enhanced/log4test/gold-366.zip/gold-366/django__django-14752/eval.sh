#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff b64db05b9cedd96905d637a2d824cbbf428e40e7
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout b64db05b9cedd96905d637a2d824cbbf428e40e7 tests/admin_views/test_autocomplete_view.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/admin_views/test_autocomplete_view.py b/tests/admin_views/test_autocomplete_view.py
index 7ef6d86..d1c6610 100644
--- a/tests/admin_views/test_autocomplete_view.py
+++ b/tests/admin_views/test_autocomplete_view.py
@@ -1,5 +1,59 @@
+
+class TestAutocompleteJsonView(TestCase):
+    def setUp(self):
+        self.factory = RequestFactory()
+        self.superuser = User.objects.create_superuser(
+            username='super', password='secret', email='super@example.com',
+        )
+        self.url = '/autocomplete/'
+        self.opts = {'app_label': 'admin', 'model_name': 'question', 'field_name': 'autocomplete'}
+
+    def test_serialize_result_with_extra_field(self):
+        class AutocompleteJsonSerializeResultView(AutocompleteJsonView):
+            def serialize_result(self, obj, to_field_name):
+                return {
+                    **super().serialize_result(obj, to_field_name),
+                    'posted': str(obj.posted),
+                }
+
+        Question.objects.create(question='Question 1', posted=date(2021, 8, 9))
+        Question.objects.create(question='Question 2', posted=date(2021, 8, 7))
+        request = self.factory.get(self.url, {'term': 'question', **self.opts})
+        request.user = self.superuser
+        response = AutocompleteJsonSerializeResultView.as_view(admin_site=admin.site)(request)
+        self.assertEqual(response.status_code, 200)
+        data = json.loads(response.content.decode('utf-8'))
+        self.assertEqual(data, {
+            'results': [
+                {'id': str(q.pk), 'text': q.question, 'posted': str(q.posted)}
+                for q in Question.objects.order_by('-posted')
+            ],
+            'pagination': {'more': False},
+        })
+
+    def test_serialize_result_without_extra_field(self):
+        class AutocompleteJsonOriginalView(AutocompleteJsonView):
+            pass
+
+        Question.objects.create(question='Question 1', posted=date(2021, 8, 9))
+        Question.objects.create(question='Question 2', posted=date(2021, 8, 7))
+        request = self.factory.get(self.url, {'term': 'question', **self.opts})
+        request.user = self.superuser
+        response = AutocompleteJsonOriginalView.as_view(admin_site=admin.site)(request)
+        self.assertEqual(response.status_code, 200)
+        data = json.loads(response.content.decode('utf-8'))
+        self.assertEqual(data, {
+            'results': [
+                {'id': str(q.pk), 'text': q.question}
+                for q in Question.objects.order_by('-posted')
+            ],
+            'pagination': {'more': False},
+        })
+
 import json
-from contextlib import contextmanager
+from datetime import date
+from django.test import TestCase
+from .models import Question
 
 from django.contrib import admin
 from django.contrib.admin.tests import AdminSeleniumTestCase

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 admin_views.test_autocomplete_view
git checkout b64db05b9cedd96905d637a2d824cbbf428e40e7 tests/admin_views/test_autocomplete_view.py
