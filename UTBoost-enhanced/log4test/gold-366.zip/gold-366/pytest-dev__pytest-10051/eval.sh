#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff aa55975c7d3f6c9f6d7f68accc41bb7cadf0eb9a
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout aa55975c7d3f6c9f6d7f68accc41bb7cadf0eb9a testing/logging/test_fixture.py
git apply -v - <<'EOF_114329324912'
diff --git a/testing/logging/test_fixture.py b/testing/logging/test_fixture.py
index 26c4c15..56f529d 100644
--- a/testing/logging/test_fixture.py
+++ b/testing/logging/test_fixture.py
@@ -160,6 +160,8 @@ def logging_during_setup_and_teardown(caplog):
     assert [x.message for x in caplog.get_records("teardown")] == ["a_teardown_log"]
 
 
+import logging
+
 def test_caplog_captures_for_all_stages(caplog, logging_during_setup_and_teardown):
     assert not caplog.records
     assert not caplog.get_records("call")
@@ -172,7 +174,15 @@ def test_caplog_captures_for_all_stages(caplog, logging_during_setup_and_teardow
     assert set(caplog._item.stash[caplog_records_key]) == {"setup", "call"}
 
 
-def test_ini_controls_global_log_level(pytester: Pytester) -> None:
+def test_caplog_clear_and_get_records_consistency(caplog) -> None:
+    def verify_consistency() -> None:
+        assert caplog.get_records("call") == caplog.records
+
+    verify_consistency()
+    logging.warning("test")
+    verify_consistency()
+    caplog.clear()
+    verify_consistency()  # This should pass if the issue is fixed
     pytester.makepyfile(
         """
         import pytest

EOF_114329324912
pytest -rA testing/logging/test_fixture.py
git checkout aa55975c7d3f6c9f6d7f68accc41bb7cadf0eb9a testing/logging/test_fixture.py
