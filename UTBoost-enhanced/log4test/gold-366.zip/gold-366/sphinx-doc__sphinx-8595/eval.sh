#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff b19bce971e82f2497d67fdacdeca8db08ae0ba56
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .[test]
git checkout b19bce971e82f2497d67fdacdeca8db08ae0ba56 tests/test_ext_autodoc.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/test_ext_autodoc.py b/tests/test_ext_autodoc.py
index eec5523..5f14fe3 100644
--- a/tests/test_ext_autodoc.py
+++ b/tests/test_ext_autodoc.py
@@ -29,6 +29,27 @@ try:
 except ImportError:
     pyximport = None
 
+from .test_ext_autodoc import do_autodoc
+
+@pytest.mark.sphinx('html', testroot='ext-autodoc')
+def test_empty_all(app):
+    options = {'members': True}
+    actual = do_autodoc(app, 'module', 'target.empty_all', options)
+    assert list(actual) == [
+        '',
+        '.. py:module:: target.empty_all',
+        '',
+        'docsting of empty_all module.',
+        '',
+    ]
+
+@pytest.mark.sphinx('html', testroot='ext-autodoc')
+def test_ignore_module_all_option(app):
+    options = {'members': True, 'ignore-module-all': True}
+    actual = do_autodoc(app, 'module', 'target.empty_all', options)
+    assert 'foo' in actual
+    assert 'bar' in actual
+    assert 'baz' in actual
 
 def do_autodoc(app, objtype, name, options=None):
     if options is None:

EOF_114329324912
tox --current-env -epy39 -v -- tests/roots/test-ext-autodoc/target/empty_all.py tests/test_ext_autodoc_automodule.py
git checkout b19bce971e82f2497d67fdacdeca8db08ae0ba56 tests/test_ext_autodoc.py
