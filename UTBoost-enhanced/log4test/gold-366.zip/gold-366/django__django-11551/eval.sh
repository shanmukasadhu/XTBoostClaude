#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 7991111af12056ec9a856f35935d273526338c1f
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 7991111af12056ec9a856f35935d273526338c1f tests/modeladmin/test_checks.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/modeladmin/test_checks.py b/tests/modeladmin/test_checks.py
index debaf8a..378e0c6 100644
--- a/tests/modeladmin/test_checks.py
+++ b/tests/modeladmin/test_checks.py
@@ -1,9 +1,10 @@
+
 from django import forms
 from django.contrib.admin import BooleanFieldListFilter, SimpleListFilter
 from django.contrib.admin.options import VERTICAL, ModelAdmin, TabularInline
 from django.contrib.admin.sites import AdminSite
 from django.core.checks import Error
-from django.db.models import F
+from django.db.models import F, Field, Model
 from django.db.models.functions import Upper
 from django.forms.models import BaseModelFormSet
 from django.test import SimpleTestCase

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 modeladmin.test_checks
git checkout 7991111af12056ec9a856f35935d273526338c1f tests/modeladmin/test_checks.py
