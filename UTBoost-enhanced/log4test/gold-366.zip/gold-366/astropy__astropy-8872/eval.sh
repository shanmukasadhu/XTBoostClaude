#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff b750a0e6ee76fb6b8a099a4d16ec51977be46bf6
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .[test] --verbose
git checkout b750a0e6ee76fb6b8a099a4d16ec51977be46bf6 astropy/units/tests/test_quantity.py
git apply -v - <<'EOF_114329324912'
diff --git a/astropy/units/tests/test_quantity.py b/astropy/units/tests/test_quantity.py
index 283420f..e0b1a44 100644
--- a/astropy/units/tests/test_quantity.py
+++ b/astropy/units/tests/test_quantity.py
@@ -139,6 +139,31 @@ class TestQuantityCreation:
         assert q2.unit == q1.unit
 
         # but we should preserve float32
+        a3_32 = np.array([1., 2.], dtype=np.float32)
+        q3_32 = u.Quantity(a3_32, u.yr)
+        assert q3_32.dtype == a3_32.dtype
+        a3_16 = np.array([1., 2.], dtype=np.float16)
+        q3_16 = u.Quantity(a3_16, u.yr)
+        assert q3_16.dtype == a3_16.dtype
+
+    def test_preserve_float16(self):
+        """Test that float16 is not upgraded to float64 when creating a Quantity."""
+        a = np.float16(1.0)
+        q = a * u.m
+        assert q.dtype == np.float16
+        assert q.value == a
+
+    def test_mixed_dtypes(self):
+        """Test creating Quantities with mixed dtypes."""
+        a = np.array([1.0, 2.0], dtype=np.float16)
+        b = np.array([3.0, 4.0], dtype=np.float32)
+        c = np.array([5.0, 6.0], dtype=np.float64)
+        q_a = u.Quantity(a, u.m)
+        q_b = u.Quantity(b, u.m)
+        q_c = u.Quantity(c, u.m)
+        assert q_a.dtype == np.float16
+        assert q_b.dtype == np.float32
+        assert q_c.dtype == np.float64
         a3 = np.array([1., 2.], dtype=np.float32)
         q3 = u.Quantity(a3, u.yr)
         assert q3.dtype == a3.dtype

EOF_114329324912
pytest -rA astropy/units/tests/test_quantity.py
git checkout b750a0e6ee76fb6b8a099a4d16ec51977be46bf6 astropy/units/tests/test_quantity.py
