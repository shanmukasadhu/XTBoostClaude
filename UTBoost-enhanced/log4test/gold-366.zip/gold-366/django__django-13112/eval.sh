#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 09914ccf688974e068941f55412b930729bafa06
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 09914ccf688974e068941f55412b930729bafa06 tests/migrations/test_state.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/migrations/test_state.py b/tests/migrations/test_state.py
index 081eff8..24a4320 100644
--- a/tests/migrations/test_state.py
+++ b/tests/migrations/test_state.py
@@ -867,7 +867,28 @@ class StateTests(SimpleTestCase):
         with self.assertRaisesMessage(ValueError, msg):
             project_state.apps
 
-    def test_real_apps(self):
+    def test_mixed_case_foreign_key(self):
+        """
+        Test ForeignKey with mixed-case app names.
+        """
+        new_apps = Apps()
+
+        class Category(models.Model):
+            class Meta:
+                app_label = 'DJ_RegLogin'
+                apps = new_apps
+
+        class Content(models.Model):
+            category = models.ForeignKey(Category, models.CASCADE)
+
+            class Meta:
+                app_label = 'DJ_RegLogin'
+                apps = new_apps
+
+        project_state = ProjectState()
+        project_state.add_model(ModelState.from_model(Category))
+        project_state.add_model(ModelState.from_model(Content))
+        self.assertEqual(len(project_state.apps.get_models()), 2)
         """
         Including real apps can resolve dangling FK errors.
         This test relies on the fact that contenttypes is always loaded.

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 migrations.test_state
git checkout 09914ccf688974e068941f55412b930729bafa06 tests/migrations/test_state.py
