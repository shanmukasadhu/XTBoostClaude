#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 69331bb851c34f05bc77e9fc24020fe6908b9cd5
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 69331bb851c34f05bc77e9fc24020fe6908b9cd5 tests/template_tests/test_custom.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/template_tests/test_custom.py b/tests/template_tests/test_custom.py
index 8a8c535..4a14d32 100644
--- a/tests/template_tests/test_custom.py
+++ b/tests/template_tests/test_custom.py
@@ -87,7 +87,24 @@ class SimpleTagTests(TagTestCase):
             t = self.engine.from_string("%s as var %%}Result: {{ var }}" % entry[0][0:-2])
             self.assertEqual(t.render(c), "Result: %s" % entry[1])
 
-    def test_simple_tag_errors(self):
+    def test_simple_tag_keyword_only_defaults(self):
+        templates = [
+            ('{% load custom %}{% hello %}', 'hello world'),
+            ('{% load custom %}{% hello greeting="hi" %}', 'hi world'),
+        ]
+
+        for entry in templates:
+            t = self.engine.from_string(entry[0])
+            self.assertEqual(t.render({}), entry[1])
+
+        errors = [
+            ("'hello' received multiple values for keyword argument 'greeting'",
+             '{% load custom %}{% hello greeting="hi" greeting="hello" %}'),
+        ]
+
+        for entry in errors:
+            with self.assertRaisesMessage(TemplateSyntaxError, entry[0]):
+                self.engine.from_string(entry[1])
         errors = [
             ("'simple_one_default' received unexpected keyword argument 'three'",
                 '{% load custom %}{% simple_one_default 99 two="hello" three="foo" %}'),
@@ -196,7 +213,24 @@ class InclusionTagTests(TagTestCase):
             t = self.engine.from_string(entry[0])
             self.assertEqual(t.render(c), entry[1])
 
-    def test_inclusion_tag_errors(self):
+    def test_inclusion_tag_keyword_only_defaults(self):
+        templates = [
+            ('{% load inclusion %}{% inclusion_keyword_only_default %}', 'inclusion_keyword_only_default - Expected result: 42\n'),
+            ('{% load inclusion %}{% inclusion_keyword_only_default kwarg=37 %}', 'inclusion_keyword_only_default - Expected result: 37\n'),
+        ]
+
+        for entry in templates:
+            t = self.engine.from_string(entry[0])
+            self.assertEqual(t.render({}), entry[1])
+
+        errors = [
+            ("'inclusion_keyword_only_default' received multiple values for keyword argument 'kwarg'",
+             '{% load inclusion %}{% inclusion_keyword_only_default kwarg=37 kwarg=42 %}'),
+        ]
+
+        for entry in errors:
+            with self.assertRaisesMessage(TemplateSyntaxError, entry[0]):
+                self.engine.from_string(entry[1])
         errors = [
             ("'inclusion_one_default' received unexpected keyword argument 'three'",
                 '{% load inclusion %}{% inclusion_one_default 99 two="hello" three="foo" %}'),

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 template_tests.templatetags.inclusion template_tests.test_custom
git checkout 69331bb851c34f05bc77e9fc24020fe6908b9cd5 tests/template_tests/test_custom.py
