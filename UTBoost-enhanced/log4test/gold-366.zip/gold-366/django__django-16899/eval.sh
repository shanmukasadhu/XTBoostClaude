#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff d3d173425fc0a1107836da5b4567f1c88253191b
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout d3d173425fc0a1107836da5b4567f1c88253191b tests/admin_checks/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/admin_checks/tests.py b/tests/admin_checks/tests.py
index 5130136..436f515 100644
--- a/tests/admin_checks/tests.py
+++ b/tests/admin_checks/tests.py
@@ -790,8 +790,20 @@ class SystemChecksTestCase(SimpleTestCase):
 
         errors = SongAdmin(Song, AdminSite()).check()
         self.assertEqual(errors, [])
+    def test_readonly_field_includes_name(self):
+        class SongAdmin(admin.ModelAdmin):
+            readonly_fields = ("nonexistent_field",)
 
-    def test_nonexistent_field(self):
+        errors = SongAdmin(Song, AdminSite()).check()
+        expected = [
+            checks.Error(
+                "The value of 'readonly_fields[0]' refers to 'nonexistent_field', "
+                "which is not a callable, an attribute of 'SongAdmin', or an attribute of 'admin_checks.Song'.",
+                obj=SongAdmin,
+                id="admin.E035",
+            )
+        ]
+        self.assertEqual(errors, expected)
         class SongAdmin(admin.ModelAdmin):
             readonly_fields = ("title", "nonexistent")
 

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 admin_checks.tests
git checkout d3d173425fc0a1107836da5b4567f1c88253191b tests/admin_checks/tests.py
