#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 0ab58c120939093fea90822f376e1866fc714d1f
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 0ab58c120939093fea90822f376e1866fc714d1f tests/migrations/test_autodetector.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/migrations/test_autodetector.py b/tests/migrations/test_autodetector.py
index a6c0858..d1b468a 100644
--- a/tests/migrations/test_autodetector.py
+++ b/tests/migrations/test_autodetector.py
@@ -1762,7 +1762,28 @@ class AutodetectorTests(TestCase):
             index_together={('title', 'newfield2')},
         )
 
-    def test_proxy(self):
+    def test_optimize_foo_together_operations(self):
+        """
+        Test optimization of multiple AlterFooTogether operations into one.
+        """
+        changes = self.get_changes(
+            [self.author_empty, self.book_foo_together],
+            [self.author_empty, self.book_foo_together_optimized]
+        )
+        # Right number/type of migrations?
+        self.assertNumberMigrations(changes, "otherapp", 1)
+        self.assertOperationTypes(changes, "otherapp", 0, [
+            "AlterUniqueTogether",
+            "AlterIndexTogether",
+        ])
+        self.assertOperationAttributes(
+            changes, "otherapp", 0, 0, name="book",
+            unique_together={("col",)},
+        )
+        self.assertOperationAttributes(
+            changes, "otherapp", 0, 1, name="book",
+            index_together={("col",)},
+        )
         """The autodetector correctly deals with proxy models."""
         # First, we test adding a proxy model
         changes = self.get_changes([self.author_empty], [self.author_empty, self.author_proxy])

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 migrations.test_autodetector
git checkout 0ab58c120939093fea90822f376e1866fc714d1f tests/migrations/test_autodetector.py
