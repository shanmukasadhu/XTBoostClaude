#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 795747bdb6b8fb7d717d5bbfc2c3316869e66a73
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .[test]
git checkout 795747bdb6b8fb7d717d5bbfc2c3316869e66a73 tests/test_intl.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/test_intl.py b/tests/test_intl.py
index 58339b1..58007dc 100644
--- a/tests/test_intl.py
+++ b/tests/test_intl.py
@@ -1287,5 +1287,39 @@ def test_image_glob_intl_using_figure_language_filename(app):
                             'image/svg+xml': 'subdir/svgimg.svg'})
 
 
+from babel.messages import pofile
+from sphinx.testing.util import SphinxTestApp
+from babel.messages.catalog import Catalog
+from sphinx import locale
+
+@pytest.mark.sphinx('html', testroot='locale_override', confoverrides={'language': 'da'})
+def test_locale_override(make_app, app_params, sphinx_test_tempdir):
+    try:
+        # clear translators cache
+        locale.translators.clear()
+
+        # prepare message catalog (.po)
+        locale_dir = sphinx_test_tempdir / 'locale_override' / 'locales' / 'da' / 'LC_MESSAGES'
+        locale_dir.makedirs()
+        with (locale_dir / 'sphinx.po').open('wb') as f:
+            catalog = Catalog()
+            catalog.add('Fig. %s', 'Foobar %s')
+            catalog.add('Listing %s', 'Whatever %s')
+            pofile.write_po(f, catalog)
+
+        # construct application and convert po file to .mo
+        args, kwargs = app_params
+        app = make_app(*args, **kwargs)
+        assert (locale_dir / 'sphinx.mo').exists()
+        assert app.translator.gettext('Fig. %s') == 'Foobar %s'
+        assert app.translator.gettext('Listing %s') == 'Whatever %s'
+
+        app.build()
+        content = (app.outdir / 'index.html').read_text()
+        assert 'Foobar 1' in content
+        assert 'Whatever 1' in content
+    finally:
+        locale.translators.clear()
+
 def getwarning(warnings):
-    return strip_escseq(warnings.getvalue().replace(os.sep, '/'))
+    return strip_escseq(warnings.getvalue().replace(os.sep, '/'))

EOF_114329324912
tox --current-env -epy39 -v -- tests/test_intl.py
git checkout 795747bdb6b8fb7d717d5bbfc2c3316869e66a73 tests/test_intl.py
