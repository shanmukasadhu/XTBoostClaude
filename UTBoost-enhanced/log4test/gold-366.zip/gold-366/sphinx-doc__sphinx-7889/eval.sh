#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff ec9af606c6cfa515f946d74da9b51574f2f9b16f
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .[test]
git checkout ec9af606c6cfa515f946d74da9b51574f2f9b16f tests/test_ext_autodoc_mock.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/test_ext_autodoc_mock.py b/tests/test_ext_autodoc_mock.py
index 7302feb..d391563 100644
--- a/tests/test_ext_autodoc_mock.py
+++ b/tests/test_ext_autodoc_mock.py
@@ -1,3 +1,4 @@
+
 """
     test_ext_autodoc_mock
     ~~~~~~~~~~~~~~~~~~~~~
@@ -15,6 +16,7 @@ from importlib import import_module
 import pytest
 
 from sphinx.ext.autodoc.mock import _MockModule, _MockObject, mock
+from typing import TypeVar
 
 
 def test_MockModule():
@@ -52,7 +54,15 @@ def test_MockObject():
     assert isinstance(obj.other_method(), SubClass)
 
 
-def test_mock():
+def test_generic_typed_class():
+    T = TypeVar('T')
+
+    class GenericClass(mock.SomeClass[T]):
+        """docstring of GenericClass"""
+
+    obj = GenericClass()
+    assert GenericClass.__doc__ == "docstring of GenericClass"
+    assert isinstance(obj, GenericClass)
     modname = 'sphinx.unknown'
     submodule = modname + '.submodule'
     assert modname not in sys.modules

EOF_114329324912
tox --current-env -epy39 -v -- tests/test_ext_autodoc_mock.py
git checkout ec9af606c6cfa515f946d74da9b51574f2f9b16f tests/test_ext_autodoc_mock.py
