#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 5e17a90c19f7eecfa10c1ab872648ae7e2131323
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 5e17a90c19f7eecfa10c1ab872648ae7e2131323 sympy/core/tests/test_arit.py
git apply -v - <<'EOF_114329324912'
diff --git a/sympy/core/tests/test_arit.py b/sympy/core/tests/test_arit.py
index d8e8fc4..3a7cb59 100644
--- a/sympy/core/tests/test_arit.py
+++ b/sympy/core/tests/test_arit.py
@@ -1625,7 +1625,21 @@ def test_Mod():
     assert (3*i*x) % (2*i*y) == i*Mod(3*x, 2*y)
     assert Mod(4*i, 4) == 0
 
-    # issue 8677
+    # issue 15493
+    i, j = symbols('i j', integer=True, positive=True)
+    assert Mod(3*i, 2) == Mod(i, 2)
+    assert Mod(8*i/j, 4) == 4*Mod(2*i/j, 1)
+    assert Mod(8*i, 4) == 0
+
+    # Additional test cases for issue 15493
+    assert Mod(6*i, 2) == 0
+    assert Mod(7*i, 2) == Mod(i, 2)
+    assert Mod(9*i, 3) == 0
+    assert Mod(12*i, 4) == 0
+    assert Mod(15*i, 5) == 0
+    assert Mod(5*i + 2, 2) == Mod(i, 2)
+    assert Mod(10*i + 3, 5) == Mod(i, 5)
+    assert Mod(14*i + 7, 7) == 0
     n = Symbol('n', integer=True, positive=True)
     assert factorial(n) % n == 0
     assert factorial(n + 2) % n == 0

EOF_114329324912
PYTHONWARNINGS='ignore::UserWarning,ignore::SyntaxWarning' bin/test -C --verbose sympy/core/tests/test_arit.py
git checkout 5e17a90c19f7eecfa10c1ab872648ae7e2131323 sympy/core/tests/test_arit.py
