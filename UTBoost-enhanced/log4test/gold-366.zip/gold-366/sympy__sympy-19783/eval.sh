#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 586a43201d0357e92e8c93548d69a9f42bf548f4
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 586a43201d0357e92e8c93548d69a9f42bf548f4 sympy/physics/quantum/tests/test_operator.py
git apply -v - <<'EOF_114329324912'
diff --git a/sympy/physics/quantum/tests/test_operator.py b/sympy/physics/quantum/tests/test_operator.py
index 799aaae..a3d3144 100644
--- a/sympy/physics/quantum/tests/test_operator.py
+++ b/sympy/physics/quantum/tests/test_operator.py
@@ -1,5 +1,7 @@
+
 from sympy import (Derivative, diff, Function, Integer, Mul, pi, sin, Symbol,
                    symbols)
+from sympy.physics.quantum import IdentityOperator
 from sympy.physics.quantum.qexpr import QExpr
 from sympy.physics.quantum.dagger import Dagger
 from sympy.physics.quantum.hilbert import HilbertSpace
@@ -84,7 +86,13 @@ def test_unitary():
     assert Dagger(U).is_commutative is False
 
 
-def test_identity():
+def test_dagger_identity():
+    O = Operator('O')
+    I = IdentityOperator()
+    D = Dagger(O)
+
+    assert D * I == D
+    assert I * D == D
     I = IdentityOperator()
     O = Operator('O')
     x = Symbol("x")

EOF_114329324912
PYTHONWARNINGS='ignore::UserWarning,ignore::SyntaxWarning' bin/test -C --verbose sympy/physics/quantum/tests/test_dagger.py sympy/physics/quantum/tests/test_operator.py
git checkout 586a43201d0357e92e8c93548d69a9f42bf548f4 sympy/physics/quantum/tests/test_operator.py
