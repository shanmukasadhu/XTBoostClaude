#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff cb828ebe70b4fa35cd5f9a7ee024272237eab351
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout cb828ebe70b4fa35cd5f9a7ee024272237eab351 testing/test_collection.py
git apply -v - <<'EOF_114329324912'
diff --git a/testing/test_collection.py b/testing/test_collection.py
index e422b03..3c77bdc 100644
--- a/testing/test_collection.py
+++ b/testing/test_collection.py
@@ -6,13 +6,34 @@ import textwrap
 import py
 
 import pytest
+from unittest.mock import patch
+import numpy as np
 from _pytest.main import _in_venv
 from _pytest.main import ExitCode
 from _pytest.main import Session
 
 
 class TestCollector:
-    def test_collect_versus_item(self):
+    def test_mock_sentinel_check_against_numpy_array(self, testdir):
+        """Ensure array values do not cause a ValueError during test collection (#5606)."""
+        testdir.makepyfile(
+            dummy="""
+            import numpy as np
+            FOO = np.array([1, 2, 3])
+            """
+        )
+        testdir.makepyfile(
+            """
+            from unittest.mock import patch
+            import dummy
+            class Test:
+                @patch("dummy.FOO", new=np.array([4, 5, 6]))
+                def test_array_patch(self):
+                    assert (dummy.FOO == np.array([4, 5, 6])).all()
+            """
+        )
+        reprec = testdir.inline_run()
+        reprec.assertoutcome(passed=1)
         from pytest import Collector, Item
 
         assert not issubclass(Collector, Item)

EOF_114329324912
pytest -rA testing/python/integration.py
git checkout cb828ebe70b4fa35cd5f9a7ee024272237eab351 testing/test_collection.py
