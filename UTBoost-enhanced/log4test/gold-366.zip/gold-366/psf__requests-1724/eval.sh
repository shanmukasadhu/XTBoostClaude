#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 1ba83c47ce7b177efe90d5f51f7760680f72eda0
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install .
git checkout 1ba83c47ce7b177efe90d5f51f7760680f72eda0 requests/api.py
git apply -v - <<'EOF_114329324912'
diff --git a/requests/api.py b/requests/api.py
index 66d7f21..3a66dbf 100644
--- a/requests/api.py
+++ b/requests/api.py
@@ -11,6 +11,7 @@ This module implements the Requests API.
 
 """
 
+import io
 from . import sessions
 
 
@@ -33,6 +34,31 @@ def request(method, url, **kwargs):
     :param stream: (optional) if ``False``, the response content will be immediately downloaded.
     :param cert: (optional) if String, path to ssl client cert file (.pem). If Tuple, ('cert', 'key') pair.
 
+    def test_unicode_method_name(self):
+        files = {'file': io.BytesIO(b"Test content")}
+        # Using unicode method name
+        r = request(method=u'POST', url='http://httpbin.org/post', files=files)
+        assert r.status_code == 200
+
+    def test_string_method_name(self):
+        files = {'file': io.BytesIO(b"Test content")}
+        # Using string method name
+        r = request(method='POST', url='http://httpbin.org/post', files=files)
+        assert r.status_code == 200
+
+    def test_unicode_url(self):
+        files = {'file': io.BytesIO(b"Test content")}
+        # Using unicode URL
+        r = request(method='POST', url=u'http://httpbin.org/post', files=files)
+        assert r.status_code == 200
+
+    def test_invalid_unicode_handling(self):
+        try:
+            files = {'file': io.BytesIO(b"Test content")}
+            request(method=u'POST', url='http://httpbin.org/post', files=files)
+        except UnicodeDecodeError:
+            assert False, "UnicodeDecodeError should not occur with unicode method names"
+
     Usage::
 
       >>> import requests

EOF_114329324912
pytest -rA test_requests.py
git checkout 1ba83c47ce7b177efe90d5f51f7760680f72eda0 requests/api.py
