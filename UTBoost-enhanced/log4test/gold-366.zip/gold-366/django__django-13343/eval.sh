#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff ece18207cbb64dd89014e279ac636a6c9829828e
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout ece18207cbb64dd89014e279ac636a6c9829828e tests/file_storage/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/file_storage/tests.py b/tests/file_storage/tests.py
index a5ab3a0..e816301 100644
--- a/tests/file_storage/tests.py
+++ b/tests/file_storage/tests.py
@@ -29,7 +29,7 @@ from django.test.utils import requires_tz_support
 from django.urls import NoReverseMatch, reverse_lazy
 from django.utils import timezone
 
-from .models import Storage, temp_storage, temp_storage_location
+from .models import Storage, callable_storage, temp_storage, temp_storage_location
 
 FILE_SUFFIX_REGEX = '[A-Za-z0-9]{7}'
 
@@ -82,7 +82,15 @@ class FileSystemStorageTests(unittest.TestCase):
         path, args, kwargs = storage.deconstruct()
         self.assertEqual(kwargs, kwargs_orig)
 
-    def test_lazy_base_url_init(self):
+    def test_deconstruction_with_callable_storage(self):
+        """
+        Verifies that deconstructing a FileField with callable storage returns
+        the original callable, not the evaluated value.
+        """
+        obj = Storage()
+        _, _, kwargs = obj._meta.get_field('storage_callable').deconstruct()
+        storage = kwargs['storage']
+        self.assertIs(storage, callable_storage)
         """
         FileSystemStorage.__init__() shouldn't evaluate base_url.
         """
@@ -906,7 +914,17 @@ class FieldCallableFileStorageTests(SimpleTestCase):
         obj = FileField(storage=GetStorage)
         self.assertIsInstance(obj.storage, BaseStorage)
 
-    def test_callable_storage_file_field_in_model(self):
+    def test_filefield_storage_callable_behavior(self):
+        """
+        Ensures that the FileField with a callable storage parameter does not evaluate
+        the callable during migrations.
+        """
+        obj = Storage()
+        storage_field = obj._meta.get_field('storage_callable')
+        name, path, args, kwargs = storage_field.deconstruct()
+
+        # Check that the callable is preserved and not evaluated
+        self.assertEqual(kwargs['storage'], callable_storage)
         obj = Storage()
         self.assertEqual(obj.storage_callable.storage, temp_storage)
         self.assertEqual(obj.storage_callable.storage.location, temp_storage_location)

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 file_storage.tests
git checkout ece18207cbb64dd89014e279ac636a6c9829828e tests/file_storage/tests.py
