#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff f618e033acd37d59b536d6e6126e6c5be18037f6
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout f618e033acd37d59b536d6e6126e6c5be18037f6 tests/aggregation/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/aggregation/tests.py b/tests/aggregation/tests.py
index 2b8f813..42d9d16 100644
--- a/tests/aggregation/tests.py
+++ b/tests/aggregation/tests.py
@@ -391,6 +391,16 @@ class AggregateTestCase(TestCase):
         vals = Book.objects.aggregate(Count("rating", distinct=True))
         self.assertEqual(vals, {"rating__count": 4})
 
+    def test_distinct_on_aggregate(self):
+        # Testing DISTINCT on Avg and Sum aggregates
+        for aggregate, expected_result in (
+            (Avg, 4.125),
+            (Sum, 16.5),
+        ):
+            with self.subTest(aggregate=aggregate.__name__):
+                books = Book.objects.aggregate(ratings=aggregate('rating', distinct=True))
+                self.assertEqual(books['ratings'], expected_result)
+
     def test_count_star(self):
         with self.assertNumQueries(1) as ctx:
             Book.objects.aggregate(n=Count("*"))

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 aggregation.tests
git checkout f618e033acd37d59b536d6e6126e6c5be18037f6 tests/aggregation/tests.py
