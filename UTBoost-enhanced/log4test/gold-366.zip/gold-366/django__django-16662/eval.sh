#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 0eb3e9bd754e4c9fac8b616b705178727fc8031e
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 0eb3e9bd754e4c9fac8b616b705178727fc8031e tests/migrations/test_writer.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/migrations/test_writer.py b/tests/migrations/test_writer.py
index f0046ca..92ea405 100644
--- a/tests/migrations/test_writer.py
+++ b/tests/migrations/test_writer.py
@@ -922,7 +922,29 @@ class WriterTests(SimpleTestCase):
             output,
         )
 
-    def test_migration_file_header_comments(self):
+    def test_import_ordering_style(self):
+        """
+        Test that import ordering follows Django style and isort defaults.
+        """
+        migration = type(
+            "Migration",
+            (migrations.Migration,),
+            {
+                "operations": [
+                    migrations.AddField(
+                        "mymodel",
+                        "myfield2",
+                        models.FloatField(default=time.time),
+                    ),
+                ]
+            },
+        )
+        writer = MigrationWriter(migration)
+        output = writer.as_string()
+        self.assertIn(
+            "import datetime\nimport time\nfrom django.db import migrations, models\n",
+            output,
+        )
         """
         Test comments at top of file.
         """

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 migrations.test_writer
git checkout 0eb3e9bd754e4c9fac8b616b705178727fc8031e tests/migrations/test_writer.py
