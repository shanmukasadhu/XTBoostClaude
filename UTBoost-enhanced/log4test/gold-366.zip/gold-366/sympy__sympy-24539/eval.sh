#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 193e3825645d93c73e31cdceb6d742cc6919624d
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 193e3825645d93c73e31cdceb6d742cc6919624d sympy/polys/tests/test_rings.py
git apply -v - <<'EOF_114329324912'
diff --git a/sympy/polys/tests/test_rings.py b/sympy/polys/tests/test_rings.py
index 1f0e405..f81a164 100644
--- a/sympy/polys/tests/test_rings.py
+++ b/sympy/polys/tests/test_rings.py
@@ -249,6 +249,8 @@ def test_PolyElement_copy():
     g[(1, 1, 1)] = 7
     assert f != g
 
+from sympy import ring, ZZ, symbols, raises
+
 def test_PolyElement_as_expr():
     R, x, y, z = ring("x,y,z", ZZ)
     f = 3*x**2*y - x*y*z + 7*z**3 + 1
@@ -267,6 +269,21 @@ def test_PolyElement_as_expr():
 
     raises(ValueError, lambda: f.as_expr(X))
 
+    # Additional test cases to verify the fix
+    # Test with different number of symbols
+    U, V = symbols("u,v")
+    raises(ValueError, lambda: f.as_expr(U, V))
+
+    # Test with a different set of symbols
+    U, V, W = symbols("u,v,w")
+    g = 3*U**2*V - U*V*W + 7*W**3 + 1
+    assert f.as_expr(U, V, W) == g
+
+    # Test with the same symbols but in a different order
+    W, V, U = symbols("w,v,u")
+    g = 3*W**2*V - W*V*U + 7*U**3 + 1
+    assert f.as_expr(W, V, U) == g
+
     R, = ring("", ZZ)
     assert R(3).as_expr() == 3
 

EOF_114329324912
PYTHONWARNINGS='ignore::UserWarning,ignore::SyntaxWarning' bin/test -C --verbose sympy/polys/tests/test_rings.py
git checkout 193e3825645d93c73e31cdceb6d742cc6919624d sympy/polys/tests/test_rings.py
