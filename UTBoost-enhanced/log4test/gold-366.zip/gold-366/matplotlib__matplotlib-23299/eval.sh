#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 3eadeacc06c9f2ddcdac6ae39819faa9fbee9e39
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 3eadeacc06c9f2ddcdac6ae39819faa9fbee9e39 lib/matplotlib/tests/test_rcparams.py
git apply -v - <<'EOF_114329324912'
diff --git a/lib/matplotlib/tests/test_rcparams.py b/lib/matplotlib/tests/test_rcparams.py
index 144880c..375a016 100644
--- a/lib/matplotlib/tests/test_rcparams.py
+++ b/lib/matplotlib/tests/test_rcparams.py
@@ -490,6 +490,45 @@ def test_validate_fontstretch(stretch, parsed_stretch):
         assert validate_fontstretch(stretch) == parsed_stretch
 
 
+import matplotlib.pyplot as plt
+from matplotlib import get_backend, rc_context
+from matplotlib.testing.decorators import cleanup
+
+
+@cleanup
+def test_get_backend_does_not_clear_figs_rc_context():
+    # Ensure Gcf.figs is not cleared when get_backend() is called with rc_context
+    with rc_context():
+        fig = plt.figure()
+    before = f'{id(plt._pylab_helpers.Gcf)} {plt._pylab_helpers.Gcf.figs!r}'
+    get_backend()
+    after = f'{id(plt._pylab_helpers.Gcf)} {plt._pylab_helpers.Gcf.figs!r}'
+    assert before == after, '\n' + before + '\n' + after
+
+
+@cleanup
+def test_get_backend_with_preceding_figure():
+    # Ensure Gcf.figs is not cleared when a figure is created before rc_context
+    fig1 = plt.figure()
+    with rc_context():
+        fig2 = plt.figure()
+    before = f'{id(plt._pylab_helpers.Gcf)} {plt._pylab_helpers.Gcf.figs!r}'
+    get_backend()
+    after = f'{id(plt._pylab_helpers.Gcf)} {plt._pylab_helpers.Gcf.figs!r}'
+    assert before == after, '\n' + before + '\n' + after
+
+
+@cleanup
+def test_get_backend_with_interactive_mode():
+    # Ensure Gcf.figs is not cleared when interactive mode is turned on
+    plt.ion()
+    with rc_context():
+        fig = plt.figure()
+    before = f'{id(plt._pylab_helpers.Gcf)} {plt._pylab_helpers.Gcf.figs!r}'
+    get_backend()
+    after = f'{id(plt._pylab_helpers.Gcf)} {plt._pylab_helpers.Gcf.figs!r}'
+    assert before == after, '\n' + before + '\n' + after
+
 def test_keymaps():
     key_list = [k for k in mpl.rcParams if 'keymap' in k]
     for k in key_list:

EOF_114329324912
pytest -rA lib/matplotlib/tests/test_rcparams.py
git checkout 3eadeacc06c9f2ddcdac6ae39819faa9fbee9e39 lib/matplotlib/tests/test_rcparams.py
