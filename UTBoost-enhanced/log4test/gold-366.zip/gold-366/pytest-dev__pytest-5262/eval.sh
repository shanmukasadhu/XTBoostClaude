#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 58e6a09db49f34886ff13f3b7520dd0bcd7063cd
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 58e6a09db49f34886ff13f3b7520dd0bcd7063cd testing/test_capture.py
git apply -v - <<'EOF_114329324912'
diff --git a/testing/test_capture.py b/testing/test_capture.py
index 1f092b0..40d150c 100644
--- a/testing/test_capture.py
+++ b/testing/test_capture.py
@@ -1042,6 +1042,28 @@ class TestFDCapture(object):
             os.write(1, b"world")
             sys.stdout.write("qlwkej")
             assert not cap.snap()
+
+    def test_capfd_sys_stdout_mode(self, capfd):
+        import sys
+        out, err = capfd.readouterr()
+        assert "b" not in sys.stdout.mode
+
+    def test_encodedfile_write_str(self):
+        from _pytest.capture import EncodedFile
+        import io
+        buffer = io.StringIO()
+        ef = EncodedFile(buffer, 'utf-8')
+        ef.write("test")
+        assert buffer.getvalue() == "test"
+
+    def test_encodedfile_write_bytes_raises(self):
+        from _pytest.capture import EncodedFile
+        import io
+        buffer = io.BytesIO()
+        ef = EncodedFile(buffer, 'utf-8')
+        import pytest
+        with pytest.raises(TypeError, match="write\(\) argument must be str, not bytes"):
+            ef.write(b"test")
             cap.resume()
             os.write(1, b"but now")
             sys.stdout.write(" yes\n")

EOF_114329324912
pytest -rA testing/test_capture.py
git checkout 58e6a09db49f34886ff13f3b7520dd0bcd7063cd testing/test_capture.py
