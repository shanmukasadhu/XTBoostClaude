#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 6991880109e35c879b71b7d9d9c154baeec12b89
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 6991880109e35c879b71b7d9d9c154baeec12b89 tests/schema/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/schema/tests.py b/tests/schema/tests.py
index b8137da..f8b53f5 100644
--- a/tests/schema/tests.py
+++ b/tests/schema/tests.py
@@ -3955,6 +3955,35 @@ class SchemaTests(TransactionTestCase):
             validators=[lambda x: x],
             verbose_name="verbose name",
         )
+
+    def test_alter_field_choices_same_choices(self):
+        # Test with same choices to ensure no SQL is generated
+        with connection.schema_editor() as editor:
+            editor.create_model(Author)
+        old_field = Author._meta.get_field("name")
+        new_field = CharField(
+            choices=old_field.choices,
+            max_length=255,
+        )
+        new_field.set_attributes_from_name("name")
+        with connection.schema_editor() as editor, self.assertNumQueries(0):
+            editor.alter_field(Author, old_field, new_field, strict=True)
+        with connection.schema_editor() as editor, self.assertNumQueries(0):
+            editor.alter_field(Author, new_field, old_field, strict=True)
+
+    def test_alter_field_choices_no_choices(self):
+        # Test removing choices
+        with connection.schema_editor() as editor:
+            editor.create_model(Author)
+        old_field = Author._meta.get_field("name")
+        new_field = CharField(
+            max_length=255,
+        )
+        new_field.set_attributes_from_name("name")
+        with connection.schema_editor() as editor, self.assertNumQueries(0):
+            editor.alter_field(Author, old_field, new_field, strict=True)
+        with connection.schema_editor() as editor, self.assertNumQueries(0):
+            editor.alter_field(Author, new_field, old_field, strict=True)
         new_field.set_attributes_from_name("author")
         with connection.schema_editor() as editor, self.assertNumQueries(0):
             editor.alter_field(Book, old_field, new_field, strict=True)

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 schema.tests
git checkout 6991880109e35c879b71b7d9d9c154baeec12b89 tests/schema/tests.py
