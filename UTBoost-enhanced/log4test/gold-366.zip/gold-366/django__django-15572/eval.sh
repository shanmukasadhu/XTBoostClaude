#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 0b31e024873681e187b574fe1c4afe5e48aeeecf
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 0b31e024873681e187b574fe1c4afe5e48aeeecf tests/template_tests/test_autoreloader.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/template_tests/test_autoreloader.py b/tests/template_tests/test_autoreloader.py
index 188dca4..58d7d65 100644
--- a/tests/template_tests/test_autoreloader.py
+++ b/tests/template_tests/test_autoreloader.py
@@ -75,11 +75,30 @@ class TemplateReloadTests(SimpleTestCase):
                 ROOT / "templates",
             },
         )
+    from django.test import override_settings
+    from django.template import autoreload
+    from pathlib import Path
+    import os
+    import unittest.mock as mock
 
-    @mock.patch("django.template.loaders.base.Loader.reset")
+    @override_settings(
+        TEMPLATES=[
+            {
+                "DIRS": [""],
+                "BACKEND": "django.template.backends.django.DjangoTemplates",
+            }
+        ]
+    )
+    def test_template_dirs_ignore_empty_path(self):
+        self.assertEqual(autoreload.get_template_directories(), set())
     def test_reset_all_loaders(self, mock_reset):
         autoreload.reset_loaders()
         self.assertEqual(mock_reset.call_count, 2)
+    from django.test import override_settings
+    from django.template import autoreload
+    from pathlib import Path
+    import os
+    import unittest.mock as mock
 
     @override_settings(
         TEMPLATES=[
@@ -93,7 +112,21 @@ class TemplateReloadTests(SimpleTestCase):
             }
         ]
     )
-    def test_template_dirs_normalized_to_paths(self):
+    @override_settings(
+        TEMPLATES=[
+            {
+                "DIRS": ["", "/some/valid/path"],
+                "BACKEND": "django.template.backends.django.DjangoTemplates",
+            }
+        ]
+    )
+    def test_mixed_template_dirs(self):
+        self.assertSetEqual(
+            autoreload.get_template_directories(),
+            {
+                Path.cwd() / "some" / "valid" / "path",
+            },
+        )
         self.assertSetEqual(
             autoreload.get_template_directories(),
             {

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 template_tests.test_autoreloader
git checkout 0b31e024873681e187b574fe1c4afe5e48aeeecf tests/template_tests/test_autoreloader.py
