#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff fa5e7e46d875d4143510944f19d79df7b1739bab
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout fa5e7e46d875d4143510944f19d79df7b1739bab tests/expressions/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/expressions/tests.py b/tests/expressions/tests.py
index 872551b..274657d 100644
--- a/tests/expressions/tests.py
+++ b/tests/expressions/tests.py
@@ -13,6 +13,44 @@ from django.db.models import (
     Func, IntegerField, Max, Min, Model, OrderBy, OuterRef, Q, StdDev,
     Subquery, Sum, TimeField, UUIDField, Value, Variance, When,
 )
+class SubqueryWithSimpleLazyObjectTests(TestCase):
+    @classmethod
+    def setUpTestData(cls):
+        cls.manager = Manager.objects.create(name="Manager")
+        cls.example_inc = Company.objects.create(
+            name="Example Inc.", 
+            num_employees=2300, 
+            num_chairs=5,
+            ceo=Employee.objects.create(
+                firstname="Joe", 
+                lastname="Smith", 
+                salary=10,
+                manager=cls.manager
+            )
+        )
+
+    def test_subquery_filter_by_lazy(self):
+        max_manager = SimpleLazyObject(lambda: Manager.objects.get(pk=self.manager.pk))
+        qs = Company.objects.annotate(
+            ceo_manager=Subquery(
+                Employee.objects.filter(
+                    lastname=OuterRef('ceo__lastname'),
+                ).values('manager'),
+            ),
+        ).filter(ceo_manager=max_manager)
+        self.assertEqual(qs.get(), self.example_inc)
+
+    def test_subquery_with_different_lazy_object(self):
+        different_manager = SimpleLazyObject(lambda: Manager.objects.create(name="Different Manager"))
+        qs = Company.objects.annotate(
+            ceo_manager=Subquery(
+                Employee.objects.filter(
+                    lastname=OuterRef('ceo__lastname'),
+                ).values('manager'),
+            ),
+        ).filter(ceo_manager=different_manager)
+        self.assertFalse(qs.exists())
+
 from django.db.models.expressions import Col, Combinable, Random, RawSQL, Ref
 from django.db.models.functions import (
     Coalesce, Concat, Left, Length, Lower, Substr, Upper,
@@ -22,6 +60,8 @@ from django.db.models.sql.datastructures import Join
 from django.test import SimpleTestCase, TestCase, skipUnlessDBFeature
 from django.test.utils import Approximate, isolate_apps
 
+from django.contrib.auth.models import User
+from django.utils.functional import SimpleLazyObject
 from .models import (
     UUID, UUIDPK, Company, Employee, Experiment, Number, RemoteEmployee,
     Result, SimulationRun, Time,

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 expressions.models expressions.tests
git checkout fa5e7e46d875d4143510944f19d79df7b1739bab tests/expressions/tests.py
