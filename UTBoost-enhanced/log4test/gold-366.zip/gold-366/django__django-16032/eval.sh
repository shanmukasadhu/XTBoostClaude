#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 0c3981eb5094419fe200eb46c71b5376a2266166
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 0c3981eb5094419fe200eb46c71b5376a2266166 
git apply -v - <<'EOF_114329324912'

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 annotations.tests
git checkout 0c3981eb5094419fe200eb46c71b5376a2266166 
