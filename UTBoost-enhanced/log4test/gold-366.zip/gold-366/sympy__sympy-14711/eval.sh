#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff c6753448b5c34f95e250105d76709fe4d349ca1f
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout c6753448b5c34f95e250105d76709fe4d349ca1f sympy/physics/vector/tests/test_vector.py
git apply -v - <<'EOF_114329324912'
diff --git a/sympy/physics/vector/tests/test_vector.py b/sympy/physics/vector/tests/test_vector.py
index de6a8ff..6eaf537 100644
--- a/sympy/physics/vector/tests/test_vector.py
+++ b/sympy/physics/vector/tests/test_vector.py
@@ -4,6 +4,21 @@ from sympy.abc import x, y, z
 from sympy.utilities.pytest import raises
 
 
+from sympy.physics.vector import ReferenceFrame, Vector
+from sympy import symbols
+
+...
+
+def test_vector_add_zero():
+    N = ReferenceFrame('N')
+    assert sum([N.x, (0 * N.x)]) == N.x
+
+def test_vector_add_zero_edge_cases():
+    N = ReferenceFrame('N')
+    assert sum([0 * N.x, 0 * N.y, 0 * N.z]) == Vector(0)
+    assert sum([N.x, 0, N.y]) == N.x + N.y
+    assert sum([0, 0, 0 * N.x]) == Vector(0)
+
 Vector.simp = True
 A = ReferenceFrame('A')
 

EOF_114329324912
PYTHONWARNINGS='ignore::UserWarning,ignore::SyntaxWarning' bin/test -C --verbose sympy/physics/vector/tests/test_vector.py
git checkout c6753448b5c34f95e250105d76709fe4d349ca1f sympy/physics/vector/tests/test_vector.py
