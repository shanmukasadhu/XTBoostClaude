#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff a59de6e89e8dc1f3e71c9a5a5bbceb373ea5247e
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout a59de6e89e8dc1f3e71c9a5a5bbceb373ea5247e tests/ordering/models.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/ordering/models.py b/tests/ordering/models.py
index ec1f9e4..e4e8956 100644
--- a/tests/ordering/models.py
+++ b/tests/ordering/models.py
@@ -6,6 +6,20 @@ should be a list or tuple of field names. This tells Django how to order
 ``QuerySet`` results.
 
 If a field name in ``ordering`` starts with a hyphen, that field will be
+from django.db import models
+
+class OneModel(models.Model):
+    class Meta:
+        ordering = ("-id",)
+    id = models.BigAutoField(primary_key=True)
+    root = models.ForeignKey("OneModel", on_delete=models.CASCADE, null=True)
+    oneval = models.BigIntegerField(null=True)
+
+class TwoModel(models.Model):
+    id = models.BigAutoField(primary_key=True)
+    record = models.ForeignKey(OneModel, on_delete=models.CASCADE)
+    twoval = models.BigIntegerField(null=True)
+
 ordered in descending order. Otherwise, it'll be ordered in ascending order.
 The special-case field name ``"?"`` specifies random order.
 

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 ordering.models ordering.tests
git checkout a59de6e89e8dc1f3e71c9a5a5bbceb373ea5247e tests/ordering/models.py
