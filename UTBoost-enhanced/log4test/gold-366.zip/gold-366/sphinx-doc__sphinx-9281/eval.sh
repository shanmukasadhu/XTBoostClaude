#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 8ec06e9a1bd862cd713b9db748e039ccc7b3e15b
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .[test]
git checkout 8ec06e9a1bd862cd713b9db748e039ccc7b3e15b tests/test_util_inspect.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/test_util_inspect.py b/tests/test_util_inspect.py
index 3c31d3d..18f3320 100644
--- a/tests/test_util_inspect.py
+++ b/tests/test_util_inspect.py
@@ -516,6 +516,17 @@ def test_dict_customtype():
     assert "<CustomType(2)>: 2" in description
 
 
+def test_object_description_enum():
+    import enum
+
+    class MyEnum(enum.Enum):
+        ValueA = 10
+        ValueB = 20
+
+    assert inspect.object_description(MyEnum.ValueA) == "MyEnum.ValueA"
+    assert inspect.object_description(MyEnum.ValueB) == "MyEnum.ValueB"
+
+
 def test_getslots():
     class Foo:
         pass

EOF_114329324912
tox --current-env -epy39 -v -- tests/test_util_inspect.py
git checkout 8ec06e9a1bd862cd713b9db748e039ccc7b3e15b tests/test_util_inspect.py
