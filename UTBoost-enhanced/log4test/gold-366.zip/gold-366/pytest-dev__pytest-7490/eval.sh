#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 7f7a36478abe7dd1fa993b115d22606aa0e35e88
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 7f7a36478abe7dd1fa993b115d22606aa0e35e88 testing/test_skipping.py
git apply -v - <<'EOF_114329324912'
diff --git a/testing/test_skipping.py b/testing/test_skipping.py
index 50a5826..b098caa 100644
--- a/testing/test_skipping.py
+++ b/testing/test_skipping.py
@@ -1,3 +1,4 @@
+
 import sys
 
 import pytest
@@ -545,7 +546,31 @@ class TestXFail:
         assert result.ret == (1 if strict else 0)
 
 
-class TestXFailwithSetupTeardown:
+class TestDynamicXFail:
+    def test_dynamic_xfail_set_during_runtest_failed(self, testdir: Testdir) -> None:
+        # Issue #7486.
+        p = testdir.makepyfile(
+            """
+            import pytest
+            def test_this(request):
+                request.node.add_marker(pytest.mark.xfail(reason="xfail"))
+                assert 0
+            """
+        )
+        result = testdir.runpytest(p)
+        result.assert_outcomes(xfailed=1)
+
+    def test_dynamic_xfail_set_during_runtest_passed_strict(self, testdir: Testdir) -> None:
+        # Issue #7486.
+        p = testdir.makepyfile(
+            """
+            import pytest
+            def test_this(request):
+                request.node.add_marker(pytest.mark.xfail(reason="xfail", strict=True))
+            """
+        )
+        result = testdir.runpytest(p)
+        result.assert_outcomes(failed=1)
     def test_failing_setup_issue9(self, testdir):
         testdir.makepyfile(
             """

EOF_114329324912
pytest -rA testing/test_skipping.py
git checkout 7f7a36478abe7dd1fa993b115d22606aa0e35e88 testing/test_skipping.py
