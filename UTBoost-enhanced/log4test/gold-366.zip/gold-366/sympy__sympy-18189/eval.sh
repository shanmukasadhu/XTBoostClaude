#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 1923822ddf8265199dbd9ef9ce09641d3fd042b9
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 1923822ddf8265199dbd9ef9ce09641d3fd042b9 sympy/solvers/tests/test_diophantine.py
git apply -v - <<'EOF_114329324912'
diff --git a/sympy/solvers/tests/test_diophantine.py b/sympy/solvers/tests/test_diophantine.py
index 5de4546..6a13446 100644
--- a/sympy/solvers/tests/test_diophantine.py
+++ b/sympy/solvers/tests/test_diophantine.py
@@ -501,7 +501,11 @@ def test_diophantine():
     assert diophantine(eq, permute=True) == complete_soln
 
     assert diophantine(x**2 + x*Rational(15, 14) - 3) == set()
-    # test issue 11049
+    # test issue 18186
+    assert diophantine(y**4 + x**4 - 2**4 - 3**4, syms=(x, y), permute=True) == \
+        set([(-3, -2), (-3, 2), (-2, -3), (-2, 3), (2, -3), (2, 3), (3, -2), (3, 2)])
+    assert diophantine(y**4 + x**4 - 2**4 - 3**4, syms=(y, x), permute=True) == \
+        set([(-3, -2), (-3, 2), (-2, -3), (-2, 3), (2, -3), (2, 3), (3, -2), (3, 2)])
     eq = 92*x**2 - 99*y**2 - z**2
     coeff = eq.as_coefficients_dict()
     assert _diop_ternary_quadratic_normal((x, y, z), coeff) == \

EOF_114329324912
PYTHONWARNINGS='ignore::UserWarning,ignore::SyntaxWarning' bin/test -C --verbose sympy/solvers/tests/test_diophantine.py
git checkout 1923822ddf8265199dbd9ef9ce09641d3fd042b9 sympy/solvers/tests/test_diophantine.py
