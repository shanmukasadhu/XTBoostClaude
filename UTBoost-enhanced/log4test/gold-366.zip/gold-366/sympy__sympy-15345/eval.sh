#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 9ef28fba5b4d6d0168237c9c005a550e6dc27d81
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 9ef28fba5b4d6d0168237c9c005a550e6dc27d81 sympy/printing/tests/test_mathematica.py
git apply -v - <<'EOF_114329324912'
diff --git a/sympy/printing/tests/test_mathematica.py b/sympy/printing/tests/test_mathematica.py
index 512f405..552416b 100644
--- a/sympy/printing/tests/test_mathematica.py
+++ b/sympy/printing/tests/test_mathematica.py
@@ -1,8 +1,9 @@
+
 from sympy.core import (S, pi, oo, symbols, Function,
                         Rational, Integer, Tuple, Derivative)
 from sympy.integrals import Integral
 from sympy.concrete import Sum
-from sympy.functions import exp, sin, cos, conjugate
+from sympy.functions import exp, sin, cos, conjugate, Max, Min
 
 from sympy import mathematica_code as mcode
 
@@ -18,6 +19,11 @@ def test_Integer():
 def test_Rational():
     assert mcode(Rational(3, 7)) == "3/7"
     assert mcode(Rational(18, 9)) == "2"
+    assert mcode(Max(x, 2)) == "Max[x, 2]"
+    assert mcode(Max(2, x)) == "Max[2, x]"
+    assert mcode(Max(x, y, 2)) == "Max[x, y, 2]"
+    assert mcode(Max(2, y, x)) == "Max[2, y, x]"
+    assert mcode(Max(Min(x, y), 2)) == "Max[Min[x, y], 2]"
     assert mcode(Rational(3, -7)) == "-3/7"
     assert mcode(Rational(-3, -7)) == "3/7"
     assert mcode(x + Rational(3, 7)) == "x + 3/7"

EOF_114329324912
PYTHONWARNINGS='ignore::UserWarning,ignore::SyntaxWarning' bin/test -C --verbose sympy/printing/tests/test_mathematica.py
git checkout 9ef28fba5b4d6d0168237c9c005a550e6dc27d81 sympy/printing/tests/test_mathematica.py
