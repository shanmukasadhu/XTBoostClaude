#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff ba726067604ce5a8ca3919edf653496722b433ab
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout ba726067604ce5a8ca3919edf653496722b433ab tests/prefetch_related/models.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/prefetch_related/models.py b/tests/prefetch_related/models.py
index 3ce4b3f..23ea22c 100644
--- a/tests/prefetch_related/models.py
+++ b/tests/prefetch_related/models.py
@@ -1,3 +1,17 @@
+
+import uuid
+
+class Foo(models.Model):
+    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
+
+class Bar(models.Model):
+    foo_content_type = models.ForeignKey(
+        ContentType, related_name='actor',
+        on_delete=models.CASCADE, db_index=True
+    )
+    foo_object_id = models.CharField(max_length=255, db_index=True)
+    foo = GenericForeignKey('foo_content_type', 'foo_object_id')
+
 import uuid
 
 from django.contrib.contenttypes.fields import (

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 prefetch_related.models prefetch_related.tests
git checkout ba726067604ce5a8ca3919edf653496722b433ab tests/prefetch_related/models.py
