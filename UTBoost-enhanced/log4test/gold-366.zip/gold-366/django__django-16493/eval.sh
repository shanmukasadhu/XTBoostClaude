#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff e3a4cee081cf60650b8824f0646383b79cb110e7
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout e3a4cee081cf60650b8824f0646383b79cb110e7 tests/file_storage/models.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/file_storage/models.py b/tests/file_storage/models.py
index 3513a6b..3efae86 100644
--- a/tests/file_storage/models.py
+++ b/tests/file_storage/models.py
@@ -52,6 +52,9 @@ class Storage(models.Model):
     )
     pathlib_direct = models.FileField(storage=temp_storage, upload_to=Path("bar"))
     random = models.FileField(storage=temp_storage, upload_to=random_upload_to)
+    storage_callable_default = models.FileField(
+        storage=callable_default_storage, upload_to="storage_callable_default"
+    )
     custom_valid_name = models.FileField(
         storage=CustomValidNameStorage(location=temp_storage_location),
         upload_to=random_upload_to,

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 file_storage.models file_storage.tests
git checkout e3a4cee081cf60650b8824f0646383b79cb110e7 tests/file_storage/models.py
