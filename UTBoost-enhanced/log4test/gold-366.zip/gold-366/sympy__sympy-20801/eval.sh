#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff e11d3fed782146eebbffdc9ced0364b223b84b6c
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout e11d3fed782146eebbffdc9ced0364b223b84b6c sympy/core/tests/test_numbers.py
git apply -v - <<'EOF_114329324912'
diff --git a/sympy/core/tests/test_numbers.py b/sympy/core/tests/test_numbers.py
index 8e1c7e2..065223e 100644
--- a/sympy/core/tests/test_numbers.py
+++ b/sympy/core/tests/test_numbers.py
@@ -583,8 +583,22 @@ def test_Float():
         assert Float(i) is a
 
 
-
-@conserve_mpmath_dps
+def test_zero_not_false():
+    # https://github.com/sympy/sympy/issues/20796
+    assert (S(0.0) == S.false) is False
+    assert (S.false == S(0.0)) is False
+    assert (S(0) == S.false) is False
+    assert (S.false == S(0)) is False
+
+def test_float_false_comparisons():
+    # Additional test cases for comparison between Float and false
+    assert (S(0.0) != S.false) is True
+    assert (S.false != S(0.0)) is True
+    assert (S(0.0) == S.false) is False
+    assert (S(0) != S.false) is True
+    assert (S.false != S(0)) is True
+    assert (S.false == S.false) is True
+    assert (S.false != S.true) is True
 def test_float_mpf():
     import mpmath
     mpmath.mp.dps = 100

EOF_114329324912
PYTHONWARNINGS='ignore::UserWarning,ignore::SyntaxWarning' bin/test -C --verbose sympy/core/tests/test_numbers.py
git checkout e11d3fed782146eebbffdc9ced0364b223b84b6c sympy/core/tests/test_numbers.py
