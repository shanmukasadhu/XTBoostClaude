#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff d06c5b358149c02a62da8a5469264d05f29ac659
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout d06c5b358149c02a62da8a5469264d05f29ac659 tests/dbshell/test_mysql.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/dbshell/test_mysql.py b/tests/dbshell/test_mysql.py
index 643c2b6..5ad6e5a 100644
--- a/tests/dbshell/test_mysql.py
+++ b/tests/dbshell/test_mysql.py
@@ -68,7 +68,64 @@ class MySqlDbshellCommandTestCase(SimpleTestCase):
             (expected_args, expected_env),
         )
 
-    def test_options_password(self):
+    def test_deprecated_and_new_keys(self):
+        settings_port = 444
+        options_port = 555
+        self.assertNotEqual(settings_port, options_port, 'test pre-req')
+        expected_args = [
+            'mysql',
+            '--user=optionuser',
+            '--host=optionhost',
+            '--port=%s' % options_port,
+            'optiondbname',
+        ]
+        expected_env = {'MYSQL_PWD': 'optionpassword'}
+        for keys in [('database', 'password'), ('db', 'passwd')]:
+            with self.subTest(keys=keys):
+                database, password = keys
+                self.assertEqual(
+                    self.settings_to_cmd_args_env({
+                        'NAME': 'settingdbname',
+                        'USER': 'settinguser',
+                        'PASSWORD': 'settingpassword',
+                        'HOST': 'settinghost',
+                        'PORT': settings_port,
+                        'OPTIONS': {
+                            database: 'optiondbname',
+                            'user': 'optionuser',
+                            password: 'optionpassword',
+                            'host': 'optionhost',
+                            'port': options_port,
+                        },
+                    }),
+                    (expected_args, expected_env),
+                )
+
+    def test_options_non_deprecated_keys_preferred(self):
+        expected_args = [
+            'mysql',
+            '--user=someuser',
+            '--host=somehost',
+            '--port=444',
+            'optiondbname',
+        ]
+        expected_env = {'MYSQL_PWD': 'optionpassword'}
+        self.assertEqual(
+            self.settings_to_cmd_args_env({
+                'NAME': 'settingdbname',
+                'USER': 'someuser',
+                'PASSWORD': 'settingpassword',
+                'HOST': 'somehost',
+                'PORT': 444,
+                'OPTIONS': {
+                    'database': 'optiondbname',
+                    'db': 'deprecatedoptiondbname',
+                    'password': 'optionpassword',
+                    'passwd': 'deprecatedoptionpassword',
+                },
+            }),
+            (expected_args, expected_env),
+        )
         expected_args = [
             'mysql',
             '--user=someuser',

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 dbshell.test_mysql
git checkout d06c5b358149c02a62da8a5469264d05f29ac659 tests/dbshell/test_mysql.py
