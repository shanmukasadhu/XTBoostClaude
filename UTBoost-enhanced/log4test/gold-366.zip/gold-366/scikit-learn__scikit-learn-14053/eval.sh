#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 6ab8c86c383dd847a1be7103ad115f174fe23ffd
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -v --no-use-pep517 --no-build-isolation -e .
git checkout 6ab8c86c383dd847a1be7103ad115f174fe23ffd sklearn/tree/tests/test_export.py
git apply -v - <<'EOF_114329324912'
diff --git a/sklearn/tree/tests/test_export.py b/sklearn/tree/tests/test_export.py
index 50eb697..ad75a72 100644
--- a/sklearn/tree/tests/test_export.py
+++ b/sklearn/tree/tests/test_export.py
@@ -396,8 +396,26 @@ def test_export_text():
     assert export_text(reg, decimals=1) == expected_report
     assert export_text(reg, decimals=1, show_weights=True) == expected_report
 
+def test_export_text_single_feature():
+    from sklearn.tree import DecisionTreeClassifier
+    from sklearn.tree.export import export_text
+    from sklearn.datasets import load_iris
 
-def test_plot_tree_entropy(pyplot):
+    X, y = load_iris(return_X_y=True)
+    X = X[:, 0].reshape(-1, 1)
+
+    tree = DecisionTreeClassifier()
+    tree.fit(X, y)
+
+    expected_report = dedent("""
+    |--- sepal_length <= 5.45
+    |   |--- class: 0
+    |--- sepal_length >  5.45
+    |   |--- class: 1
+    """).lstrip()
+
+    tree_text = export_text(tree, feature_names=['sepal_length'])
+    assert tree_text == expected_report
     # mostly smoke tests
     # Check correctness of export_graphviz for criterion = entropy
     clf = DecisionTreeClassifier(max_depth=3,

EOF_114329324912
pytest -rA sklearn/tree/tests/test_export.py
git checkout 6ab8c86c383dd847a1be7103ad115f174fe23ffd sklearn/tree/tests/test_export.py
