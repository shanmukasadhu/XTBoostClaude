#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff bef6f7584280f1cc80e5e2d80b7ad073a93d26ec
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout bef6f7584280f1cc80e5e2d80b7ad073a93d26ec tests/admin_scripts/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/admin_scripts/tests.py b/tests/admin_scripts/tests.py
index d88ea78..473addb 100644
--- a/tests/admin_scripts/tests.py
+++ b/tests/admin_scripts/tests.py
@@ -1314,6 +1314,13 @@ class ManageRunserver(SimpleTestCase):
         self.assertIn('unapplied migration(s)', self.output.getvalue())
 
 
+import mock
+from io import StringIO
+from django.core.management import call_command
+from django.core.management.commands.runserver import Command as RunserverCommand
+from django.test import TestCase, override_settings
+from unittest import mock
+
 class ManageRunserverMigrationWarning(TestCase):
 
     def setUp(self):

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 admin_scripts.tests utils_tests.test_autoreload
git checkout bef6f7584280f1cc80e5e2d80b7ad073a93d26ec tests/admin_scripts/tests.py
