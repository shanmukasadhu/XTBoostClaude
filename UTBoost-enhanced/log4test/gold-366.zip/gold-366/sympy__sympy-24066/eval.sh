#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 514579c655bf22e2af14f0743376ae1d7befe345
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 514579c655bf22e2af14f0743376ae1d7befe345 sympy/physics/units/tests/test_quantities.py
git apply -v - <<'EOF_114329324912'
diff --git a/sympy/physics/units/tests/test_quantities.py b/sympy/physics/units/tests/test_quantities.py
index f2abc1d..e82ee2e 100644
--- a/sympy/physics/units/tests/test_quantities.py
+++ b/sympy/physics/units/tests/test_quantities.py
@@ -528,6 +528,10 @@ def test_issue_22819():
     assert Da.scale_factor == 1.66053906660000e-24
 
 
+from sympy import exp
+from sympy.physics import units
+from sympy.physics.units.systems.si import SI
+
 def test_issue_20288():
     from sympy.core.numbers import E
     from sympy.physics.units import energy

EOF_114329324912
PYTHONWARNINGS='ignore::UserWarning,ignore::SyntaxWarning' bin/test -C --verbose sympy/physics/units/tests/test_quantities.py
git checkout 514579c655bf22e2af14f0743376ae1d7befe345 sympy/physics/units/tests/test_quantities.py
