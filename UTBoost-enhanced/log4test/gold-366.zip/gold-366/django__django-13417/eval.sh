#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 71ae1ab0123582cc5bfe0f7d5f4cc19a9412f396
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 71ae1ab0123582cc5bfe0f7d5f4cc19a9412f396 tests/queries/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/queries/tests.py b/tests/queries/tests.py
index 8130de5..8184bb4 100644
--- a/tests/queries/tests.py
+++ b/tests/queries/tests.py
@@ -2076,6 +2076,25 @@ class QuerysetOrderedTests(unittest.TestCase):
     def test_empty_queryset(self):
         self.assertIs(Annotation.objects.none().ordered, True)
 
+    def test_annotated_default_ordering(self):
+        qs = Tag.objects.annotate(num_notes=Count('pk'))
+        self.assertIs(qs.ordered, False)
+        self.assertIs(qs.order_by('name').ordered, True)
+
+    def test_annotated_values_default_ordering(self):
+        qs = Tag.objects.values('name').annotate(num_notes=Count('pk'))
+        self.assertIs(qs.ordered, False)
+        self.assertIs(qs.order_by('name').ordered, True)
+
+    def test_annotated_group_by_no_ordering(self):
+        qs = Annotation.objects.annotate(num_notes=Count('pk'))
+        self.assertIs(qs.ordered, False)
+        self.assertTrue('ORDER BY' not in str(qs.query))
+
+    def test_annotated_order_with_explicit_order_by(self):
+        qs = Annotation.objects.annotate(num_notes=Count('pk')).order_by('name')
+        self.assertIs(qs.ordered, True)
+
     def test_order_by_extra(self):
         self.assertIs(Annotation.objects.all().extra(order_by=['id']).ordered, True)
 

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 queries.tests
git checkout 71ae1ab0123582cc5bfe0f7d5f4cc19a9412f396 tests/queries/tests.py
