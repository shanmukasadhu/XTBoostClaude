#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 770d3e6a4ce8e0a91a9e27156036c1985e74d4a3
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 770d3e6a4ce8e0a91a9e27156036c1985e74d4a3 tests/expressions/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/expressions/tests.py b/tests/expressions/tests.py
index bd890ac..014e4ad 100644
--- a/tests/expressions/tests.py
+++ b/tests/expressions/tests.py
@@ -1906,7 +1906,40 @@ class ExistsTests(TestCase):
         self.assertNotIn('ORDER BY', captured_sql)
 
 
-class FieldTransformTests(TestCase):
+from django.db.models import Exists, Q
+from django.test import TestCase
+from .models import Manager
+
+class SubqueryFilterTests(TestCase):
+    def test_negated_empty_exists(self):
+        manager = Manager.objects.create(name='test')
+        qs = Manager.objects.filter(
+            ~Exists(Manager.objects.none()) & Q(pk=manager.pk)
+        )
+        self.assertSequenceEqual(qs, [manager])
+
+    def test_exists_with_non_empty_queryset(self):
+        manager1 = Manager.objects.create(name='test1')
+        manager2 = Manager.objects.create(name='test2')
+        qs = Manager.objects.filter(
+            Exists(Manager.objects.filter(pk=manager1.pk))
+        )
+        self.assertSequenceEqual(qs, [manager1])
+
+    def test_empty_exists_with_additional_filter(self):
+        manager1 = Manager.objects.create(name='test1')
+        qs = Manager.objects.filter(
+            ~Exists(Manager.objects.none()) & Q(name='nonexistent')
+        )
+        self.assertSequenceEqual(qs, [])
+
+    def test_exists_combined_with_other_query(self):
+        manager1 = Manager.objects.create(name='test1')
+        manager2 = Manager.objects.create(name='test2')
+        qs = Manager.objects.filter(
+            Exists(Manager.objects.filter(name='test1')) | Q(name='test2')
+        )
+        self.assertSequenceEqual(qs, [manager1, manager2])
 
     @classmethod
     def setUpTestData(cls):

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 expressions.tests
git checkout 770d3e6a4ce8e0a91a9e27156036c1985e74d4a3 tests/expressions/tests.py
