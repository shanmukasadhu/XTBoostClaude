#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 67f9d076cfc1858b94f9ed6d1a5ce2327dcc8d0d
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 67f9d076cfc1858b94f9ed6d1a5ce2327dcc8d0d tests/lookup/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/lookup/tests.py b/tests/lookup/tests.py
index 057eac3..db64e15 100644
--- a/tests/lookup/tests.py
+++ b/tests/lookup/tests.py
@@ -9,6 +9,8 @@ from django.db.models import Exists, Max, OuterRef
 from django.db.models.functions import Substr
 from django.test import TestCase, skipUnlessDBFeature
 from django.utils.deprecation import RemovedInDjango40Warning
+from django.db import models
+from django.test.utils import isolate_apps
 
 from .models import (
     Article, Author, Freebie, Game, IsNullWithNoneAsRHS, Player, Season, Tag,
@@ -189,7 +191,39 @@ class LookupTests(TestCase):
             }
         )
 
-    def test_in_bulk_non_unique_field(self):
+    def test_in_bulk_with_unique_constraint(self):
+        article1 = Article.objects.create(slug='unique-slug-1')
+        article2 = Article.objects.create(slug='unique-slug-2')
+        Article.objects.create(slug='unique-slug-3')
+        self.assertEqual(
+            Article.objects.in_bulk(
+                [article1.slug, article2.slug],
+                field_name='slug',
+            ),
+            {article1.slug: article1, article2.slug: article2},
+        )
+
+    @isolate_apps('lookup')
+    def test_in_bulk_with_unique_constraint_non_active(self):
+        class Product(models.Model):
+            code = models.CharField(max_length=100)
+            is_active = models.BooleanField(default=True)
+
+            class Meta:
+                constraints = [
+                    models.UniqueConstraint(
+                        fields=['code'],
+                        name='unique_code_active',
+                        condition=models.Q(is_active=True)
+                    ),
+                ]
+
+        product1 = Product.objects.create(code='code1', is_active=True)
+        Product.objects.create(code='code2', is_active=False)
+        self.assertEqual(
+            Product.objects.in_bulk([product1.code], field_name='code'),
+            {product1.code: product1},
+        )
         msg = "in_bulk()'s field_name must be a unique field but 'author' isn't."
         with self.assertRaisesMessage(ValueError, msg):
             Article.objects.in_bulk([self.au1], field_name='author')

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 lookup.models lookup.tests
git checkout 67f9d076cfc1858b94f9ed6d1a5ce2327dcc8d0d tests/lookup/tests.py
