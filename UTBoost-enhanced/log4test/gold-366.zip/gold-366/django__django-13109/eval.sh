#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff fbe82f82555bc25dccb476c749ca062f0b522be3
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout fbe82f82555bc25dccb476c749ca062f0b522be3 tests/model_forms/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/model_forms/tests.py b/tests/model_forms/tests.py
index d60d822..d45cfba 100644
--- a/tests/model_forms/tests.py
+++ b/tests/model_forms/tests.py
@@ -1645,6 +1645,50 @@ class ModelFormBasicTests(TestCase):
         obj.full_clean()
 
 
+from django import forms
+from django.test import TestCase
+from django.core.exceptions import ValidationError
+from .models import Article, Writer, FavoriteAricles
+
+class ForeignKeyValidationTests(TestCase):
+    def setUp(self):
+        self.archived_writer = Writer.objects.create(name='Archived Writer', archived=True)
+        self.active_writer = Writer.objects.create(name='Active Writer', archived=False)
+        self.archived_article = Article.objects.create(title='Archived Article', archived=True)
+        self.active_article = Article.objects.create(title='Active Article', archived=False)
+
+    def test_foreign_key_validation_uses_base_manager(self):
+        class FavoriteAriclesForm(forms.ModelForm):
+            class Meta:
+                model = FavoriteAricles
+                fields = '__all__'
+
+            def __init__(self, *args, **kwargs):
+                super().__init__(*args, **kwargs)
+                self.fields['article'].queryset = Article._base_manager.all()
+
+        form_data = {
+            'article': self.archived_article.pk,
+        }
+        form = FavoriteAriclesForm(data=form_data)
+        self.assertTrue(form.is_valid())
+
+    def test_foreign_key_validation_uses_default_manager(self):
+        class FavoriteAriclesForm(forms.ModelForm):
+            class Meta:
+                model = FavoriteAricles
+                fields = '__all__'
+
+        form_data = {
+            'article': self.archived_article.pk,
+        }
+        form = FavoriteAriclesForm(data=form_data)
+        self.assertFalse(form.is_valid())
+        self.assertEqual(
+            form.errors,
+            {'article': ['Select a valid choice. That choice is not one of the available choices.']}
+        )
+
 class ModelMultipleChoiceFieldTests(TestCase):
     @classmethod
     def setUpTestData(cls):

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 model_forms.models model_forms.tests validation.models validation.tests
git checkout fbe82f82555bc25dccb476c749ca062f0b522be3 tests/model_forms/tests.py
