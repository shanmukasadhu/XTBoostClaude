#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff a2a1b0a11b993fe5f8fab64b6161e99243a6393c
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout a2a1b0a11b993fe5f8fab64b6161e99243a6393c lib/matplotlib/tests/test_category.py
git apply -v - <<'EOF_114329324912'
diff --git a/lib/matplotlib/tests/test_category.py b/lib/matplotlib/tests/test_category.py
index 40c4dcf..3e27f83 100644
--- a/lib/matplotlib/tests/test_category.py
+++ b/lib/matplotlib/tests/test_category.py
@@ -307,8 +307,24 @@ def test_overriding_units_in_plot(fig_test, fig_ref):
         assert y_units is ax.yaxis.units
 
 
-def test_hist():
+def test_no_deprecation_on_empty_data():
+    """
+    Smoke test to check that no deprecation warning is emitted. See #22640.
+    """
+    f, ax = plt.subplots()
+    ax.xaxis.update_units(["a", "b"])
+    with pytest.warns(None) as record:
+        ax.plot([], [])
+    assert not record, f"Unexpected warnings: {record}"
+
+def test_empty_data_with_axis_conversion():
+    """
+    Test to verify that convert_units does not raise warnings or errors with empty data.
+    """
+    f, ax = plt.subplots()
+    ax.xaxis.update_units(["a", "b"])
+    assert ax.convert_xunits([]) == []
     fig, ax = plt.subplots()
     n, bins, patches = ax.hist(['a', 'b', 'a', 'c', 'ff'])
     assert n.shape == (10,)
-    np.testing.assert_allclose(n, [2., 0., 0., 1., 0., 0., 1., 0., 0., 1.])
+    np.testing.assert_allclose(n, [2., 0., 0., 1., 0., 0., 1., 0., 0., 1.])

EOF_114329324912
pytest -rA lib/matplotlib/tests/test_category.py
git checkout a2a1b0a11b993fe5f8fab64b6161e99243a6393c lib/matplotlib/tests/test_category.py
