#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff d7c3045115693e887bcd03599b7ca4650ac5f2cb
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout d7c3045115693e887bcd03599b7ca4650ac5f2cb sympy/utilities/tests/test_lambdify.py
git apply -v - <<'EOF_114329324912'
diff --git a/sympy/utilities/tests/test_lambdify.py b/sympy/utilities/tests/test_lambdify.py
index 386dc7c..be17226 100644
--- a/sympy/utilities/tests/test_lambdify.py
+++ b/sympy/utilities/tests/test_lambdify.py
@@ -741,6 +741,27 @@ def test_special_printers():
     assert isinstance(func1(), mpi)
     assert isinstance(func2(), mpi)
 
+from sympy import Float
+from sympy.utilities.lambdify import implemented_function
+
+def test_issue_12092():
+    f = implemented_function('f', lambda x: x**2)
+    assert f(f(2)).evalf() == Float(16)
+
+def test_evalf_recursive():
+    f = implemented_function('f', lambda x: x**2)
+    g = implemented_function('g', lambda x: 2 * x)
+    assert g(2).evalf() == Float(4)
+    assert f(g(2)).evalf() == Float(16)
+    assert f(g(f(2))).evalf() == Float(64)
+
+def test_evalf_with_different_functions():
+    f = implemented_function('f', lambda x: x + 1)
+    g = implemented_function('g', lambda x: x * 3)
+    h = implemented_function('h', lambda x: x - 2)
+    assert h(g(f(2))).evalf() == Float(7)
+    assert f(g(h(5))).evalf() == Float(10)
+
 def test_true_false():
     # We want exact is comparison here, not just ==
     assert lambdify([], true)() is True

EOF_114329324912
PYTHONWARNINGS='ignore::UserWarning,ignore::SyntaxWarning' bin/test -C --verbose sympy/utilities/tests/test_lambdify.py
git checkout d7c3045115693e887bcd03599b7ca4650ac5f2cb sympy/utilities/tests/test_lambdify.py
