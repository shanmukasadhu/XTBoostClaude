#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 78ad4b4b0201003792bfdbf1a7781cbc9ee03539
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 78ad4b4b0201003792bfdbf1a7781cbc9ee03539 tests/queries/models.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/queries/models.py b/tests/queries/models.py
index a43cfb4..b6486b1 100644
--- a/tests/queries/models.py
+++ b/tests/queries/models.py
@@ -59,6 +59,39 @@ class Annotation(models.Model):
         return self.name
 
 
+class ProductMetaDataType(models.Model):
+    label = models.CharField(max_length=255, unique=True, blank=False, null=False)
+    filterable = models.BooleanField(default=False, verbose_name=_("filterable"))
+
+    class Meta:
+        app_label = "adminpricing"
+        verbose_name = _("product meta data type")
+        verbose_name_plural = _("product meta data types")
+
+    def __str__(self):
+        return self.label
+
+
+class ProductMetaData(models.Model):
+    id = models.BigAutoField(primary_key=True)
+    product = models.ForeignKey(
+        Produit, null=False, blank=False, on_delete=models.CASCADE
+    )
+    value = models.TextField(null=False, blank=False)
+    marketplace = models.ForeignKey(
+        Plateforme, null=False, blank=False, on_delete=models.CASCADE
+    )
+    date_created = models.DateTimeField(null=True, default=timezone.now)
+    metadata_type = models.ForeignKey(
+        ProductMetaDataType, null=False, blank=False, on_delete=models.CASCADE
+    )
+
+    class Meta:
+        app_label = "adminpricing"
+        verbose_name = _("product meta data")
+        verbose_name_plural = _("product meta datas")
+
+
 class DateTimePK(models.Model):
     date = models.DateTimeField(primary_key=True, auto_now_add=True)
 

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 queries.models queries.tests
git checkout 78ad4b4b0201003792bfdbf1a7781cbc9ee03539 tests/queries/models.py
