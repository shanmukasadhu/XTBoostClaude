#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 8c0886b068ba4e224dd78104b93c9638b860b398
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 8c0886b068ba4e224dd78104b93c9638b860b398 tests/template_tests/filter_tests/test_date.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/template_tests/filter_tests/test_date.py b/tests/template_tests/filter_tests/test_date.py
index c6dbc53..b5d7b97 100644
--- a/tests/template_tests/filter_tests/test_date.py
+++ b/tests/template_tests/filter_tests/test_date.py
@@ -1,8 +1,10 @@
+
 from datetime import datetime, time
 
 from django.template.defaultfilters import date
 from django.test import SimpleTestCase
-from django.utils import timezone, translation
+from django.utils import timezone, translation, formats
+from django.utils.translation import gettext_lazy
 
 from ..utils import setup
 from .timezone_utils import TimezoneTestCase
@@ -63,7 +65,13 @@ class DateTests(TimezoneTestCase):
 
     # #19370: Make sure |date doesn't blow up on a midnight time object
     @setup({"date08": '{{ t|date:"H:i" }}'})
-    def test_date08(self):
+    def test_get_format_lazy_format(self):
+        self.assertEqual(formats.get_format(gettext_lazy("DATE_FORMAT")), "N j, Y")
+
+    @setup({"datelazy": '{{ t|date:_("H:i") }}'})
+    def test_date_lazy(self):
+        output = self.engine.render_to_string("datelazy", {"t": time(0, 0)})
+        self.assertEqual(output, "00:00")
         output = self.engine.render_to_string("date08", {"t": time(0, 1)})
         self.assertEqual(output, "00:01")
 

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 i18n.tests template_tests.filter_tests.test_date
git checkout 8c0886b068ba4e224dd78104b93c9638b860b398 tests/template_tests/filter_tests/test_date.py
