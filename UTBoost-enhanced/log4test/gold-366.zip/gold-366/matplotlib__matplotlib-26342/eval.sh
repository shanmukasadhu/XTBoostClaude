#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 2aee6ccd7c7e1f8d282c1e7579f4ee546b838542
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 2aee6ccd7c7e1f8d282c1e7579f4ee546b838542 lib/matplotlib/tests/test_contour.py
git apply -v - <<'EOF_114329324912'
diff --git a/lib/matplotlib/tests/test_contour.py b/lib/matplotlib/tests/test_contour.py
index 700190c..20d1c00 100644
--- a/lib/matplotlib/tests/test_contour.py
+++ b/lib/matplotlib/tests/test_contour.py
@@ -89,6 +89,45 @@ def test_contour_no_valid_levels():
     ax.contour(np.ones((9, 9)))
 
 
+@check_figures_equal(extensions=['png'])
+def test_contour_set_paths(fig_test, fig_ref):
+    cs_test = fig_test.subplots().contour([[0, 1], [1, 2]])
+    cs_ref = fig_ref.subplots().contour([[1, 0], [2, 1]])
+
+    cs_test.set_paths(cs_ref.get_paths())
+
+@check_figures_equal(extensions=['png'])
+def test_contour_set_paths_transform(fig_test, fig_ref):
+    ax_test = fig_test.subplots()
+    ax_ref = fig_ref.subplots()
+
+    cs_test = ax_test.contour([[0, 1], [1, 2]])
+    cs_ref = ax_ref.contour([[1, 0], [2, 1]])
+
+    # Apply a transformation and verify it with set_paths
+    cs_test.set_paths(cs_ref.get_paths())
+    trans_paths = [p.transformed(ax_ref.transAxes) for p in cs_ref.get_paths()]
+    cs_test.set_paths(trans_paths)
+
+    for path_test, path_ref in zip(cs_test.get_paths(), trans_paths):
+        np.testing.assert_allclose(path_test.vertices, path_ref.vertices)
+        assert path_test.codes == path_ref.codes
+
+def test_contour_set_paths_invalid_input():
+    fig, ax = plt.subplots()
+    cs = ax.contour([[0, 1], [1, 2]])
+
+    try:
+        cs.set_paths("invalid input")
+    except TypeError:
+        pass
+    else:
+        assert False, "TypeError not raised with invalid input for set_paths"
+
+import numpy as np
+import matplotlib.pyplot as plt
+from matplotlib.testing.decorators import check_figures_equal
+
 def test_contour_Nlevels():
     # A scalar levels arg or kwarg should trigger auto level generation.
     # https://github.com/matplotlib/matplotlib/issues/11913

EOF_114329324912
pytest -rA lib/matplotlib/tests/test_contour.py
git checkout 2aee6ccd7c7e1f8d282c1e7579f4ee546b838542 lib/matplotlib/tests/test_contour.py
