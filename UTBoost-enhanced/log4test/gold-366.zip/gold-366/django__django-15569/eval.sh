#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 884b4c27f506b3c29d58509fc83a35c30ea10d94
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 884b4c27f506b3c29d58509fc83a35c30ea10d94 tests/custom_lookups/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/custom_lookups/tests.py b/tests/custom_lookups/tests.py
index 74c331a..a986aa3 100644
--- a/tests/custom_lookups/tests.py
+++ b/tests/custom_lookups/tests.py
@@ -326,7 +326,16 @@ class LookupTests(TestCase):
 
 
 class BilateralTransformTests(TestCase):
-    def test_bilateral_upper(self):
+    def test_unregister_lookup_clears_cache(self):
+        field = Article._meta.get_field("author")
+
+        # Register a lookup and verify it is cached
+        with register_lookup(models.ForeignObject, Exactly):
+            self.assertIn("exactly", field.get_lookups())
+        
+        # Unregister the lookup and verify the cache is cleared
+        models.ForeignObject._unregister_lookup(Exactly)
+        self.assertNotIn("exactly", field.get_lookups())
         with register_lookup(models.CharField, UpperBilateralTransform):
             author1 = Author.objects.create(name="Doe")
             author2 = Author.objects.create(name="doe")

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 custom_lookups.tests model_fields.test_jsonfield schema.tests
git checkout 884b4c27f506b3c29d58509fc83a35c30ea10d94 tests/custom_lookups/tests.py
