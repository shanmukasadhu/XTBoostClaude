#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 9bb204dcabe6ba0fc422bf4a45ad0c79c680d90b
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .[test]
git checkout 9bb204dcabe6ba0fc422bf4a45ad0c79c680d90b tests/test_domain_std.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/test_domain_std.py b/tests/test_domain_std.py
index 975a00f..1368af1 100644
--- a/tests/test_domain_std.py
+++ b/tests/test_domain_std.py
@@ -147,8 +147,32 @@ def test_glossary(app):
     assert ("term3", "term3", "term", "index", "term-term3", -1) in objects
     assert ("term4", "term4", "term", "index", "term-term4", -1) in objects
 
+def test_glossary_duplicate_case(app):
+    text = (".. glossary::\n"
+            "\n"
+            "   MySQL\n"
+            "       description for MySQL\n"
+            "\n"
+            "   mysql\n"
+            "       description for mysql\n")
+
+    # doctree
+    doctree = restructuredtext.parse(app, text)
+    assert_node(doctree, (
+        [glossary, definition_list, ([definition_list_item, ([term, ("MySQL", index)],
+                                                             definition)],
+                                     [definition_list_item, ([term, ("mysql", index)],
+                                                             definition)])],
+    ))
+    assert_node(doctree[0][0][0][0][1],
+                entries=[("single", "MySQL", "term-MySQL", "main", None)])
+    assert_node(doctree[0][0][1][0][1],
+                entries=[("single", "mysql", "term-mysql", "main", None)])
 
-def test_glossary_warning(app, status, warning):
+    # index
+    objects = list(app.env.get_domain("std").get_objects())
+    assert ("MySQL", "MySQL", "term", "index", "term-MySQL", -1) in objects
+    assert ("mysql", "mysql", "term", "index", "term-mysql", -1) in objects
     # empty line between terms
     text = (".. glossary::\n"
             "\n"

EOF_114329324912
tox --current-env -epy39 -v -- tests/test_domain_std.py
git checkout 9bb204dcabe6ba0fc422bf4a45ad0c79c680d90b tests/test_domain_std.py
