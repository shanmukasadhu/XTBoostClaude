#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 4c1b401e8250f9f520b3c7dc369554477ce8b15a
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 4c1b401e8250f9f520b3c7dc369554477ce8b15a tests/model_enums/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/model_enums/tests.py b/tests/model_enums/tests.py
index 6cabf01..cae4250 100644
--- a/tests/model_enums/tests.py
+++ b/tests/model_enums/tests.py
@@ -1,3 +1,4 @@
+
 import datetime
 import decimal
 import ipaddress
@@ -5,7 +6,7 @@ import uuid
 
 from django.db import models
 from django.test import SimpleTestCase
-from django.utils.functional import Promise
+from django.template import Context, Template
 from django.utils.translation import gettext_lazy as _
 
 
@@ -137,7 +138,22 @@ class ChoicesTests(SimpleTestCase):
                 # A string is not permitted as the second argument to int().
                 ONE = 1, 'X', 'Invalid'
 
-        msg = "duplicate values found in <enum 'Fruit'>: PINEAPPLE -> APPLE"
+    def test_templates(self):
+        template = Template('{{ Suit.DIAMOND.label }}|{{ Suit.DIAMOND.value }}')
+        output = template.render(Context({'Suit': Suit}))
+        self.assertEqual(output, 'Diamond|1')
+
+    def test_enum_in_template(self):
+        class YearInSchool(models.TextChoices):
+            FRESHMAN = 'FR', _('Freshman')
+            SOPHOMORE = 'SO', _('Sophomore')
+            JUNIOR = 'JR', _('Junior')
+            SENIOR = 'SR', _('Senior')
+
+        template = Template('{% if student.year_in_school == YearInSchool.FRESHMAN %}Yes{% else %}No{% endif %}')
+        context = Context({'student': {'year_in_school': YearInSchool.FRESHMAN}, 'YearInSchool': YearInSchool})
+        output = template.render(context)
+        self.assertEqual(output, 'Yes')
         with self.assertRaisesMessage(ValueError, msg):
             class Fruit(models.IntegerChoices):
                 APPLE = 1, 'Apple'

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 model_enums.tests
git checkout 4c1b401e8250f9f520b3c7dc369554477ce8b15a tests/model_enums/tests.py
