#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 619f26d2895d121854b1bed1b535d42b722e2eba
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 619f26d2895d121854b1bed1b535d42b722e2eba tests/custom_pk/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/custom_pk/tests.py b/tests/custom_pk/tests.py
index cbae2d9..37e19c2 100644
--- a/tests/custom_pk/tests.py
+++ b/tests/custom_pk/tests.py
@@ -1,5 +1,8 @@
+
 from django.db import IntegrityError, transaction
-from django.test import TestCase, skipIfDBFeature
+from django.test import TestCase, skipIfDBFeature, skipUnlessDBFeature
+from .fields import MyWrapper
+from .models import CustomAutoFieldModel
 
 from .models import Bar, Business, Employee, Foo
 
@@ -220,6 +223,17 @@ class CustomPKTests(TestCase):
         self.assertEqual(f, new_foo),
         self.assertEqual(f.bar, new_bar)
 
+
+    def test_auto_field_subclass_create(self):
+        obj = CustomAutoFieldModel.objects.create()
+        self.assertIsInstance(obj.id, MyWrapper)
+
+    @skipUnlessDBFeature('can_return_rows_from_bulk_insert')
+    def test_auto_field_subclass_bulk_create(self):
+        obj = CustomAutoFieldModel()
+        CustomAutoFieldModel.objects.bulk_create([obj])
+        self.assertIsInstance(obj.id, MyWrapper)
+
     # SQLite lets objects be saved with an empty primary key, even though an
     # integer is expected. So we can't check for an error being raised in that
     # case for SQLite. Remove it from the suite for this next bit.

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 custom_pk.fields custom_pk.models custom_pk.tests
git checkout 619f26d2895d121854b1bed1b535d42b722e2eba tests/custom_pk/tests.py
