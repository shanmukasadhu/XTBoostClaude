#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 53d8646f799de7f92ab9defe9dc56c6125448102
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 53d8646f799de7f92ab9defe9dc56c6125448102 tests/forms_tests/tests/test_forms.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/forms_tests/tests/test_forms.py b/tests/forms_tests/tests/test_forms.py
index 61f7a13..0dc8a02 100644
--- a/tests/forms_tests/tests/test_forms.py
+++ b/tests/forms_tests/tests/test_forms.py
@@ -1,3 +1,4 @@
+
 import copy
 import datetime
 import json
@@ -2486,6 +2487,25 @@ Password: <input type="password" name="password" required>
         self.assertEqual(f.errors, {})
         self.assertEqual(f.cleaned_data['file1'], 'resume.txt')
 
+    def test_filefield_with_fileinput_initial_data(self):
+        # Test case for verifying that FileInput doesn't display "required" when there is initial data.
+        class FileForm(Form):
+            file1 = forms.FileField(widget=FileInput)
+
+        # No initial data, should have "required"
+        form_no_initial = FileForm(auto_id=False)
+        self.assertHTMLEqual(
+            form_no_initial.as_table(),
+            '<tr><th>File1:</th><td><input type="file" name="file1" required></td></tr>',
+        )
+
+        # With initial data, should not have "required"
+        form_with_initial = FileForm(initial={'file1': 'resume.txt'}, auto_id=False)
+        self.assertHTMLEqual(
+            form_with_initial.as_table(),
+            '<tr><th>File1:</th><td><input type="file" name="file1"></td></tr>',
+        )
+
     def test_basic_processing_in_view(self):
         class UserRegistration(Form):
             username = CharField(max_length=10)

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 forms_tests.tests.test_forms forms_tests.widget_tests.test_fileinput
git checkout 53d8646f799de7f92ab9defe9dc56c6125448102 tests/forms_tests/tests/test_forms.py
