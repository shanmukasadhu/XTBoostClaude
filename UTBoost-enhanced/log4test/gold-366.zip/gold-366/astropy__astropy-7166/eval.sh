#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 26d147868f8a891a6009a25cd6a8576d2e1bd747
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .[test] --verbose
git checkout 26d147868f8a891a6009a25cd6a8576d2e1bd747 astropy/utils/tests/test_misc.py
git apply -v - <<'EOF_114329324912'
diff --git a/astropy/utils/tests/test_misc.py b/astropy/utils/tests/test_misc.py
index 77667e4..1d7702b 100644
--- a/astropy/utils/tests/test_misc.py
+++ b/astropy/utils/tests/test_misc.py
@@ -89,6 +89,22 @@ def test_inherit_docstrings():
         assert Subclass.__call__.__doc__ == "FOO"
 
 
+def test_property_inherit_docstrings():
+    class Base(metaclass=misc.InheritDocstrings):
+        @property
+        def bar(self):
+            "BAR"
+            return 0
+
+    class Subclass(Base):
+        @property
+        def bar(self):
+            return 42
+
+    if Base.bar.__doc__ is not None:
+        assert Subclass.bar.__doc__ == "BAR"
+
+
 def test_set_locale():
     # First, test if the required locales are available
     current = locale.setlocale(locale.LC_ALL)

EOF_114329324912
pytest -rA -vv -o console_output_style=classic --tb=no astropy/utils/tests/test_misc.py
git checkout 26d147868f8a891a6009a25cd6a8576d2e1bd747 astropy/utils/tests/test_misc.py
