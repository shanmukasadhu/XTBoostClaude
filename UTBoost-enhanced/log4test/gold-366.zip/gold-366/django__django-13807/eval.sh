#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 89fc144dedc737a79929231438f035b1d4a993c9
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 89fc144dedc737a79929231438f035b1d4a993c9 tests/backends/models.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/backends/models.py b/tests/backends/models.py
index a2fd310..65fe4ee 100644
--- a/tests/backends/models.py
+++ b/tests/backends/models.py
@@ -134,9 +134,17 @@ class RawData(models.Model):
     raw_data = models.BinaryField()
 
 
+class SQLKeywordsModel(models.Model):
+    id = models.AutoField(primary_key=True, db_column='select')
+    reporter = models.ForeignKey(Reporter, models.CASCADE, db_column='where')
+
+    class Meta:
+        db_table = 'order'
+
+
 class Author(models.Model):
     name = models.CharField(max_length=255, unique=True)
 
 
 class Book(models.Model):
-    author = models.ForeignKey(Author, models.CASCADE, to_field='name')
+    author = models.ForeignKey(Author, models.CASCADE, to_field='name')

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 backends.models backends.tests
git checkout 89fc144dedc737a79929231438f035b1d4a993c9 tests/backends/models.py
