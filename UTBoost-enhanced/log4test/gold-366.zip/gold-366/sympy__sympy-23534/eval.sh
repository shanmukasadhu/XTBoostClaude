#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 832c24fec1046eaa544a4cab4c69e3af3e651759
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 832c24fec1046eaa544a4cab4c69e3af3e651759 sympy/core/tests/test_symbol.py
git apply -v - <<'EOF_114329324912'
diff --git a/sympy/core/tests/test_symbol.py b/sympy/core/tests/test_symbol.py
index 645c231..ec053ae 100644
--- a/sympy/core/tests/test_symbol.py
+++ b/sympy/core/tests/test_symbol.py
@@ -1,5 +1,7 @@
+
 from sympy.core.numbers import (I, Rational, pi)
 from sympy.core.relational import (GreaterThan, LessThan, StrictGreaterThan, StrictLessThan)
+from sympy.core.function import Function, UndefinedFunction
 from sympy.core.symbol import (Dummy, Symbol, Wild, symbols)
 from sympy.core.sympify import sympify  # can't import as S yet
 from sympy.core.symbol import uniquely_named_symbol, _symbol, Str
@@ -294,8 +296,15 @@ def test_symbols():
     assert symbols('aa:d,x:z') == (aa, ab, ac, ad, x, y, z)
     assert symbols(('aa:d','x:z')) == ((aa, ab, ac, ad), (x, y, z))
 
+    # Test for issue: Using symbols with an extra layer of parentheses
+    q, u = symbols(('q:2', 'u:2'), cls=Function)
+    assert type(q[0]) == UndefinedFunction
+    assert type(u[1]) == UndefinedFunction
 
-    # issue 6675
+    # Check that the symbols without extra parentheses still work correctly
+    x, y = symbols('x y', cls=Function)
+    assert type(x) == UndefinedFunction
+    assert type(y) == UndefinedFunction
     def sym(s):
         return str(symbols(s))
     assert sym('a0:4') == '(a0, a1, a2, a3)'

EOF_114329324912
PYTHONWARNINGS='ignore::UserWarning,ignore::SyntaxWarning' bin/test -C --verbose sympy/core/tests/test_symbol.py
git checkout 832c24fec1046eaa544a4cab4c69e3af3e651759 sympy/core/tests/test_symbol.py
