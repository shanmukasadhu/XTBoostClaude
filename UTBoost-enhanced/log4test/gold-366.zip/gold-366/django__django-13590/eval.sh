#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 755dbf39fcdc491fe9b588358303e259c7750be4
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 755dbf39fcdc491fe9b588358303e259c7750be4 tests/expressions/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/expressions/tests.py b/tests/expressions/tests.py
index 0b4f73f..cc2c516 100644
--- a/tests/expressions/tests.py
+++ b/tests/expressions/tests.py
@@ -1,9 +1,11 @@
+
 import datetime
 import pickle
 import unittest
 import uuid
 from copy import deepcopy
 from decimal import Decimal
+from collections import namedtuple
 from unittest import mock
 
 from django.core.exceptions import FieldError
@@ -815,7 +817,40 @@ class IterableLookupInnerExpressionsTests(TestCase):
         Company.objects.create(name='5060 Ltd', num_employees=50, num_chairs=60, ceo=ceo)
         Company.objects.create(name='99300 Ltd', num_employees=99, num_chairs=300, ceo=ceo)
 
-    def test_in_lookup_allows_F_expressions_and_expressions_for_integers(self):
+    def test_range_lookup_namedtuple(self):
+        # Test using namedtuple as range filter arguments
+        EmployeeRange = namedtuple('EmployeeRange', ['minimum', 'maximum'])
+        qs = Company.objects.filter(
+            num_employees__range=EmployeeRange(minimum=51, maximum=100),
+        )
+        self.assertQuerysetEqual(
+            qs,
+            ['<Company: 99300 Ltd>'],
+            ordered=False
+        )
+
+    def test_range_lookup_namedtuple_edge_case(self):
+        # Test edge case with namedtuple containing same values
+        EmployeeRange = namedtuple('EmployeeRange', ['minimum', 'maximum'])
+        qs = Company.objects.filter(
+            num_employees__range=EmployeeRange(minimum=50, maximum=50),
+        )
+        self.assertQuerysetEqual(
+            qs,
+            [
+                '<Company: 5020 Ltd>', '<Company: 5040 Ltd>', 
+                '<Company: 5050 Ltd>', '<Company: 5060 Ltd>'
+            ],
+            ordered=False
+        )
+
+    def test_range_lookup_namedtuple_reverse(self):
+        # Test namedtuple with reversed range
+        EmployeeRange = namedtuple('EmployeeRange', ['minimum', 'maximum'])
+        qs = Company.objects.filter(
+            num_employees__range=EmployeeRange(minimum=100, maximum=51),
+        )
+        self.assertQuerysetEqual(qs, [])
         # __in lookups can use F() expressions for integers.
         queryset = Company.objects.filter(num_employees__in=([F('num_chairs') - 10]))
         self.assertQuerysetEqual(queryset, ['<Company: 5060 Ltd>'], ordered=False)

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 expressions.tests
git checkout 755dbf39fcdc491fe9b588358303e259c7750be4 tests/expressions/tests.py
