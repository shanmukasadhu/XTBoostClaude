#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 953f29f700a60fc09b08b2c2270c12c447490c6a
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 953f29f700a60fc09b08b2c2270c12c447490c6a tests/apps/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/apps/tests.py b/tests/apps/tests.py
index f7c2c67..e437a37 100644
--- a/tests/apps/tests.py
+++ b/tests/apps/tests.py
@@ -138,7 +138,31 @@ class AppsTests(SimpleTestCase):
             config = apps.get_app_config("two_configs_one_default_app")
         self.assertIsInstance(config, TwoConfig)
 
+    from django.test import override_settings
+    from django.apps import apps
+    from functools import lru_cache
+
     @override_settings(INSTALLED_APPS=SOME_INSTALLED_APPS)
+    
+    def test_clear_cache_swappable_settings(self):
+        """
+        Test that apps.clear_cache() clears the cache for get_swappable_settings_name.
+        """
+        # Simulate cache usage
+        @lru_cache()
+        def get_swappable_settings_name(value):
+            return None
+
+        get_swappable_settings_name("admin.LogEntry")
+        
+        # Clear caches
+        apps.clear_cache()
+        
+        # Verify caches are cleared
+        self.assertEqual(get_swappable_settings_name.cache_info().currsize, 0)
+
+        # Verify other caches are also cleared
+        self.assertEqual(apps.get_models.cache_info().currsize, 0)
     def test_get_app_configs(self):
         """
         Tests apps.get_app_configs().
@@ -148,7 +172,31 @@ class AppsTests(SimpleTestCase):
             [app_config.name for app_config in app_configs], SOME_INSTALLED_APPS_NAMES
         )
 
+    from django.test import override_settings
+    from django.apps import apps
+    from functools import lru_cache
+
     @override_settings(INSTALLED_APPS=SOME_INSTALLED_APPS)
+    
+    def test_clear_cache_swappable_settings(self):
+        """
+        Test that apps.clear_cache() clears the cache for get_swappable_settings_name.
+        """
+        # Simulate cache usage
+        @lru_cache()
+        def get_swappable_settings_name(value):
+            return None
+
+        get_swappable_settings_name("admin.LogEntry")
+        
+        # Clear caches
+        apps.clear_cache()
+        
+        # Verify caches are cleared
+        self.assertEqual(get_swappable_settings_name.cache_info().currsize, 0)
+
+        # Verify other caches are also cleared
+        self.assertEqual(apps.get_models.cache_info().currsize, 0)
     def test_get_app_config(self):
         """
         Tests apps.get_app_config().
@@ -166,7 +214,31 @@ class AppsTests(SimpleTestCase):
         with self.assertRaisesMessage(LookupError, msg):
             apps.get_app_config("django.contrib.auth")
 
+    from django.test import override_settings
+    from django.apps import apps
+    from functools import lru_cache
+
     @override_settings(INSTALLED_APPS=SOME_INSTALLED_APPS)
+    
+    def test_clear_cache_swappable_settings(self):
+        """
+        Test that apps.clear_cache() clears the cache for get_swappable_settings_name.
+        """
+        # Simulate cache usage
+        @lru_cache()
+        def get_swappable_settings_name(value):
+            return None
+
+        get_swappable_settings_name("admin.LogEntry")
+        
+        # Clear caches
+        apps.clear_cache()
+        
+        # Verify caches are cleared
+        self.assertEqual(get_swappable_settings_name.cache_info().currsize, 0)
+
+        # Verify other caches are also cleared
+        self.assertEqual(apps.get_models.cache_info().currsize, 0)
     def test_is_installed(self):
         """
         Tests apps.is_installed().
@@ -176,7 +248,31 @@ class AppsTests(SimpleTestCase):
         self.assertIs(apps.is_installed("django.contrib.staticfiles"), True)
         self.assertIs(apps.is_installed("django.contrib.admindocs"), False)
 
+    from django.test import override_settings
+    from django.apps import apps
+    from functools import lru_cache
+
     @override_settings(INSTALLED_APPS=SOME_INSTALLED_APPS)
+    
+    def test_clear_cache_swappable_settings(self):
+        """
+        Test that apps.clear_cache() clears the cache for get_swappable_settings_name.
+        """
+        # Simulate cache usage
+        @lru_cache()
+        def get_swappable_settings_name(value):
+            return None
+
+        get_swappable_settings_name("admin.LogEntry")
+        
+        # Clear caches
+        apps.clear_cache()
+        
+        # Verify caches are cleared
+        self.assertEqual(get_swappable_settings_name.cache_info().currsize, 0)
+
+        # Verify other caches are also cleared
+        self.assertEqual(apps.get_models.cache_info().currsize, 0)
     def test_get_model(self):
         """
         Tests apps.get_model().

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 apps.tests
git checkout 953f29f700a60fc09b08b2c2270c12c447490c6a tests/apps/tests.py
