#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 19e6efa50b603af325e7f62058364f278596758f
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 19e6efa50b603af325e7f62058364f278596758f tests/async/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/async/tests.py b/tests/async/tests.py
index 72e103e..1653afa 100644
--- a/tests/async/tests.py
+++ b/tests/async/tests.py
@@ -1,3 +1,4 @@
+
 import asyncio
 import os
 from unittest import mock
@@ -6,7 +7,8 @@ from asgiref.sync import async_to_sync
 
 from django.core.cache import DEFAULT_CACHE_ALIAS, caches
 from django.core.exceptions import ImproperlyConfigured, SynchronousOnlyOperation
-from django.http import HttpResponse
+from django.http import HttpResponse, HttpResponseNotAllowed
+from django.test import RequestFactory
 from django.test import SimpleTestCase
 from django.utils.asyncio import async_unsafe
 from django.views.generic.base import View
@@ -119,7 +121,42 @@ class ViewTests(SimpleTestCase):
 
                 self.assertIsInstance(response, HttpResponse)
 
-    def test_base_view_class_is_sync(self):
+    def test_http_method_not_allowed_responds_correctly(self):
+        """
+        Test to ensure http_method_not_allowed returns the correct
+        HttpResponseNotAllowed type and handles async correctly.
+        """
+        request_factory = RequestFactory()
+        tests = [
+            (SyncView, False),
+            (AsyncView, True),
+        ]
+        for view_cls, is_coroutine in tests:
+            with self.subTest(view_cls=view_cls, is_coroutine=is_coroutine):
+                instance = view_cls()
+                response = instance.http_method_not_allowed(request_factory.post("/"))
+                self.assertIs(
+                    asyncio.iscoroutine(response),
+                    is_coroutine,
+                )
+                if is_coroutine:
+                    response = asyncio.run(response)
+
+                self.assertIsInstance(response, HttpResponseNotAllowed)
+
+    def test_demo_view_get_method(self):
+        """
+        Test that a GET request to the Demo view returns HttpResponseNotAllowed.
+        """
+        class Demo(View):
+            """This basic view supports only POST requests"""
+            async def post(self, request):
+                return HttpResponse("ok")
+
+        request_factory = RequestFactory()
+        instance = Demo()
+        response = instance.http_method_not_allowed(request_factory.get("/demo"))
+        self.assertIsInstance(response, HttpResponseNotAllowed)
         """
         View and by extension any subclasses that don't define handlers are
         sync.

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 async.tests
git checkout 19e6efa50b603af325e7f62058364f278596758f tests/async/tests.py
