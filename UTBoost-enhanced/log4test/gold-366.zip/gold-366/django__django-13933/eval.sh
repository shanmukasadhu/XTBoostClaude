#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 42e8cf47c7ee2db238bf91197ea398126c546741
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 42e8cf47c7ee2db238bf91197ea398126c546741 tests/forms_tests/tests/test_error_messages.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/forms_tests/tests/test_error_messages.py b/tests/forms_tests/tests/test_error_messages.py
index 881a5a8..1ea261c 100644
--- a/tests/forms_tests/tests/test_error_messages.py
+++ b/tests/forms_tests/tests/test_error_messages.py
@@ -281,8 +281,25 @@ class FormsErrorMessagesTestCase(SimpleTestCase, AssertFormErrorsMixin):
             '</ul></li></ul>'
         )
 
+from django.test import TestCase
+from django.forms import ModelChoiceField, ModelMultipleChoiceField
+from .models import ChoiceModel
 
 class ModelChoiceFieldErrorMessagesTestCase(TestCase, AssertFormErrorsMixin):
+    def test_modelchoicefield_value_placeholder(self):
+        # Test the invalid choice value is included in the error message
+        f = ModelChoiceField(
+            queryset=ChoiceModel.objects.all(),
+            error_messages={
+                'invalid_choice': '"%(value)s" is not one of the available choices.',
+            },
+        )
+        self.assertFormErrors(
+            ['"invalid" is not one of the available choices.'],
+            f.clean,
+            'invalid',
+        )
+
     def test_modelchoicefield(self):
         # Create choices for the model choice field tests below.
         ChoiceModel.objects.create(pk=1, name='a')
@@ -298,6 +315,20 @@ class ModelChoiceFieldErrorMessagesTestCase(TestCase, AssertFormErrorsMixin):
         self.assertFormErrors(['REQUIRED'], f.clean, '')
         self.assertFormErrors(['INVALID CHOICE'], f.clean, '4')
 
+    def test_modelmultiplechoicefield_value_placeholder(self):
+        # Test ModelMultipleChoiceField with an invalid choice and placeholder
+        f = ModelMultipleChoiceField(
+            queryset=ChoiceModel.objects.all(),
+            error_messages={
+                'invalid_choice': '"%(value)s" is not one of the available choices.',
+            },
+        )
+        self.assertFormErrors(
+            ['"invalid" is not one of the available choices.'],
+            f.clean,
+            ['invalid'],
+        )
+
         # ModelMultipleChoiceField
         e = {
             'required': 'REQUIRED',
@@ -307,4 +338,4 @@ class ModelChoiceFieldErrorMessagesTestCase(TestCase, AssertFormErrorsMixin):
         f = ModelMultipleChoiceField(queryset=ChoiceModel.objects.all(), error_messages=e)
         self.assertFormErrors(['REQUIRED'], f.clean, '')
         self.assertFormErrors(['NOT A LIST OF VALUES'], f.clean, '3')
-        self.assertFormErrors(['4 IS INVALID CHOICE'], f.clean, ['4'])
+        self.assertFormErrors(['4 IS INVALID CHOICE'], f.clean, ['4'])

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 forms_tests.tests.test_error_messages
git checkout 42e8cf47c7ee2db238bf91197ea398126c546741 tests/forms_tests/tests/test_error_messages.py
