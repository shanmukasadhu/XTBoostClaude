#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 2dfa7457f20ee187fbb09b5b6a1631da4458388c
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 2dfa7457f20ee187fbb09b5b6a1631da4458388c sympy/matrices/tests/test_sparse.py
git apply -v - <<'EOF_114329324912'
diff --git a/sympy/matrices/tests/test_sparse.py b/sympy/matrices/tests/test_sparse.py
index 4d1c3fc..2cdc3a5 100644
--- a/sympy/matrices/tests/test_sparse.py
+++ b/sympy/matrices/tests/test_sparse.py
@@ -490,6 +490,23 @@ def test_errors():
         lambda: SparseMatrix(1, 2, [1, 2]) + SparseMatrix(2, 1, [2, 1]))
 
 
+def test_hstack_vstack_issue():
+    # Test for hstack with 0 x n matrices
+    sparse_matrices = [SparseMatrix.zeros(0, n) for n in range(4)]
+    assert SparseMatrix.hstack(*sparse_matrices).shape == (0, 6)
+
+    # Test for vstack with n x 0 matrices
+    sparse_matrices = [SparseMatrix.zeros(n, 0) for n in range(4)]
+    assert SparseMatrix.vstack(*sparse_matrices).shape == (6, 0)
+
+    # Additional tests for hstack with 1 x n matrices
+    sparse_matrices = [SparseMatrix.zeros(1, n) for n in range(4)]
+    assert SparseMatrix.hstack(*sparse_matrices).shape == (1, 6)
+
+    # Additional tests for vstack with n x 1 matrices
+    sparse_matrices = [SparseMatrix.zeros(n, 1) for n in range(4)]
+    assert SparseMatrix.vstack(*sparse_matrices).shape == (6, 1)
+
 def test_len():
     assert not SparseMatrix()
     assert SparseMatrix() == SparseMatrix([])

EOF_114329324912
PYTHONWARNINGS='ignore::UserWarning,ignore::SyntaxWarning' bin/test -C --verbose sympy/matrices/tests/test_sparse.py
git checkout 2dfa7457f20ee187fbb09b5b6a1631da4458388c sympy/matrices/tests/test_sparse.py
