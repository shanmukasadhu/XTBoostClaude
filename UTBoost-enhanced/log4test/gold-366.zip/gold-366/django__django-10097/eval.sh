#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
export LANG=en_US.UTF-8
export LC_ALL=en_US.UTF-8
export PYTHONIOENCODING=utf8
export LANGUAGE=en_US:en
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff b9cf764be62e77b4777b3a75ec256f6209a57671
source /opt/miniconda3/bin/activate
conda activate testbed
python setup.py install
git checkout b9cf764be62e77b4777b3a75ec256f6209a57671 tests/validators/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/validators/tests.py b/tests/validators/tests.py
index 90c3285..d807267 100644
--- a/tests/validators/tests.py
+++ b/tests/validators/tests.py
@@ -218,6 +218,19 @@ TEST_DATA = [
     (URLValidator(EXTENDED_SCHEMES), 'git+ssh://git@github.com/example/hg-git.git', None),
 
     (URLValidator(EXTENDED_SCHEMES), 'git://-invalid.com', ValidationError),
+
+    # Test cases for invalid characters in the username and password
+    (URLValidator(), 'http://foo@bar@example.com', ValidationError),
+    (URLValidator(), 'http://foo/bar@example.com', ValidationError),
+    (URLValidator(), 'http://foo:bar:baz@example.com', ValidationError),
+    (URLValidator(), 'http://foo:bar@baz@example.com', ValidationError),
+    (URLValidator(), 'http://foo:bar/baz@example.com', ValidationError),
+    (URLValidator(), 'http://invalid-.com/?m=foo@example.com', ValidationError),
+    (URLValidator(), "http://-.~_!$&'()*+,;=%40:80%2f@example.com", ValidationError),
+
+    # Test cases for valid encoded characters in username and password
+    (URLValidator(), 'http://foo%40bar:%40baz@example.com', None),
+    (URLValidator(), 'http://user:pass%2Fword@example.com', None),
     # Trailing newlines not accepted
     (URLValidator(), 'http://www.djangoproject.com/\n', ValidationError),
     (URLValidator(), 'http://[::ffff:192.9.5.5]\n', ValidationError),

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1
git checkout b9cf764be62e77b4777b3a75ec256f6209a57671 tests/validators/tests.py
