#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 6e9c5ee88fc948e05b4a7d9f82a8861ed2b0343d
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 6e9c5ee88fc948e05b4a7d9f82a8861ed2b0343d tests/sessions_tests/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/sessions_tests/tests.py b/tests/sessions_tests/tests.py
index e3a089f..02938ae 100644
--- a/tests/sessions_tests/tests.py
+++ b/tests/sessions_tests/tests.py
@@ -312,6 +312,13 @@ class SessionTestsMixin:
         self.assertEqual(self.session.decode(encoded), data)
 
     @override_settings(SECRET_KEY='django_tests_secret_key')
+    @ignore_warnings(category=RemovedInDjango40Warning)
+    def test_default_hashing_algorithm_legacy_decode(self):
+        with self.settings(DEFAULT_HASHING_ALGORITHM='sha1'):
+            data = {'a test key': 'a test value'}
+            encoded = self.session.encode(data)
+            self.assertEqual(self.session._legacy_decode(encoded), data)
+
     def test_decode_legacy(self):
         # RemovedInDjango40Warning: pre-Django 3.1 sessions will be invalid.
         legacy_encoded = (
@@ -323,6 +330,13 @@ class SessionTestsMixin:
             {'a test key': 'a test value'},
         )
 
+    def test_sha1_legacy_decode_with_invalid_data(self):
+        with self.settings(DEFAULT_HASHING_ALGORITHM='sha1'):
+            invalid_data = 'invalid_data'
+            with self.assertLogs('django.security.SuspiciousSession', 'WARNING') as cm:
+                self.assertEqual(self.session._legacy_decode(invalid_data), {})
+            self.assertIn('corrupted', cm.output[0])
+
     def test_decode_failure_logged_to_security(self):
         bad_encode = base64.b64encode(b'flaskdj:alkdjf').decode('ascii')
         with self.assertLogs('django.security.SuspiciousSession', 'WARNING') as cm:

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 sessions_tests.tests
git checkout 6e9c5ee88fc948e05b4a7d9f82a8861ed2b0343d tests/sessions_tests/tests.py
