#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 37522e991a32ee3c0ad1a5ff8afe8e3eb1885550
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 37522e991a32ee3c0ad1a5ff8afe8e3eb1885550 xarray/tests/test_coding.py
git apply -v - <<'EOF_114329324912'
diff --git a/xarray/tests/test_coding.py b/xarray/tests/test_coding.py
index 2dbb0b4..88f7359 100644
--- a/xarray/tests/test_coding.py
+++ b/xarray/tests/test_coding.py
@@ -2,6 +2,16 @@ from contextlib import suppress
 
 import numpy as np
 import pandas as pd
+@pytest.mark.parametrize("engine", ["netcdf4", "pydap"])
+def test_opendap_signed_byte_handling(engine):
+    # URL for test dataset
+    url = "https://observations.ipsl.fr/thredds/dodsC/EUREC4A/PRODUCTS/testdata/netcdf_testfiles/test_NC_BYTE_neg.nc"
+    ds = xr.open_dataset(url, engine=engine)
+    expected_values = np.array([-128.0, -1.0, 0.0, 1.0, 2.0, np.nan, 127.0], dtype=np.float32)
+    
+    # Check if the coordinates match the expected signed values
+    assert np.allclose(ds.coords['test'].values, expected_values, equal_nan=True)
+
 import pytest
 
 import xarray as xr
@@ -9,6 +19,7 @@ from xarray.coding import variables
 from xarray.conventions import decode_cf_variable, encode_cf_variable
 
 from . import assert_allclose, assert_equal, assert_identical, requires_dask
+import numpy as np
 
 with suppress(ImportError):
     import dask.array as da

EOF_114329324912
pytest -rA xarray/tests/test_coding.py
git checkout 37522e991a32ee3c0ad1a5ff8afe8e3eb1885550 xarray/tests/test_coding.py
