#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 4e8121e8e42a24acc3565851c9ef50ca8322b15c
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 4e8121e8e42a24acc3565851c9ef50ca8322b15c tests/migrations/test_state.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/migrations/test_state.py b/tests/migrations/test_state.py
index 11009e5..999068b 100644
--- a/tests/migrations/test_state.py
+++ b/tests/migrations/test_state.py
@@ -924,6 +924,33 @@ class StateTests(SimpleTestCase):
             1,
         )
 
+    def test_real_apps_as_set(self):
+        """
+        Test ProjectState initialization with real_apps as a set.
+        """
+        try:
+            ProjectState(real_apps={'contenttypes'})
+        except AssertionError:
+            self.fail("ProjectState raised AssertionError unexpectedly!")
+
+    def test_real_apps_as_none(self):
+        """
+        Test ProjectState initialization with real_apps as None.
+        """
+        try:
+            ProjectState(real_apps=None)
+        except AssertionError:
+            self.fail("ProjectState raised AssertionError unexpectedly!")
+
+    def test_real_apps_as_empty_set(self):
+        """
+        Test ProjectState initialization with real_apps as an empty set.
+        """
+        try:
+            ProjectState(real_apps=set())
+        except AssertionError:
+            self.fail("ProjectState raised AssertionError unexpectedly!")
+
     def test_ignore_order_wrt(self):
         """
         Makes sure ProjectState doesn't include OrderWrt fields when

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 migrations.test_state
git checkout 4e8121e8e42a24acc3565851c9ef50ca8322b15c tests/migrations/test_state.py
