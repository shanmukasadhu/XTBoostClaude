#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff a3011dfd1aaa2487cce8aa7369475533133ef777
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout a3011dfd1aaa2487cce8aa7369475533133ef777 lib/matplotlib/tests/test_colors.py
git apply -v - <<'EOF_114329324912'
diff --git a/lib/matplotlib/tests/test_colors.py b/lib/matplotlib/tests/test_colors.py
index 2be14fe..c5f1e56 100644
--- a/lib/matplotlib/tests/test_colors.py
+++ b/lib/matplotlib/tests/test_colors.py
@@ -20,6 +20,17 @@ import matplotlib.scale as mscale
 from matplotlib.testing.decorators import image_comparison, check_figures_equal
 
 
+import pytest
+import numpy as np
+import matplotlib as mpl
+from numpy.testing import assert_array_equal
+
+@pytest.mark.parametrize("dtype", [np.uint8, int, np.float16, float])
+def test_index_dtype(dtype):
+    # We use subtraction in the indexing, so need to verify that uint8 works
+    cm = mpl.colormaps["viridis"]
+    assert_array_equal(cm(dtype(0)), cm(0))
+
 @pytest.mark.parametrize('N, result', [
     (5, [1, .6, .2, .1, 0]),
     (2, [1, 0]),

EOF_114329324912
pytest -rA lib/matplotlib/tests/test_colors.py
git checkout a3011dfd1aaa2487cce8aa7369475533133ef777 lib/matplotlib/tests/test_colors.py
