#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 28d913d3cead6c5646307ffa6540b21d65059dfd
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 28d913d3cead6c5646307ffa6540b21d65059dfd sympy/functions/elementary/tests/test_miscellaneous.py
git apply -v - <<'EOF_114329324912'
diff --git a/sympy/functions/elementary/tests/test_miscellaneous.py b/sympy/functions/elementary/tests/test_miscellaneous.py
index 821fd0c..e12355d 100644
--- a/sympy/functions/elementary/tests/test_miscellaneous.py
+++ b/sympy/functions/elementary/tests/test_miscellaneous.py
@@ -76,6 +76,10 @@ def test_Min():
     assert Min(oo, nn) == nn
     assert Min(p, p) == p
     assert Min(p, oo) == p
+
+    # Test zero-argument Min and Max
+    assert Min() == S.Infinity
+    assert Max() == S.NegativeInfinity
     assert Min(oo, p) == p
     assert Min(oo, oo) == oo
 
@@ -87,6 +91,12 @@ def test_Min():
     # lists
     raises(ValueError, lambda: Min())
     assert Min(x, y) == Min(y, x)
+
+    # Additional tests for zero-argument Min and Max
+    assert Min(1) == 1
+    assert Max(1) == 1
+    assert Min(1, 2) == 1
+    assert Max(1, 2) == 2
     assert Min(x, y, z) == Min(z, y, x)
     assert Min(x, Min(y, z)) == Min(z, y, x)
     assert Min(x, Max(y, -oo)) == Min(x, y)
@@ -154,10 +164,20 @@ def test_Max():
 
     assert Max(5, 4) == 5
 
+    # Test zero-argument Min and Max
+    assert Min() == S.Infinity
+    assert Max() == S.NegativeInfinity
+
     # lists
 
     raises(ValueError, lambda: Max())
     assert Max(x, y) == Max(y, x)
+
+    # Additional tests for zero-argument Min and Max
+    assert Min(3, 5, -1) == -1
+    assert Max(3, 5, -1) == 5
+    assert Min(-5, -10) == -10
+    assert Max(-5, -10) == -5
     assert Max(x, y, z) == Max(z, y, x)
     assert Max(x, Max(y, z)) == Max(z, y, x)
     assert Max(x, Min(y, oo)) == Max(x, y)
@@ -166,6 +186,10 @@ def test_Max():
     assert Max(2, x, p, n, -oo, S.NegativeInfinity, n_, p, 2) == Max(2, x, p)
     assert Max(0, x, 1, y) == Max(1, x, y)
     assert Max(r, r + 1, r - 1) == 1 + r
+
+    # Test edge cases
+    assert Min(S.Infinity) == S.Infinity
+    assert Max(S.NegativeInfinity) == S.NegativeInfinity
     assert Max(1000, 100, -100, x, p, n) == Max(p, x, 1000)
     assert Max(cos(x), sin(x)) == Max(sin(x), cos(x))
     assert Max(cos(x), sin(x)).subs(x, 1) == sin(1)

EOF_114329324912
PYTHONWARNINGS='ignore::UserWarning,ignore::SyntaxWarning' bin/test -C --verbose sympy/functions/elementary/tests/test_miscellaneous.py
git checkout 28d913d3cead6c5646307ffa6540b21d65059dfd sympy/functions/elementary/tests/test_miscellaneous.py
