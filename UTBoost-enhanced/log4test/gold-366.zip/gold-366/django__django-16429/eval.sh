#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 6c86495bcee22eac19d7fb040b2988b830707cbd
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 6c86495bcee22eac19d7fb040b2988b830707cbd tests/utils_tests/test_timesince.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/utils_tests/test_timesince.py b/tests/utils_tests/test_timesince.py
index f795bf7..69cc2e9 100644
--- a/tests/utils_tests/test_timesince.py
+++ b/tests/utils_tests/test_timesince.py
@@ -1,3 +1,4 @@
+
 import datetime
 
 from django.test import TestCase
@@ -236,7 +237,26 @@ class TimesinceTests(TestCase):
             with self.subTest():
                 self.assertEqual(timesince(t, value), expected)
 
-    def test_depth_invalid(self):
+    @requires_tz_support
+    @override_settings(USE_TZ=True)
+    def test_long_interval_with_tz(self):
+        now = timezone.now()
+        d = now - datetime.timedelta(days=31)
+        self.assertEqual(timesince(d), "1\xa0month")
+
+    @requires_tz_support
+    @override_settings(USE_TZ=True)
+    def test_long_interval_with_tz_more_than_month(self):
+        now = timezone.now()
+        d = now - datetime.timedelta(days=61)
+        self.assertEqual(timesince(d), "2\xa0months")
+
+    @requires_tz_support
+    @override_settings(USE_TZ=True)
+    def test_long_interval_with_tz_edge_case(self):
+        now = timezone.now()
+        d = now - datetime.timedelta(days=30)
+        self.assertEqual(timesince(d), "4\xa0weeks")
         msg = "depth must be greater than 0."
         with self.assertRaisesMessage(ValueError, msg):
             timesince(self.t, self.t, depth=0)

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 utils_tests.test_timesince
git checkout 6c86495bcee22eac19d7fb040b2988b830707cbd tests/utils_tests/test_timesince.py
