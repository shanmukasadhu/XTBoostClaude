#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff bfc4a566423e036fbdc9fb02765fd893e4860c85
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -v --no-use-pep517 --no-build-isolation -e .
git checkout bfc4a566423e036fbdc9fb02765fd893e4860c85 sklearn/tests/test_base.py
git apply -v - <<'EOF_114329324912'
diff --git a/sklearn/tests/test_base.py b/sklearn/tests/test_base.py
index 4752f9c..f747109 100644
--- a/sklearn/tests/test_base.py
+++ b/sklearn/tests/test_base.py
@@ -154,7 +154,23 @@ def test_clone_nan():
     assert clf.empty is clf2.empty
 
 
-def test_clone_sparse_matrices():
+from sklearn.base import clone
+from sklearn.preprocessing import StandardScaler
+
+def test_clone_estimator_types():
+    # Check that clone works for parameters that are types rather than instances
+    class MyEstimator:
+        def __init__(self, empty=None):
+            self.empty = empty
+
+        def get_params(self, deep=False):
+            return {'empty': self.empty}
+
+    # Use the issue's example to test clone with an estimator type as a parameter
+    clf = MyEstimator(empty=StandardScaler)
+    clf2 = clone(clf)
+
+    assert clf.empty is clf2.empty
     sparse_matrix_classes = [
         getattr(sp, name)
         for name in dir(sp) if name.endswith('_matrix')]

EOF_114329324912
pytest -rA sklearn/tests/test_base.py
git checkout bfc4a566423e036fbdc9fb02765fd893e4860c85 sklearn/tests/test_base.py
