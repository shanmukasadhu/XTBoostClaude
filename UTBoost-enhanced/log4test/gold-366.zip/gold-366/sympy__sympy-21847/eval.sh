#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff d9b18c518d64d0ebe8e35a98c2fb519938b9b151
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout d9b18c518d64d0ebe8e35a98c2fb519938b9b151 sympy/polys/tests/test_monomials.py
git apply -v - <<'EOF_114329324912'
diff --git a/sympy/polys/tests/test_monomials.py b/sympy/polys/tests/test_monomials.py
index e0d22ab..eeef34d 100644
--- a/sympy/polys/tests/test_monomials.py
+++ b/sympy/polys/tests/test_monomials.py
@@ -15,6 +15,8 @@ from sympy.abc import a, b, c, x, y, z
 from sympy.core import S, symbols
 from sympy.testing.pytest import raises
 
+from sympy.polys.monomials import itermonomials
+from sympy.polys.orderings import monomial_key
 
 def test_monomials():
 
@@ -49,8 +51,17 @@ def test_monomials():
     assert set(itermonomials([x, y], 2)) == {S.One, x, y, x**2, y**2, x*y}
     assert set(itermonomials([x, y], 3)) == \
             {S.One, x, y, x**2, x**3, y**2, y**3, x*y, x*y**2, y*x**2}
-
-    i, j, k = symbols('i j k', commutative=False)
+    
+    # Testing issue with min_degrees and max_degrees both set to 3
+    x1, x2, x3 = symbols('x1 x2 x3')
+    monomials = sorted(itermonomials([x1, x2, x3], 3, min_degrees=3), key=monomial_key('grlex', [x1, x2, x3]))
+    assert set(monomials) == {x1**3, x2**3, x3**3, x1 * x2**2, x1 * x3**2, x2 * x1**2, x2 * x3**2, x3 * x1**2, x3 * x2**2, x1 * x2 * x3}
+
+    # Additional test cases for varying min_degrees and max_degrees
+    monomials = sorted(itermonomials([x1, x2, x3], 4, min_degrees=3), key=monomial_key('grlex', [x1, x2, x3]))
+    assert x1 * x2 * x3 in monomials
+    assert x1 * x2**2 in monomials
+    assert x1**2 * x2 in monomials
     assert set(itermonomials([i, j, k], 0)) == {S.One}
     assert set(itermonomials([i, j, k], 1)) == {S.One, i, j, k}
     assert set(itermonomials([i, j, k], 2)) == \
@@ -130,8 +141,17 @@ def test_monomials():
     assert set(itermonomials([x, y], [2, 1])) == {S.One, x, y, x*y, x**2, x**2*y}
     assert set(itermonomials([x, y], [2, 2])) == \
             {S.One, y**2, x*y**2, x, x*y, x**2, x**2*y**2, y, x**2*y}
-
-    i, j, k = symbols('i j k', commutative=False)
+    
+    # Testing issue with min_degrees and max_degrees both set to 3
+    x1, x2, x3 = symbols('x1 x2 x3')
+    monomials = sorted(itermonomials([x1, x2, x3], 3, min_degrees=3), key=monomial_key('grlex', [x1, x2, x3]))
+    assert set(monomials) == {x1**3, x2**3, x3**3, x1 * x2**2, x1 * x3**2, x2 * x1**2, x2 * x3**2, x3 * x1**2, x3 * x2**2, x1 * x2 * x3}
+
+    # Additional test cases for varying min_degrees and max_degrees
+    monomials = sorted(itermonomials([x1, x2, x3], 4, min_degrees=3), key=monomial_key('grlex', [x1, x2, x3]))
+    assert x1 * x2 * x3 in monomials
+    assert x1 * x2**2 in monomials
+    assert x1**2 * x2 in monomials
     assert set(itermonomials([i, j, k], [0, 0, 0])) == {S.One}
     assert set(itermonomials([i, j, k], [0, 0, 1])) == {1, k}
     assert set(itermonomials([i, j, k], [0, 1, 0])) == {1, j}

EOF_114329324912
PYTHONWARNINGS='ignore::UserWarning,ignore::SyntaxWarning' bin/test -C --verbose sympy/polys/tests/test_monomials.py
git checkout d9b18c518d64d0ebe8e35a98c2fb519938b9b151 sympy/polys/tests/test_monomials.py
