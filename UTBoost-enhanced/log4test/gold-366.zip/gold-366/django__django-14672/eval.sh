#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 00ea883ef56fb5e092cbe4a6f7ff2e7470886ac4
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 00ea883ef56fb5e092cbe4a6f7ff2e7470886ac4 tests/m2m_through/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/m2m_through/tests.py b/tests/m2m_through/tests.py
index d9eaabe..3894456 100644
--- a/tests/m2m_through/tests.py
+++ b/tests/m2m_through/tests.py
@@ -2,6 +2,7 @@ from datetime import date, datetime, timedelta
 from operator import attrgetter
 
 from django.db import IntegrityError
+from .models import Parent, ProxyParent, Child, ManyToManyModel
 from django.test import TestCase
 
 from .models import (
@@ -9,6 +10,8 @@ from .models import (
     Invitation, Membership, Person, PersonSelfRefM2M, Recipe, RecipeIngredient,
     Relationship, SymmetricalFriendship,
 )
+from django.core.checks import Error
+from django.db import models
 
 
 class M2mThroughTests(TestCase):

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 invalid_models_tests.test_models m2m_through.models m2m_through.tests
git checkout 00ea883ef56fb5e092cbe4a6f7ff2e7470886ac4 tests/m2m_through/tests.py
