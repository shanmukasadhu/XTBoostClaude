#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff a7b8b9e9e16d4e15fabda5ae615086c2e1c47d8a
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -v --no-use-pep517 --no-build-isolation -e .
git checkout a7b8b9e9e16d4e15fabda5ae615086c2e1c47d8a sklearn/linear_model/tests/test_least_angle.py
git apply -v - <<'EOF_114329324912'
diff --git a/sklearn/linear_model/tests/test_least_angle.py b/sklearn/linear_model/tests/test_least_angle.py
index 790b864..83e7390 100644
--- a/sklearn/linear_model/tests/test_least_angle.py
+++ b/sklearn/linear_model/tests/test_least_angle.py
@@ -5,7 +5,33 @@ from distutils.version import LooseVersion
 import numpy as np
 from scipy import linalg
 
+@pytest.mark.parametrize('init_copy_X, fit_copy_X, expected', [
+    (True, None, True),
+    (False, None, False),
+    (True, True, True),
+    (False, False, False),
+    (True, False, False),
+    (False, True, True),
+])
+def test_lasso_lars_ic_copy_X_resolution(init_copy_X, fit_copy_X, expected):
+    """Test that fit resolves copy_X correctly based on the inputs."""
+
+    lasso_lars_ic = LassoLarsIC(copy_X=init_copy_X, precompute=False)
+    rng = np.random.RandomState(0)
+    X = rng.normal(0, 1, (100, 5))
+    X_copy = X.copy()
+    y = X[:, 2]
+
+    if fit_copy_X is None:
+        lasso_lars_ic.fit(X, y)
+    else:
+        lasso_lars_ic.fit(X, y, copy_X=fit_copy_X)
+
+    assert expected == np.array_equal(X, X_copy)
+
 import pytest
+import numpy as np
+from sklearn.linear_model.least_angle import LassoLarsIC
 
 from sklearn.model_selection import train_test_split
 from sklearn.utils.testing import assert_equal

EOF_114329324912
pytest -rA sklearn/linear_model/tests/test_least_angle.py
git checkout a7b8b9e9e16d4e15fabda5ae615086c2e1c47d8a sklearn/linear_model/tests/test_least_angle.py
