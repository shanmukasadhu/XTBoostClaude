#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff d79be3ed39b76d3e34431873eec16f6dd354ab17
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout d79be3ed39b76d3e34431873eec16f6dd354ab17 tests/queries/test_bulk_update.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/queries/test_bulk_update.py b/tests/queries/test_bulk_update.py
index b579834..6aa7046 100644
--- a/tests/queries/test_bulk_update.py
+++ b/tests/queries/test_bulk_update.py
@@ -127,7 +127,27 @@ class BulkUpdateTests(TestCase):
         with self.assertNumQueries(0):
             Note.objects.bulk_update([], ['note'])
 
-    def test_large_batch(self):
+    def test_bulk_update_return_value_empty_list(self):
+        rows_updated = Note.objects.bulk_update([], ['note'])
+        self.assertEqual(rows_updated, 0)
+
+    def test_bulk_update_return_value_with_data(self):
+        Note.objects.bulk_create([
+            Note(note=str(i), misc=str(i))
+            for i in range(0, 2000)
+        ])
+        notes = list(Note.objects.all())
+        for note in notes:
+            note.note = 'updated-note'
+        rows_updated = Note.objects.bulk_update(notes, ['note'])
+        self.assertEqual(rows_updated, 2000)
+
+    def test_bulk_update_with_duplicates(self):
+        note = Note.objects.create(note='test-note', misc='test')
+        rows_updated = Note.objects.bulk_update([note, note], ['note'])
+        self.assertEqual(rows_updated, 1)
+        rows_updated = Note.objects.bulk_update([note, note], ['note'], batch_size=1)
+        self.assertEqual(rows_updated, 2)
         Note.objects.bulk_create([
             Note(note=str(i), misc=str(i))
             for i in range(0, 2000)

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 queries.test_bulk_update
git checkout d79be3ed39b76d3e34431873eec16f6dd354ab17 tests/queries/test_bulk_update.py
