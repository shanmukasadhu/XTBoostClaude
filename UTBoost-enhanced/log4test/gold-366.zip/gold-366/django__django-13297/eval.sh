#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 8954f255bbf5f4ee997fd6de62cb50fc9b5dd697
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 8954f255bbf5f4ee997fd6de62cb50fc9b5dd697 tests/generic_views/test_base.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/generic_views/test_base.py b/tests/generic_views/test_base.py
index 26c885d..e3775f3 100644
--- a/tests/generic_views/test_base.py
+++ b/tests/generic_views/test_base.py
@@ -1,6 +1,8 @@
 import time
 
 from django.core.exceptions import ImproperlyConfigured
+from django.shortcuts import get_object_or_404
+from .models import Artist, Account
 from django.http import HttpResponse
 from django.test import (
     RequestFactory, SimpleTestCase, ignore_warnings, override_settings,
@@ -590,7 +592,19 @@ class DeprecationTests(SimpleTestCase):
         self.assertEqual(response.context['key'], 'value')
         self.assertIsInstance(response.context['view'], View)
 
-    def test_template_params_warning(self):
+    @ignore_warnings(category=RemovedInDjango40Warning)
+    def test_template_params_filtering(self):
+        class OfferView(TemplateView):
+            template_name = 'offers/offer.html'
+
+            def get_context_data(self, offer_slug, **kwargs):
+                context = super().get_context_data(**kwargs)
+                offer = get_object_or_404(Account, slug=str(offer_slug))
+                return {**context, 'offer': offer}
+
+        account = Account.objects.create(slug='test-offer')
+        response = OfferView.as_view()(self.rf.get('/offers/test-offer/'), offer_slug='test-offer')
+        self.assertEqual(response.context_data['offer'], account)
         response = self.client.get('/template/custom/bar1/bar2/')
         self.assertEqual(response.status_code, 200)
         msg = (

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 generic_views.test_base
git checkout 8954f255bbf5f4ee997fd6de62cb50fc9b5dd697 tests/generic_views/test_base.py
