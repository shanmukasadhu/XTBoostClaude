#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 7fa1a93c6c8109010a6ff3f604fda83b604e0e97
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 7fa1a93c6c8109010a6ff3f604fda83b604e0e97 tests/middleware/test_security.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/middleware/test_security.py b/tests/middleware/test_security.py
index 7af62eb..1304f83 100644
--- a/tests/middleware/test_security.py
+++ b/tests/middleware/test_security.py
@@ -223,6 +223,14 @@ class SecurityMiddlewareTest(SimpleTestCase):
         ret = self.process_request("get", "/some/url")
         self.assertIsNone(ret)
 
+    @override_settings(SECURE_REFERRER_POLICY='same-origin')
+    def test_default_referrer_policy(self):
+        """
+        The default SECURE_REFERRER_POLICY should set the Referrer-Policy
+        to 'same-origin'.
+        """
+        self.assertEqual(self.process_response()['Referrer-Policy'], 'same-origin')
+
     @override_settings(SECURE_REFERRER_POLICY=None)
     def test_referrer_policy_off(self):
         """
@@ -247,6 +255,14 @@ class SecurityMiddlewareTest(SimpleTestCase):
             with self.subTest(value=value), override_settings(SECURE_REFERRER_POLICY=value):
                 self.assertEqual(self.process_response()['Referrer-Policy'], expected)
 
+    def test_referrer_policy_invalid_value(self):
+        """
+        The middleware will not add a Referrer-Policy header if the
+        SECURE_REFERRER_POLICY is set to an invalid value.
+        """
+        with override_settings(SECURE_REFERRER_POLICY='invalid-value'):
+            self.assertNotIn('Referrer-Policy', self.process_response())
+
     @override_settings(SECURE_REFERRER_POLICY='strict-origin')
     def test_referrer_policy_already_present(self):
         """
@@ -254,4 +270,4 @@ class SecurityMiddlewareTest(SimpleTestCase):
         present in the response.
         """
         response = self.process_response(headers={'Referrer-Policy': 'unsafe-url'})
-        self.assertEqual(response['Referrer-Policy'], 'unsafe-url')
+        self.assertEqual(response['Referrer-Policy'], 'unsafe-url')

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 project_template.test_settings
git checkout 7fa1a93c6c8109010a6ff3f604fda83b604e0e97 tests/middleware/test_security.py
