#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff da9a2b584eb7a6c7e924b2621ed0ddaeca0a7bea
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout da9a2b584eb7a6c7e924b2621ed0ddaeca0a7bea testing/test_debugging.py
git apply -v - <<'EOF_114329324912'
diff --git a/testing/test_debugging.py b/testing/test_debugging.py
index 912abd7..37966ec 100644
--- a/testing/test_debugging.py
+++ b/testing/test_debugging.py
@@ -192,6 +192,24 @@ class TestPDB:
         child.sendeof()
         self.flush(child)
 
+    def test_pdb_teardown_not_called_on_skip_class(self, pytester: Pytester) -> None:
+        """Test for issue with class-level skip"""
+        p1 = pytester.makepyfile(
+            """
+            import unittest
+            @unittest.skip('Skipping Class')
+            class MyTestCase(unittest.TestCase):
+                def setUp(self):
+                    assert False, "setUp should not be called"
+                def tearDown(self):
+                    assert False, "tearDown should not be called"
+                def test_one(self):
+                    pass
+        """
+        )
+        result = pytester.runpytest_inprocess("--pdb", p1)
+        result.stdout.fnmatch_lines("* 1 skipped in *")
+
     def test_pdb_print_captured_stdout_and_stderr(self, pytester: Pytester) -> None:
         p1 = pytester.makepyfile(
             """

EOF_114329324912
pytest -rA testing/test_unittest.py
git checkout da9a2b584eb7a6c7e924b2621ed0ddaeca0a7bea testing/test_debugging.py
