#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff a708f39ce67af174df90c5b5e50ad1976cec7cb8
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout a708f39ce67af174df90c5b5e50ad1976cec7cb8 tests/validators/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/validators/tests.py b/tests/validators/tests.py
index f726e49..938a68c 100644
--- a/tests/validators/tests.py
+++ b/tests/validators/tests.py
@@ -226,6 +226,13 @@ TEST_DATA = [
     (URLValidator(), None, ValidationError),
     (URLValidator(), 56, ValidationError),
     (URLValidator(), 'no_scheme', ValidationError),
+    # Newlines, carriage returns, and tabs are not accepted.
+    (URLValidator(), 'http://www.djangoproject.com/\r', ValidationError),
+    (URLValidator(), 'http://[::ffff:192.9.5.5]\r', ValidationError),
+    (URLValidator(), 'http://www.django\rproject.com/', ValidationError),
+    (URLValidator(), 'http://[::\rffff:192.9.5.5]', ValidationError),
+    (URLValidator(), 'http://\twww.djangoproject.com/', ValidationError),
+    (URLValidator(), 'http://\t[::ffff:192.9.5.5]', ValidationError),
     # Trailing newlines not accepted
     (URLValidator(), 'http://www.djangoproject.com/\n', ValidationError),
     (URLValidator(), 'http://[::ffff:192.9.5.5]\n', ValidationError),
@@ -329,7 +336,20 @@ class TestValidators(SimpleTestCase):
                 else:
                     self.assertEqual(expected, validator(value))
 
-    def test_single_message(self):
+    def test_strip_forbidden_characters(self):
+        validator = URLValidator()
+        with self.assertRaises(ValidationError):
+            validator('http://www.djangoproject.com/\n')
+        with self.assertRaises(ValidationError):
+            validator('http://www.djangoproject.com/\r')
+        with self.assertRaises(ValidationError):
+            validator('http://www.djangoproject.com/\t')
+        with self.assertRaises(ValidationError):
+            validator('http://[::ffff:192.9.5.5]\n')
+        with self.assertRaises(ValidationError):
+            validator('http://[::ffff:192.9.5.5]\r')
+        with self.assertRaises(ValidationError):
+            validator('http://[::ffff:192.9.5.5]\t')
         v = ValidationError('Not Valid')
         self.assertEqual(str(v), "['Not Valid']")
         self.assertEqual(repr(v), "ValidationError(['Not Valid'])")

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 validators.tests
git checkout a708f39ce67af174df90c5b5e50ad1976cec7cb8 tests/validators/tests.py
