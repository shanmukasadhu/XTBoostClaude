#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 205da797006360fc629110937e39a19c9561313e
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 205da797006360fc629110937e39a19c9561313e sympy/printing/tests/test_python.py
git apply -v - <<'EOF_114329324912'
diff --git a/sympy/printing/tests/test_python.py b/sympy/printing/tests/test_python.py
index 73fc070..f99ea43 100644
--- a/sympy/printing/tests/test_python.py
+++ b/sympy/printing/tests/test_python.py
@@ -79,6 +79,14 @@ def test_python_keyword_function_name_escaping():
         5*Function("for")(8)) == "for_ = Function('for')\ne = 5*for_(8)"
 
 
+from sympy import Eq, Ne, Symbol, sstr, Rational, Limit, S
+
+def test_sstr_sympy_integers():
+    x = Symbol("x")
+    assert sstr(x + S(1)/2, sympy_integers=True) == "x + S(1)/2"
+    assert sstr(Eq(x, S(1)/2), sympy_integers=True) == "Eq(x, S(1)/2)"
+    assert sstr(Limit(x, x, S(1)/2), sympy_integers=True) == "Limit(x, x, S(1)/2)"
+
 def test_python_relational():
     assert python(Eq(x, y)) == "e = Eq(x, y)"
     assert python(Ge(x, y)) == "x = Symbol('x')\ny = Symbol('y')\ne = x >= y"

EOF_114329324912
PYTHONWARNINGS='ignore::UserWarning,ignore::SyntaxWarning' bin/test -C --verbose sympy/printing/tests/test_python.py sympy/printing/tests/test_str.py
git checkout 205da797006360fc629110937e39a19c9561313e sympy/printing/tests/test_python.py
