#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 9a6e2df3a8f01ea761529bec48e5a8dc0ea9575b
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 9a6e2df3a8f01ea761529bec48e5a8dc0ea9575b tests/messages_tests/base.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/messages_tests/base.py b/tests/messages_tests/base.py
index 85a7769..3386412 100644
--- a/tests/messages_tests/base.py
+++ b/tests/messages_tests/base.py
@@ -1,4 +1,6 @@
+
 from django.contrib.messages import constants, get_level, set_level, utils
+from django.test import SimpleTestCase
 from django.contrib.messages.api import MessageFailure
 from django.contrib.messages.constants import DEFAULT_LEVELS
 from django.contrib.messages.storage import base, default_storage

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 messages_tests.base messages_tests.tests
git checkout 9a6e2df3a8f01ea761529bec48e5a8dc0ea9575b tests/messages_tests/base.py
