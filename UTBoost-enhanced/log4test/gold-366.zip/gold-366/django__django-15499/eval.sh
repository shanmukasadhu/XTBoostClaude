#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff d90e34c61b27fba2527834806639eebbcfab9631
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout d90e34c61b27fba2527834806639eebbcfab9631 tests/migrations/test_optimizer.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/migrations/test_optimizer.py b/tests/migrations/test_optimizer.py
index 5df1b06..5f5fe61 100644
--- a/tests/migrations/test_optimizer.py
+++ b/tests/migrations/test_optimizer.py
@@ -122,11 +122,349 @@ class OptimizerTests(SimpleTestCase):
                     name="Foo", options={"verbose_name_plural": "Foozes"}
                 ),
             ],
+            [
+                migrations.CreateModel(
+                    "Foo", fields=[], managers=[("objects", models.Manager())]
+                ),
+            ],
+        )
+
+    def test_create_alter_model_managers_single_manager(self):
+        self.assertOptimizesTo(
+            [
+                migrations.CreateModel("Bar", fields=[]),
+                migrations.AlterModelManagers(
+                    name="Bar",
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Bar",
+                    fields=[],
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Foo", fields=[], managers=[("objects", models.Manager()), ("things", models.Manager())]
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Foo", fields=[], managers=[("objects", models.Manager())]
+                ),
+            ],
+        )
+
+    def test_create_alter_model_managers_single_manager(self):
+        self.assertOptimizesTo(
+            [
+                migrations.CreateModel("Bar", fields=[]),
+                migrations.AlterModelManagers(
+                    name="Bar",
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Bar",
+                    fields=[],
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+        )
+
+    def test_create_model_alter_then_alter_managers(self):
+        self.assertOptimizesTo(
+            [
+                migrations.CreateModel("Baz", fields=[]),
+                migrations.AlterModelOptions(
+                    name="Baz",
+                    options={"ordering": ["id"]},
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Foo", fields=[], managers=[("objects", models.Manager())]
+                ),
+            ],
+        )
+
+    def test_create_alter_model_managers_single_manager(self):
+        self.assertOptimizesTo(
+            [
+                migrations.CreateModel("Bar", fields=[]),
+                migrations.AlterModelManagers(
+                    name="Bar",
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Bar",
+                    fields=[],
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+                migrations.AlterModelManagers(
+                    name="Baz",
+                    managers=[
+                        ("objects", models.Manager()),
+                        ("extras", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Foo", fields=[], managers=[("objects", models.Manager())]
+                ),
+            ],
+        )
+
+    def test_create_alter_model_managers_single_manager(self):
+        self.assertOptimizesTo(
+            [
+                migrations.CreateModel("Bar", fields=[]),
+                migrations.AlterModelManagers(
+                    name="Bar",
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Bar",
+                    fields=[],
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Baz",
+                    fields=[],
+                    options={"ordering": ["id"]},
+                    managers=[
+                        ("objects", models.Manager()),
+                        ("extras", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Foo", fields=[], managers=[("objects", models.Manager())]
+                ),
+            ],
+        )
+
+    def test_create_alter_model_managers_single_manager(self):
+        self.assertOptimizesTo(
+            [
+                migrations.CreateModel("Bar", fields=[]),
+                migrations.AlterModelManagers(
+                    name="Bar",
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Bar",
+                    fields=[],
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
             [
                 migrations.CreateModel(
                     "Foo", fields=[], options={"verbose_name_plural": "Foozes"}
                 ),
             ],
+            [
+                migrations.CreateModel(
+                    "Foo", fields=[], managers=[("objects", models.Manager())]
+                ),
+            ],
+        )
+
+    def test_create_alter_model_managers_single_manager(self):
+        self.assertOptimizesTo(
+            [
+                migrations.CreateModel("Bar", fields=[]),
+                migrations.AlterModelManagers(
+                    name="Bar",
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Bar",
+                    fields=[],
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Foo", fields=[], managers=[("objects", models.Manager()), ("things", models.Manager())]
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Foo", fields=[], managers=[("objects", models.Manager())]
+                ),
+            ],
+        )
+
+    def test_create_alter_model_managers_single_manager(self):
+        self.assertOptimizesTo(
+            [
+                migrations.CreateModel("Bar", fields=[]),
+                migrations.AlterModelManagers(
+                    name="Bar",
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Bar",
+                    fields=[],
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+        )
+
+    def test_create_model_alter_then_alter_managers(self):
+        self.assertOptimizesTo(
+            [
+                migrations.CreateModel("Baz", fields=[]),
+                migrations.AlterModelOptions(
+                    name="Baz",
+                    options={"ordering": ["id"]},
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Foo", fields=[], managers=[("objects", models.Manager())]
+                ),
+            ],
+        )
+
+    def test_create_alter_model_managers_single_manager(self):
+        self.assertOptimizesTo(
+            [
+                migrations.CreateModel("Bar", fields=[]),
+                migrations.AlterModelManagers(
+                    name="Bar",
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Bar",
+                    fields=[],
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+                migrations.AlterModelManagers(
+                    name="Baz",
+                    managers=[
+                        ("objects", models.Manager()),
+                        ("extras", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Foo", fields=[], managers=[("objects", models.Manager())]
+                ),
+            ],
+        )
+
+    def test_create_alter_model_managers_single_manager(self):
+        self.assertOptimizesTo(
+            [
+                migrations.CreateModel("Bar", fields=[]),
+                migrations.AlterModelManagers(
+                    name="Bar",
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Bar",
+                    fields=[],
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Baz",
+                    fields=[],
+                    options={"ordering": ["id"]},
+                    managers=[
+                        ("objects", models.Manager()),
+                        ("extras", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Foo", fields=[], managers=[("objects", models.Manager())]
+                ),
+            ],
+        )
+
+    def test_create_alter_model_managers_single_manager(self):
+        self.assertOptimizesTo(
+            [
+                migrations.CreateModel("Bar", fields=[]),
+                migrations.AlterModelManagers(
+                    name="Bar",
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Bar",
+                    fields=[],
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
         )
 
     def test_create_model_and_remove_model_options(self):
@@ -137,6 +475,175 @@ class OptimizerTests(SimpleTestCase):
                     fields=[],
                     options={"verbose_name": "My Model"},
                 ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Foo", fields=[], managers=[("objects", models.Manager())]
+                ),
+            ],
+        )
+
+    def test_create_alter_model_managers_single_manager(self):
+        self.assertOptimizesTo(
+            [
+                migrations.CreateModel("Bar", fields=[]),
+                migrations.AlterModelManagers(
+                    name="Bar",
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Bar",
+                    fields=[],
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Foo", fields=[], managers=[("objects", models.Manager()), ("things", models.Manager())]
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Foo", fields=[], managers=[("objects", models.Manager())]
+                ),
+            ],
+        )
+
+    def test_create_alter_model_managers_single_manager(self):
+        self.assertOptimizesTo(
+            [
+                migrations.CreateModel("Bar", fields=[]),
+                migrations.AlterModelManagers(
+                    name="Bar",
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Bar",
+                    fields=[],
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+        )
+
+    def test_create_model_alter_then_alter_managers(self):
+        self.assertOptimizesTo(
+            [
+                migrations.CreateModel("Baz", fields=[]),
+                migrations.AlterModelOptions(
+                    name="Baz",
+                    options={"ordering": ["id"]},
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Foo", fields=[], managers=[("objects", models.Manager())]
+                ),
+            ],
+        )
+
+    def test_create_alter_model_managers_single_manager(self):
+        self.assertOptimizesTo(
+            [
+                migrations.CreateModel("Bar", fields=[]),
+                migrations.AlterModelManagers(
+                    name="Bar",
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Bar",
+                    fields=[],
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+                migrations.AlterModelManagers(
+                    name="Baz",
+                    managers=[
+                        ("objects", models.Manager()),
+                        ("extras", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Foo", fields=[], managers=[("objects", models.Manager())]
+                ),
+            ],
+        )
+
+    def test_create_alter_model_managers_single_manager(self):
+        self.assertOptimizesTo(
+            [
+                migrations.CreateModel("Bar", fields=[]),
+                migrations.AlterModelManagers(
+                    name="Bar",
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Bar",
+                    fields=[],
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Baz",
+                    fields=[],
+                    options={"ordering": ["id"]},
+                    managers=[
+                        ("objects", models.Manager()),
+                        ("extras", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Foo", fields=[], managers=[("objects", models.Manager())]
+                ),
+            ],
+        )
+
+    def test_create_alter_model_managers_single_manager(self):
+        self.assertOptimizesTo(
+            [
+                migrations.CreateModel("Bar", fields=[]),
+                migrations.AlterModelManagers(
+                    name="Bar",
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
+            ],
+            [
+                migrations.CreateModel(
+                    "Bar",
+                    fields=[],
+                    managers=[
+                        ("objects", models.Manager()),
+                    ],
+                ),
                 migrations.AlterModelOptions("MyModel", options={}),
             ],
             [migrations.CreateModel("MyModel", fields=[])],

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 migrations.test_optimizer
git checkout d90e34c61b27fba2527834806639eebbcfab9631 tests/migrations/test_optimizer.py
