#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 67d06b18c68ee4452768f8a1e868565dd4354abf
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -v --no-use-pep517 --no-build-isolation -e .
git checkout 67d06b18c68ee4452768f8a1e868565dd4354abf sklearn/feature_extraction/tests/test_text.py
git apply -v - <<'EOF_114329324912'
diff --git a/sklearn/feature_extraction/tests/test_text.py b/sklearn/feature_extraction/tests/test_text.py
index 0a2b603..d1b162d 100644
--- a/sklearn/feature_extraction/tests/test_text.py
+++ b/sklearn/feature_extraction/tests/test_text.py
@@ -558,8 +558,23 @@ def test_feature_names():
     for idx, name in enumerate(feature_names):
         assert_equal(idx, cv.vocabulary_.get(name))
 
-
-def test_vectorizer_max_features():
+def test_countvectorizer_custom_vocabulary_get_feature_names():
+    vocab = ['and', 'document', 'first', 'is', 'one', 'second', 'the', 'third', 'this']
+    vectorizer = CountVectorizer(vocabulary=vocab)
+    
+    # Check that get_feature_names does not raise NotFittedError
+    feature_names = vectorizer.get_feature_names()
+    assert_array_equal(vocab, feature_names)
+
+    # Transform should work without fitting
+    corpus = [
+        'This is the first document.',
+        'This is the second second document.',
+        'And the third one.',
+        'Is this the first document?'
+    ]
+    X = vectorizer.transform(corpus)
+    assert_equal(X.shape, (4, len(vocab)))
     vec_factories = (
         CountVectorizer,
         TfidfVectorizer,

EOF_114329324912
pytest -rA sklearn/feature_extraction/tests/test_text.py
git checkout 67d06b18c68ee4452768f8a1e868565dd4354abf sklearn/feature_extraction/tests/test_text.py
