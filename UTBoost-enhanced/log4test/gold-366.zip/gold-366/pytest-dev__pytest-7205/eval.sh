#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 5e7f1ab4bf58e473e5d7f878eb2b499d7deabd29
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 5e7f1ab4bf58e473e5d7f878eb2b499d7deabd29 testing/test_setuponly.py
git apply -v - <<'EOF_114329324912'
diff --git a/testing/test_setuponly.py b/testing/test_setuponly.py
index 8211d39..e5a789a 100644
--- a/testing/test_setuponly.py
+++ b/testing/test_setuponly.py
@@ -1,3 +1,4 @@
+
 import pytest
 from _pytest.config import ExitCode
 
@@ -200,8 +201,21 @@ def test_show_fixtures_with_parameter_ids_function(testdir, mode):
 
     result.stdout.fnmatch_lines(["*SETUP    F foobar?FOO?", "*SETUP    F foobar?BAR?"])
 
+def test_show_fixture_action_with_bytes(testdir):
+    # Issue 7126, BytesWarning when using --setup-show with bytes parameter
+    test_file = testdir.makepyfile(
+        """
+        import pytest
 
-def test_dynamic_fixture_request(testdir):
+        @pytest.mark.parametrize('data', [b'Hello World'])
+        def test_data(data):
+            pass
+        """
+    )
+    result = testdir.run(
+        sys.executable, "-bb", "-m", "pytest", "--setup-show", str(test_file)
+    )
+    assert result.ret == 0
     p = testdir.makepyfile(
         """
         import pytest

EOF_114329324912
pytest -rA testing/test_setuponly.py
git checkout 5e7f1ab4bf58e473e5d7f878eb2b499d7deabd29 testing/test_setuponly.py
