#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff a7e7043c8746933dafce652507d3b821801cdc7d
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout a7e7043c8746933dafce652507d3b821801cdc7d tests/migrations/test_autodetector.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/migrations/test_autodetector.py b/tests/migrations/test_autodetector.py
index 04452fa..4e91f19 100644
--- a/tests/migrations/test_autodetector.py
+++ b/tests/migrations/test_autodetector.py
@@ -2835,7 +2835,25 @@ class AutodetectorTests(TestCase):
                 )
 
 
-class MigrationSuggestNameTests(SimpleTestCase):
+class CustomFKField(models.ForeignKey):
+    def __init__(self, *args, **kwargs):
+        kwargs['to'] = 'testapp.HardcodedModel'
+        super().__init__(*args, **kwargs)
+
+    def deconstruct(self):
+        name, path, args, kwargs = super().deconstruct()
+        del kwargs["to"]
+        return name, path, args, kwargs
+
+class HardcodedForeignKeyTestCase(TestCase):
+    def test_hardcoded_fk_field(self):
+        before = ProjectState()
+        before.add_model(ModelState('testapp', 'HardcodedModel', []))
+        after = ProjectState()
+        after.add_model(ModelState('testapp', 'HardcodedModel', []))
+        after.add_model(ModelState('testapp', 'TestModel', [('custom', CustomFKField(on_delete=models.CASCADE))]))
+        changes = MigrationAutodetector(before, after)._detect_changes()
+        self.assertEqual(len(changes['testapp']), 1)
     def test_no_operations(self):
         class Migration(migrations.Migration):
             operations = []

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 migrations.test_autodetector
git checkout a7e7043c8746933dafce652507d3b821801cdc7d tests/migrations/test_autodetector.py
