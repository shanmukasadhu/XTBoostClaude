#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 652c68ffeebd510a6f59e1b56b3e007d07683ad8
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 652c68ffeebd510a6f59e1b56b3e007d07683ad8 tests/model_fields/tests.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/model_fields/tests.py b/tests/model_fields/tests.py
index e4daf0e..d1daec8 100644
--- a/tests/model_fields/tests.py
+++ b/tests/model_fields/tests.py
@@ -10,6 +10,8 @@ from .models import (
     Bar, Choiceful, Foo, RenamedField, VerboseNameField, Whiz, WhizDelayed,
     WhizIter, WhizIterEmpty,
 )
+from django.db import models
+from django.test import SimpleTestCase
 
 
 class Nested:
@@ -19,7 +21,38 @@ class Nested:
 
 class BasicFieldTests(SimpleTestCase):
 
-    def test_show_hidden_initial(self):
+    def test_hash_immutability(self):
+        field = models.CharField(max_length=200)
+        field_hash = hash(field)
+
+        class MyModel(models.Model):
+            title = field
+
+        self.assertEqual(field_hash, hash(field))
+
+    def test_field_in_dict(self):
+        field = models.CharField(max_length=200)
+        field_hash = hash(field)
+        field_dict = {field: 'test'}
+
+        class MyModel(models.Model):
+            title = field
+
+        # Ensure field is still in the dict after being assigned to a model
+        self.assertTrue(field in field_dict)
+        self.assertEqual(field_hash, hash(field))  # Hash should remain the same
+
+    def test_field_equality_after_assignment(self):
+        field1 = models.CharField(max_length=200)
+        field2 = models.CharField(max_length=200)
+        
+        self.assertNotEqual(hash(field1), hash(field2))  # Different fields should have different hashes
+
+        class MyModel(models.Model):
+            title1 = field1
+            title2 = field2
+
+        self.assertNotEqual(hash(field1), hash(field2))  # Ensure hashes are still different after assignment
         """
         Fields with choices respect show_hidden_initial as a kwarg to
         formfield().

EOF_114329324912
./tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1 model_fields.tests
git checkout 652c68ffeebd510a6f59e1b56b3e007d07683ad8 tests/model_fields/tests.py
