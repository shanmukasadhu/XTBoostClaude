#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 9f0b959a8c9195d1b6e203f08b698e052b426ca9
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -v --no-use-pep517 --no-build-isolation -e .
git checkout 9f0b959a8c9195d1b6e203f08b698e052b426ca9 sklearn/model_selection/tests/test_split.py
git apply -v - <<'EOF_114329324912'
diff --git a/sklearn/model_selection/tests/test_split.py b/sklearn/model_selection/tests/test_split.py
index 785bf42..f1d8b97 100644
--- a/sklearn/model_selection/tests/test_split.py
+++ b/sklearn/model_selection/tests/test_split.py
@@ -494,7 +494,32 @@ def test_shuffle_stratifiedkfold():
     check_cv_coverage(kf0, X_40, y, groups=None, expected_n_splits=5)
 
 
-def test_kfold_can_detect_dependent_samples_on_digits():  # see #2372
+def test_stratifiedkfold_shuffle_effectiveness():
+    import numpy as np
+    from sklearn.model_selection import StratifiedKFold
+
+    X = np.arange(20)
+    y = [0] * 10 + [1] * 10
+
+    # Check different random_states produce different test sets
+    kf1 = StratifiedKFold(n_splits=10, shuffle=True, random_state=42)
+    kf2 = StratifiedKFold(n_splits=10, shuffle=True, random_state=24)
+
+    test_sets_1 = [test for _, test in kf1.split(X, y)]
+    test_sets_2 = [test for _, test in kf2.split(X, y)]
+
+    for ts1, ts2 in zip(test_sets_1, test_sets_2):
+        assert not np.array_equal(ts1, ts2)
+
+    # Check that without shuffle, test sets are the same
+    kf3 = StratifiedKFold(n_splits=10, shuffle=False)
+    kf4 = StratifiedKFold(n_splits=10, shuffle=False)
+
+    test_sets_3 = [test for _, test in kf3.split(X, y)]
+    test_sets_4 = [test for _, test in kf4.split(X, y)]
+
+    for ts3, ts4 in zip(test_sets_3, test_sets_4):
+        assert np.array_equal(ts3, ts4)
     # The digits samples are dependent: they are apparently grouped by authors
     # although we don't have any information on the groups segment locations
     # for this data. We can highlight this fact by computing k-fold cross-

EOF_114329324912
pytest -rA sklearn/model_selection/tests/test_split.py
git checkout 9f0b959a8c9195d1b6e203f08b698e052b426ca9 sklearn/model_selection/tests/test_split.py
