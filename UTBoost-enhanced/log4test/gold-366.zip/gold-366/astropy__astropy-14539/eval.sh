#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff c0a24c1dc957a3b565294213f435fefb2ec99714
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .[test] --verbose
git checkout c0a24c1dc957a3b565294213f435fefb2ec99714 astropy/io/fits/tests/test_diff.py
git apply -v - <<'EOF_114329324912'
diff --git a/astropy/io/fits/tests/test_diff.py b/astropy/io/fits/tests/test_diff.py
index 9bf4897..26fc44d 100644
--- a/astropy/io/fits/tests/test_diff.py
+++ b/astropy/io/fits/tests/test_diff.py
@@ -601,7 +601,34 @@ class TestDiff(FitsTestCase):
         assert "13 different table data element(s) found (65.00% different)" in report
         assert report.count("more indices") == 1
 
-    def test_identical_files_basic(self):
+    def test_identical_files_variable_length_arrays(self):
+        """
+        Test that FITSDiff does not report differences for identical files with VLAs.
+        """
+        # Setup a file with a VLA column
+        col = Column('a', format='QD', array=[[0], [0, 0]])
+        hdu = BinTableHDU.from_columns([col])
+        hdu.writeto('test_vla_identical.fits', overwrite=True)
+
+        # Perform FITSDiff on the same file
+        diff = FITSDiff('test_vla_identical.fits', 'test_vla_identical.fits')
+        assert diff.identical, "FITSDiff is reporting differences on identical files with VLAs"
+
+    def test_vla_differences(self):
+        """
+        Test that FITSDiff reports differences for files with different VLA data.
+        """
+        # Setup two files with different VLA data
+        col1 = Column('a', format='QD', array=[[0], [0, 0]])
+        col2 = Column('a', format='QD', array=[[1], [1, 1]])
+        hdu1 = BinTableHDU.from_columns([col1])
+        hdu2 = BinTableHDU.from_columns([col2])
+        hdu1.writeto('test_vla_diff1.fits', overwrite=True)
+        hdu2.writeto('test_vla_diff2.fits', overwrite=True)
+
+        # Perform FITSDiff on two different files
+        diff = FITSDiff('test_vla_diff1.fits', 'test_vla_diff2.fits')
+        assert not diff.identical, "FITSDiff failed to report differences between files with differing VLA data"
         """Test identicality of two simple, extensionless files."""
 
         a = np.arange(100).reshape(10, 10)

EOF_114329324912
pytest -rA astropy/io/fits/tests/test_diff.py
git checkout c0a24c1dc957a3b565294213f435fefb2ec99714 astropy/io/fits/tests/test_diff.py
