#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git diff 3a668ea6ff24b0c8f00498c3144c63bac561d925
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 3a668ea6ff24b0c8f00498c3144c63bac561d925 testing/test_collection.py
git apply -v - <<'EOF_114329324912'
diff --git a/testing/test_collection.py b/testing/test_collection.py
index fb6b260..10a9b41 100644
--- a/testing/test_collection.py
+++ b/testing/test_collection.py
@@ -681,8 +681,20 @@ class Test_genitems:
                 if numj != numi:
                     assert hash(i) != hash(j)
                     assert i != j
+    def test_issue_resolved_parametrize_dot_bracket(self, testdir):
+        p = testdir.makepyfile(
+            """
+            import pytest
 
-    def test_example_items1(self, testdir):
+            @pytest.mark.parametrize("arg0", [".["])
+            def testmethod_two(arg0):
+                pass
+            """
+        )
+        items, reprec = testdir.inline_genitems(p)
+        assert len(items) == 1
+        assert items[0].name == "testmethod_two[.[]"
+        assert items[0].getmodpath() == "testmethod_two[.[]"
         p = testdir.makepyfile(
             """
             def testone():

EOF_114329324912
pytest -rA testing/test_collection.py
git checkout 3a668ea6ff24b0c8f00498c3144c63bac561d925 testing/test_collection.py
